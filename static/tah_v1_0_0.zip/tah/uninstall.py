#!/usr/bin/env python3
"""
uninstall.py — Tah Clean Removal

No tricks. No leftovers. No trace.
This is a promise.

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""

import os
import shutil

FILES_TO_REMOVE = [
    "tah_settings.json",
    "tah_audit.log",
    "tah_undo.json",
]

DIRS_TO_REMOVE = [
    "tah",
    "__pycache__",
]

def uninstall():
    print()
    print("  Tah — Clean Removal")
    print("  ─────────────────────────────────────────────────")
    print()
    print("  Tah will now remove itself completely.")
    print("  No files will remain. No registry entries. No trace.")
    print()

    confirm = input("  Are you sure? [y/N] ").strip().lower()
    if confirm != "y":
        print("\n  Uninstall cancelled. Tah remains.\n")
        return

    print()
    removed = []

    for f in FILES_TO_REMOVE:
        if os.path.exists(f):
            try:
                os.remove(f)
                removed.append(f)
                print(f"  ✓  Removed: {f}")
            except Exception as e:
                print(f"  ✗  Could not remove {f}: {e}")

    for d in DIRS_TO_REMOVE:
        if os.path.exists(d):
            try:
                shutil.rmtree(d)
                removed.append(d)
                print(f"  ✓  Removed: {d}/")
            except Exception as e:
                print(f"  ✗  Could not remove {d}: {e}")

    # Remove report files
    for f in os.listdir("."):
        if f.startswith("Tah_Report_") and f.endswith(".txt"):
            try:
                os.remove(f)
                print(f"  ✓  Removed: {f}")
            except Exception:
                pass

    print()
    print("  Tah has been removed.")
    print("  Thank you for letting us help.")
    print()
    print("  You can always find Tah again at:")
    print("  The Commons — commons.onrender.com")
    print()

    # Remove this script last
    try:
        os.remove(__file__)
    except Exception:
        pass

if __name__ == "__main__":
    uninstall()
