# pn198nJPR8DHoIvOZCFAiSbLKibyOUlNu5bj874S32XOpi6LtWLdtVFCPZNdJgNV
# 2lgRgWEvjyySrV5q3iDmx0OnF6cwGQvsY6g5DtKxv0U5hhJM8631liQlCMDyTVFl
""""""
import os
import shutil
_LMyNnPGhVgaw = ['tah_settings.json', 'tah_audit.log', 'tah_undo.json']
_zbJePcgQUUTF = ['tah', '__pycache__']

def _oyvoyVjKBOxw():
    print()
    print('  Tah — Clean Removal')
    print('  ─────────────────────────────────────────────────')
    print()
    print('  Tah will now remove itself completely.')
    print('  No files will remain. No registry entries. No trace.')
    print()
    _zOltFVAglMVu = _WTZAjifvklDe('  Are you sure? [y/N] ').strip().lower()
    if _zOltFVAglMVu != 'y':
        print('\n  Uninstall cancelled. Tah remains.\n')
        return
    print()
    _EafoPtQAhnDd = []
    for _FmGodtyFUtwL in _LMyNnPGhVgaw:
        if os.path.exists(_FmGodtyFUtwL):
            try:
                os.remove(_FmGodtyFUtwL)
                _EafoPtQAhnDd.append(_FmGodtyFUtwL)
                print(f'  ✓  Removed: {_FmGodtyFUtwL}')
            except Exception as e:
                print(f'  ✗  Could not remove {_FmGodtyFUtwL}: {_xmkWNvQFeIwA}')
    for _TcGcSZEjzqMG in _zbJePcgQUUTF:
        if os.path.exists(_TcGcSZEjzqMG):
            try:
                shutil.rmtree(_TcGcSZEjzqMG)
                _EafoPtQAhnDd.append(_TcGcSZEjzqMG)
                print(f'  ✓  Removed: {_TcGcSZEjzqMG}/')
            except Exception as e:
                print(f'  ✗  Could not remove {_TcGcSZEjzqMG}: {_xmkWNvQFeIwA}')
    for _FmGodtyFUtwL in os.listdir('.'):
        if _FmGodtyFUtwL.startswith('Tah_Report_') and _FmGodtyFUtwL.endswith('.txt'):
            try:
                os.remove(_FmGodtyFUtwL)
                print(f'  ✓  Removed: {_FmGodtyFUtwL}')
            except Exception:
                pass
    print()
    print('  Tah has been removed.')
    print('  Thank you for letting us help.')
    print()
    print('  You can always find Tah again at:')
    print('  The Commons — commons.onrender.com')
    print()
    try:
        os.remove(__file__)
    except Exception:
        pass
if __name__ == '__main__':
    _oyvoyVjKBOxw()