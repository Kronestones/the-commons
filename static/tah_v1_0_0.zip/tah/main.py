#!/usr/bin/env python3
"""
main.py — Tah Enhancement Council

The launcher. Clean and purposeful.

Usage:
    python main.py              # Background watch mode
    python main.py --enhance    # Full enhancement scan right now
    python main.py --status     # Check what Tah found and changed
    python main.py --undo       # Undo last enhancement session
    python main.py --mode auto|ask|watch

— Krone the Architect · Powers Tracey Lynn
  Tah Enhancement Council · 2026
"""

import argparse
import signal
import sys

parser = argparse.ArgumentParser(
    description="Tah — Device enhancement for everyone."
)
parser.add_argument("--enhance", action="store_true",
                    help="Run a full enhancement scan right now")
parser.add_argument("--status",  action="store_true",
                    help="Show what Tah found and changed")
parser.add_argument("--undo",    action="store_true",
                    help="Undo the last enhancement session")
parser.add_argument("--mode",    metavar="MODE",
                    help="Set mode: auto / ask / watch")
parser.add_argument("--version", action="store_true",
                    help="Print version and exit")
args = parser.parse_args()

VERSION = "1.0.0"

if args.version:
    print(f"Tah v{VERSION}")
    sys.exit(0)

from tah.engine import TahEngine

engine = TahEngine()

if args.mode:
    engine.set_user_mode(args.mode)
    sys.exit(0)

if args.status:
    status = engine.status()
    print()
    print("  ╔══════════════════════════════════════════════════╗")
    print("  ║   T A H   —   Status                            ║")
    print("  ╚══════════════════════════════════════════════════╝")
    print()
    for k, v in status.items():
        print(f"  {k:<22} {v}")
    print()
    sys.exit(0)

if args.undo:
    engine.enhance.undo_last_session()
    sys.exit(0)

# Graceful shutdown
def handle_shutdown(signum, frame):
    print("\n  Tah is stepping back. The fog lifts.")
    engine.stop()
    sys.exit(0)

signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT,  handle_shutdown)

# Launch
if args.enhance:
    engine.start(mode="enhance")
else:
    engine.start(mode="watch")
