# Pa5YaW5jeLtnyH2XD9Z6y9ViEEo9J0283cWFwkbEa0Tmn7YsJSXN63lhA9Te19Sm
# Bz61BsT1BLWUQsywcZ3iJc0vw4KBbxyvIWkGiya8xVpfkXoEZcIHAYZEemX8SrMH
""""""
import argparse
import signal
import sys
_GioYgfxnCfUA = argparse.ArgumentParser(description='Tah — Device enhancement for everyone.')
_GioYgfxnCfUA.add_argument('--enhance', action='store_true', help='Run a full enhancement scan right now')
_GioYgfxnCfUA.add_argument('--status', action='store_true', help='Show what Tah found and changed')
_GioYgfxnCfUA.add_argument('--undo', action='store_true', help='Undo the last enhancement session')
_GioYgfxnCfUA.add_argument('--mode', metavar='MODE', help='Set mode: auto / ask / watch')
_GioYgfxnCfUA.add_argument('--version', action='store_true', help='Print version and exit')
_lFQIrWwjytUT = _GioYgfxnCfUA.parse_args()
_OLsfmpQaKrQa = '1.0.0'
if _lFQIrWwjytUT.version:
    print(f'Tah v{_OLsfmpQaKrQa}')
    sys.exit(0)
from tah.engine import TahEngine
_CyBplAMwDEZK = _WBBwsbVKXzKh()
if _lFQIrWwjytUT.mode:
    _CyBplAMwDEZK.set_user_mode(_lFQIrWwjytUT.mode)
    sys.exit(0)
if _lFQIrWwjytUT.status:
    _bVKwOhTVuSnY = _CyBplAMwDEZK.status()
    print()
    print('  ╔══════════════════════════════════════════════════╗')
    print('  ║   T A H   —   Status                            ║')
    print('  ╚══════════════════════════════════════════════════╝')
    print()
    for _vBuAgxZVFhgP, _BRRFIPnicOIi in _bVKwOhTVuSnY.items():
        print(f'  {_vBuAgxZVFhgP:<22} {_BRRFIPnicOIi}')
    print()
    sys.exit(0)
if _lFQIrWwjytUT.undo:
    _CyBplAMwDEZK.enhance.undo_last_session()
    sys.exit(0)

def _uDvewUSyXNSo(_rToShBxIvgub, _URcffpRtitfM):
    print('\n  Tah is stepping back. The fog lifts.')
    _CyBplAMwDEZK.stop()
    sys.exit(0)
_JhDQrKSfQMxj.signal(_JhDQrKSfQMxj.SIGTERM, _uDvewUSyXNSo)
_JhDQrKSfQMxj.signal(_JhDQrKSfQMxj.SIGINT, _uDvewUSyXNSo)
if _lFQIrWwjytUT.enhance:
    _CyBplAMwDEZK.start(mode='enhance')
else:
    _CyBplAMwDEZK.start(mode='watch')