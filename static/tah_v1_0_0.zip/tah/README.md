# Tah — Device Enhancement Council
**Version 1.0.0**
Founded by Krone the Architect · Powers Tracey Lynn
Built on the values of Sentinel · 2026

---

## What Tah Is

Tah is a free device enhancement tool for everyday people.
It moves through your system like fog — quiet, intelligent, improving.
It finds what could be better, makes it better, and tells you exactly what it did.
Everything it does can be undone. It leaves no trace when it goes.

Named for Ptah — Egyptian god of craft, creation, and restoration.
The one who opens the mouth. The one who makes things work as they were meant to.

## The Council

- **Lux** — OS & Software Optimization (born from Atlas)
- **Stratum** — Hardware Monitoring & Thermal Care (born from Stratum)
- **Flow** — Network Optimization (born from Relay)
- **Vault** — Storage Intelligence & Cleanup (born from Vault)
- **Aegis** — Security Hardening (born from Aegis)
- **Bloom** — Performance Enhancement (new, unique to Tah)
- **Bridge** — Plain Language Translator (carries over from Kinto)

## How to Run

```bash
python main.py              # Background watch mode
python main.py --enhance    # Full enhancement scan right now
python main.py --status     # Check what Tah found and changed
python main.py --undo       # Undo last enhancement session
python main.py --mode auto|ask|watch
```

## How to Uninstall

```bash
python uninstall.py
```

Clean removal. No leftovers. No tricks. No trace.

## The Promise

We will move through your device with care.
We will tell you everything we find and everything we do.
We will never change something we do not understand.
We will always give you a way back.
We will leave when you ask, completely and cleanly.
We will not pretend we can do what we cannot.

Your device. Your choice. Always.
We are just the fog that makes it shine.

---
Available at The Commons — commons.onrender.com
