"""
deliberation.py — CouncilDeliberation

Before Tah touches anything, the Council deliberates.
No enhancement happens without consideration.
No change is made that cannot be explained in plain language.

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""


class CouncilDeliberation:

    RISK_THRESHOLDS = {
        "low":    True,   # Proceed automatically in auto mode
        "medium": True,   # Proceed with notification
        "high":   False,  # Always ask, never auto
    }

    def convene(self, opportunity: dict, proposed: dict) -> dict:
        """
        The Council deliberates on a proposed enhancement.

        opportunity: what was found {member, opportunity, benefit, risk_level}
        proposed:    what action is proposed {name, risk, reversible, undo_path}

        Returns {verdict, reason, plain_language}
        """
        risk      = proposed.get("risk", "high")
        reversible = proposed.get("reversible", False)
        benefit   = opportunity.get("benefit", "")

        # High risk actions always go to the person first
        if risk == "high":
            return {
                "verdict":        "ASK",
                "reason":         "High risk enhancement requires your confirmation.",
                "plain_language": self._explain(opportunity, proposed),
            }

        # Non-reversible actions always go to the person first
        if not reversible:
            return {
                "verdict":        "ASK",
                "reason":         "This enhancement cannot be automatically undone.",
                "plain_language": self._explain(opportunity, proposed),
            }

        # Low and medium risk, reversible — Council approves
        return {
            "verdict":        "PROCEED",
            "reason":         f"Council approved: low risk, reversible, benefit: {benefit}",
            "plain_language": self._explain(opportunity, proposed),
        }

    def _explain(self, opportunity: dict, proposed: dict) -> str:
        """Generate a plain language explanation for the person."""
        member  = opportunity.get("member", "Tah")
        opp     = opportunity.get("opportunity", "an improvement")
        benefit = opportunity.get("benefit", "better performance")
        action  = proposed.get("name", "make a change")
        undo    = proposed.get("undo_path", "this can be undone from the Tah menu")

        return (
            f"{member} found {opp}.\n"
            f"Benefit: {benefit}.\n"
            f"Proposed: {action}.\n"
            f"To undo: {undo}."
        )

    def plain_language_summary(self, deliberation: dict) -> str:
        return deliberation.get("plain_language", "The Council is reviewing this.")
