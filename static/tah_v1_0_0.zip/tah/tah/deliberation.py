# SoGo9HRDMn29LBn6dj41jvn0AivfwKl8JnWRSjNOmrfUJZRkAjHOczqsS5fTU4SK
# Ta61hGef0ZVqKrmjYK7L7ECXV3wZiQrJGesJ18b3V8A6TRVpUC97mYbPXCkU3Sp1
""""""

class _tfgYbFKApOaP:
    _saEhcgmwpmaF = {'low': True, 'medium': True, 'high': False}

    def _aHJsLIeeosNv(self, _ukpxpYdpEQKV: dict, _rhQyKvispKrb: dict) -> dict:
        """"""
        _KMxmUHbNVNkG = _rhQyKvispKrb.get('risk', 'high')
        _UJEuCvtgEgjJ = _rhQyKvispKrb.get('reversible', False)
        _ublDlWgQEgTN = _ukpxpYdpEQKV.get('benefit', '')
        if _KMxmUHbNVNkG == 'high':
            return {'verdict': 'ASK', 'reason': 'High risk enhancement requires your confirmation.', 'plain_language': self._explain(_ukpxpYdpEQKV, _rhQyKvispKrb)}
        if not _UJEuCvtgEgjJ:
            return {'verdict': 'ASK', 'reason': 'This enhancement cannot be automatically undone.', 'plain_language': self._explain(_ukpxpYdpEQKV, _rhQyKvispKrb)}
        return {'verdict': 'PROCEED', 'reason': f'Council approved: low risk, reversible, benefit: {_ublDlWgQEgTN}', 'plain_language': self._explain(_ukpxpYdpEQKV, _rhQyKvispKrb)}

    def _RTZgAdTxqtXg(self, _ukpxpYdpEQKV: dict, _rhQyKvispKrb: dict) -> str:
        """"""
        _LbZdijwEqHiC = _ukpxpYdpEQKV.get('member', 'Tah')
        _SCiVdmIpuqSD = _ukpxpYdpEQKV.get('opportunity', 'an improvement')
        _ublDlWgQEgTN = _ukpxpYdpEQKV.get('benefit', 'better performance')
        _sxooXUdKscOS = _rhQyKvispKrb.get('name', 'make a change')
        _rNLxbTYWZlOr = _rhQyKvispKrb.get('undo_path', 'this can be undone from the Tah menu')
        return f'{_LbZdijwEqHiC} found {_SCiVdmIpuqSD}.\nBenefit: {_ublDlWgQEgTN}.\nProposed: {_sxooXUdKscOS}.\nTo undo: {_rNLxbTYWZlOr}.'

    def _AqBfbxmoTTyq(self, _WYbumbNIMHwj: dict) -> str:
        return _WYbumbNIMHwj.get('plain_language', 'The Council is reviewing this.')