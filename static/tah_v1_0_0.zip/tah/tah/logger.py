# TiakOYzf4fruWjI9u9o5jRmQwusCsqQrfSkE7kaOIBZ2fYcmc5Rs6Y4x6GaSEhWt
# QhA9ihFNJAbfVogHwBXOJM9Z6XSp4Tx1SGxLY2yCfdLicpPAgnDUemXIAgWcfAgD
""""""
import json
import os
from datetime import datetime

class _MllVNMGNJJZt:
    _SliYksIAsvMc = 'tah_audit.log'
    _cHFvsuBqqJpW = 10000

    def _RAoZZeHblEWE(self, _qPXVWRTRagkw: str, _xqCRquoDvQoo: str, _DgyTTjpTFGJL: str, _XfOSFjMnTUtX: str='ok'):
        _SuDHAEpANHwm = {'time': datetime.now().isoformat(), 'member': _qPXVWRTRagkw, 'action': _xqCRquoDvQoo, 'detail': _DgyTTjpTFGJL, 'status': _XfOSFjMnTUtX}
        try:
            with open(self.LOG_FILE, 'a') as _XJlKqBdFpZIY:
                _XJlKqBdFpZIY.write(json.dumps(_SuDHAEpANHwm) + '\n')
        except Exception:
            pass

    def _nPJzUegMdJIi(self, _QlsjXXgMCZIj: int=20) -> list:
        """"""
        _xsLRDBmKIAIs = []
        try:
            if os.path.exists(self.LOG_FILE):
                with open(self.LOG_FILE) as _XJlKqBdFpZIY:
                    for _rIaQdyqlVjQq in _XJlKqBdFpZIY:
                        try:
                            _xsLRDBmKIAIs.append(json.loads(_rIaQdyqlVjQq))
                        except Exception:
                            pass
        except Exception:
            pass
        return _xsLRDBmKIAIs[-_QlsjXXgMCZIj:]

    def _hROGjYWIIolW(self) -> list:
        """"""
        _xsLRDBmKIAIs = []
        try:
            if os.path.exists(self.LOG_FILE):
                with open(self.LOG_FILE) as _XJlKqBdFpZIY:
                    for _rIaQdyqlVjQq in _XJlKqBdFpZIY:
                        try:
                            _OmStWvCNEKVI = json.loads(_rIaQdyqlVjQq)
                            if _OmStWvCNEKVI.get('action', '').startswith('enhanced'):
                                _xsLRDBmKIAIs.append(_OmStWvCNEKVI)
                        except Exception:
                            pass
        except Exception:
            pass
        return _xsLRDBmKIAIs