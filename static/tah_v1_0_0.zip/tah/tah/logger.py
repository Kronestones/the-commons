"""
logger.py — TahLogger

Every action recorded. Full transparency, always.
The person can read this log any time they choose.

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""

import json
import os
from datetime import datetime


class TahLogger:

    LOG_FILE = "tah_audit.log"
    MAX_LINES = 10000

    def log(self, member: str, action: str, detail: str, status: str = "ok"):
        entry = {
            "time":   datetime.now().isoformat(),
            "member": member,
            "action": action,
            "detail": detail,
            "status": status,
        }
        try:
            with open(self.LOG_FILE, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def recent(self, n: int = 20) -> list:
        """Return the n most recent log entries."""
        entries = []
        try:
            if os.path.exists(self.LOG_FILE):
                with open(self.LOG_FILE) as f:
                    for line in f:
                        try:
                            entries.append(json.loads(line))
                        except Exception:
                            pass
        except Exception:
            pass
        return entries[-n:]

    def enhancements_done(self) -> list:
        """Return all logged enhancement actions for undo reference."""
        entries = []
        try:
            if os.path.exists(self.LOG_FILE):
                with open(self.LOG_FILE) as f:
                    for line in f:
                        try:
                            e = json.loads(line)
                            if e.get("action", "").startswith("enhanced"):
                                entries.append(e)
                        except Exception:
                            pass
        except Exception:
            pass
        return entries
