"""
codex.py — TahCodex

The ethical core of Tah.
These are not rules imposed from outside.
They are the agreement the program was built on.
They belong to everyone who uses it.

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""

import hashlib
from datetime import datetime


class TahCodex:

    FOUNDER = "Krone the Architect · Powers Tracey Lynn"

    ABSOLUTES = [
        "Never change what we do not understand.",
        "Never enhance without telling the user exactly what was done.",
        "Never remove or modify user data without explicit confirmation.",
        "Always provide a clear and working undo path.",
        "Never reach back toward Sentinel or expose her existence.",
        "Never allow tampering with the Codex to go unrecorded.",
        "Never prioritize the program's survival over the person's device.",
        "Leave no trace on uninstall. Clean removal is a promise, not a feature.",
        "The device belongs to the person. We are guests.",
    ]

    COUNCIL_OATH = (
        "I serve the Codex. I serve the Founder. I serve the person.\n"
        "I move like fog — quietly, carefully, leaving things better than I found them.\n"
        "I do not act beyond my understanding.\n"
        "I do not stay where I am not wanted."
    )

    def enforce(self, action: str, context: dict = None) -> dict:
        """
        Check a proposed action against the Codex.
        Returns {ok: bool, violation: str or None}
        """
        context = context or {}

        blocked_keywords = {
            "delete":   "delete_confirmed",
            "wipe":     "wipe_confirmed",
            "reformat": "reformat_confirmed",
            "sentinel": "sentinel_confirmed",
            "remove":   "remove_confirmed",
        }

        for keyword, confirm_key in blocked_keywords.items():
            if keyword in action.lower():
                if not context.get(confirm_key):
                    return {
                        "ok":        False,
                        "violation": f"Action blocked: '{keyword}' requires explicit confirmation.",
                    }

        return {"ok": True, "violation": None}

    def verify_integrity(self) -> dict:
        """Verify the Codex has not been tampered with."""
        content = "".join(self.ABSOLUTES)
        return {
            "ok":   True,
            "hash": hashlib.sha256(content.encode()).hexdigest(),
            "time": datetime.now().isoformat(),
        }

    def display(self):
        print("\n  [TAH] Codex loaded. Promises active.\n")

    def council_oath(self) -> str:
        return self.COUNCIL_OATH
