"""
report.py — TahReport

Every session documented. Full transparency.
The person can read exactly what Tah did and why.

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""

import os
from datetime import datetime


class TahReport:

    def __init__(self):
        self._scan_data    = {}
        self._enhancements = []

    def load_from_scan(self, scan_data: dict, enhancements: list):
        self._scan_data    = scan_data
        self._enhancements = enhancements

    def generate(self, fmt: str = "txt") -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename  = f"Tah_Report_{timestamp}.txt"

        opportunities = self._scan_data.get("opportunities", [])
        system        = self._scan_data.get("system", "Unknown")
        done          = [e for e in self._enhancements if e and e.get("ok")]
        skipped       = [e for e in self._enhancements if e and not e.get("ok")]

        lines = [
            "╔══════════════════════════════════════════════════════════╗",
            "║            T A H   —   Enhancement Report               ║",
            "╚══════════════════════════════════════════════════════════╝",
            "",
            f"  Date:    {datetime.now().strftime('%B %d, %Y at %I:%M %p')}",
            f"  System:  {system}",
            f"  Found:   {len(opportunities)} opportunity/ies",
            f"  Done:    {len(done)} enhancement(s) applied",
            f"  Skipped: {len(skipped)} skipped or held",
            "",
            "  ──────────────────────────────────────────────────────────",
            "  WHAT TAH FOUND",
            "  ──────────────────────────────────────────────────────────",
            "",
        ]

        if opportunities:
            for opp in opportunities:
                lines.append(f"  [{opp.get('member', 'Tah')}] {opp.get('opportunity', '')}")
                if opp.get("benefit"):
                    lines.append(f"    Benefit: {opp['benefit']}")
                lines.append("")
        else:
            lines.append("  Nothing to enhance. Your device is running well.")
            lines.append("")

        lines += [
            "  ──────────────────────────────────────────────────────────",
            "  WHAT TAH DID",
            "  ──────────────────────────────────────────────────────────",
            "",
        ]

        if done:
            for e in done:
                lines.append(f"  ✓  {e.get('desc', 'Enhancement applied.')}")
                if e.get("undo"):
                    lines.append(f"     To undo: {e['undo']}")
                lines.append("")
        else:
            lines.append("  No changes were made this session.")
            lines.append("")

        lines += [
            "  ──────────────────────────────────────────────────────────",
            "",
            "  Tah — Device enhancement for everyone.",
            "  Founded by Krone the Architect · Powers Tracey Lynn",
            "  Available at The Commons — commons.onrender.com",
            "",
            "  Run  python main.py --undo  to reverse this session.",
            "",
        ]

        try:
            with open(filename, "w") as f:
                f.write("\n".join(lines))
        except Exception:
            pass

        return filename
