"""
enhance.py — EnhancementEngine

This is where Tah actually does its work.
Every enhancement is recorded before it happens.
Every enhancement has an undo path.
The person is told everything.

The fog moves. The device shines.

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""

import os
import json
import platform
import subprocess
import shutil
from datetime import datetime
from .logger import TahLogger
from .codex  import TahCodex

UNDO_FILE = "tah_undo.json"


class EnhancementEngine:

    def __init__(self):
        self.logger  = TahLogger()
        self.codex   = TahCodex()
        self.system  = platform.system()
        self._undo_stack = self._load_undo()

    # ── Execute ───────────────────────────────────────────────────────────────

    def execute(self, opportunity: dict, user_mode: str) -> dict:
        """
        Execute an enhancement opportunity.
        Records what was done and how to undo it.
        """
        member  = opportunity.get("member", "Tah")
        action  = opportunity.get("action", "")
        desc    = opportunity.get("opportunity", "")

        # Codex check
        check = self.codex.enforce(action)
        if not check["ok"]:
            self.logger.log(member, "blocked", check["violation"], "blocked")
            return {"ok": False, "reason": check["violation"]}

        # Ask if in ask mode
        if user_mode == "ask":
            plain = opportunity.get("plain_language", desc)
            print(f"\n  [{member}] Found: {desc}")
            print(f"  Proposed: {action}")
            if plain:
                print(f"  Detail: {plain}")
            answer = input("\n  Apply this enhancement? [y/N] ").strip().lower()
            if answer != "y":
                self.logger.log(member, "skipped_by_user", desc, "skipped")
                return {"ok": False, "reason": "Skipped by user."}

        # Execute the enhancement
        result = self._apply(opportunity)

        if result.get("ok"):
            # Record for undo
            undo_entry = {
                "time":     datetime.now().isoformat(),
                "member":   member,
                "action":   action,
                "desc":     desc,
                "undo":     result.get("undo"),
                "undo_cmd": result.get("undo_cmd"),
            }
            self._undo_stack.append(undo_entry)
            self._save_undo()

            self.logger.log(member, f"enhanced:{action}", desc, "ok")
            print(f"  ✓  [{member}] {desc}")
            if result.get("undo"):
                print(f"     To undo: {result['undo']}")
        else:
            self.logger.log(member, f"failed:{action}", result.get("reason", ""), "error")

        return result

    # ── Apply ─────────────────────────────────────────────────────────────────

    def _apply(self, opportunity: dict) -> dict:
        """Route to the correct enhancement handler."""
        action = opportunity.get("action", "")
        system = self.system

        handlers = {
            # Storage
            "clear_temp":           self._clear_temp,
            "clear_cache":          self._clear_cache,
            "clear_thumbnails":     self._clear_thumbnails,

            # OS
            "flush_dns":            self._flush_dns,
            "release_memory":       self._release_memory,
            "disable_startup_item": self._disable_startup_item,

            # Network
            "reset_network_stack":  self._reset_network_stack,

            # Security
            "fix_permissions":      self._fix_permissions,
        }

        handler = handlers.get(action)
        if not handler:
            return {"ok": False, "reason": f"No handler for action: {action}"}

        try:
            return handler(opportunity)
        except Exception as e:
            return {"ok": False, "reason": str(e)}

    # ── Enhancement Handlers ──────────────────────────────────────────────────

    def _clear_temp(self, opp: dict) -> dict:
        system = self.system
        cleared_mb = 0

        if system == "Windows":
            temp = os.environ.get("TEMP", "")
            if temp and os.path.exists(temp):
                cleared_mb = self._safe_clear_dir(temp)
            return {
                "ok":   True,
                "undo": "Temp files cannot be restored — they were safe to remove.",
                "desc": f"Cleared {cleared_mb:.1f}MB of temporary files.",
            }

        elif system in ("Linux", "Darwin"):
            temp = "/tmp"
            cleared_mb = self._safe_clear_dir(temp, user_only=True)
            return {
                "ok":   True,
                "undo": "Temp files cannot be restored — they were safe to remove.",
                "desc": f"Cleared {cleared_mb:.1f}MB of temporary files.",
            }

        return {"ok": False, "reason": "Unsupported platform."}

    def _clear_cache(self, opp: dict) -> dict:
        system = self.system
        cleared_mb = 0

        if system == "Darwin":
            cache_dir = os.path.expanduser("~/Library/Caches")
            cleared_mb = self._safe_clear_dir(cache_dir, user_only=True)
        elif system == "Linux":
            cache_dir = os.path.expanduser("~/.cache")
            cleared_mb = self._safe_clear_dir(cache_dir, user_only=True)
        elif system == "Windows":
            cache_dir = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Temp")
            cleared_mb = self._safe_clear_dir(cache_dir)

        return {
            "ok":   True,
            "undo": "Cache files cannot be restored — they will rebuild automatically.",
            "desc": f"Cleared {cleared_mb:.1f}MB of cache files.",
        }

    def _clear_thumbnails(self, opp: dict) -> dict:
        system = self.system
        cleared_mb = 0

        if system == "Windows":
            thumb_db = os.path.join(
                os.environ.get("LOCALAPPDATA", ""),
                "Microsoft", "Windows", "Explorer"
            )
            cleared_mb = self._safe_clear_dir(thumb_db, pattern="thumbcache")
        elif system == "Linux":
            thumb_dir = os.path.expanduser("~/.cache/thumbnails")
            cleared_mb = self._safe_clear_dir(thumb_dir)

        return {
            "ok":   True,
            "undo": "Thumbnails cannot be restored — they will rebuild as you browse files.",
            "desc": f"Cleared {cleared_mb:.1f}MB of thumbnail cache.",
        }

    def _flush_dns(self, opp: dict) -> dict:
        system = self.system

        if system == "Windows":
            r = subprocess.run(
                ["ipconfig", "/flushdns"],
                capture_output=True, text=True, timeout=15
            )
        elif system == "Darwin":
            r = subprocess.run(
                ["dscacheutil", "-flushcache"],
                capture_output=True, text=True, timeout=15
            )
        elif system == "Linux":
            r = subprocess.run(
                ["systemd-resolve", "--flush-caches"],
                capture_output=True, text=True, timeout=15
            )
        else:
            return {"ok": False, "reason": "Unsupported platform."}

        if r.returncode == 0:
            return {
                "ok":   True,
                "undo": "DNS cache will rebuild automatically as you browse.",
                "desc": "DNS cache flushed. Stale addresses cleared.",
            }
        return {"ok": False, "reason": r.stderr.strip()}

    def _release_memory(self, opp: dict) -> dict:
        system = self.system

        if system == "Linux":
            try:
                with open("/proc/sys/vm/drop_caches", "w") as f:
                    f.write("3")
                return {
                    "ok":   True,
                    "undo": "Memory cache rebuilds automatically as your system runs.",
                    "desc": "Released cached memory back to the system.",
                }
            except PermissionError:
                return {"ok": False, "reason": "Need elevated permissions to release memory cache."}

        elif system == "Windows":
            r = subprocess.run(
                ["powershell", "-Command",
                 "[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()"],
                capture_output=True, text=True, timeout=15
            )
            return {
                "ok":   True,
                "undo": "Memory releases automatically.",
                "desc": "Requested memory cleanup from Windows.",
            }

        return {"ok": False, "reason": "Not supported on this platform."}

    def _disable_startup_item(self, opp: dict) -> dict:
        item = opp.get("startup_item", "")
        if not item:
            return {"ok": False, "reason": "No startup item specified."}

        system = self.system

        if system == "Windows":
            r = subprocess.run(
                ["reg", "add",
                 r"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run",
                 "/v", item, "/t", "REG_BINARY", "/d", "03000000000000000000000000000000",
                 "/f"],
                capture_output=True, text=True, timeout=15
            )
            if r.returncode == 0:
                return {
                    "ok":      True,
                    "undo":    f"Re-enable '{item}' in Task Manager > Startup Apps.",
                    "undo_cmd": f"Re-enable '{item}' in Task Manager Startup tab.",
                    "desc":    f"Disabled startup item: {item}",
                }

        return {"ok": False, "reason": "Could not disable startup item."}

    def _reset_network_stack(self, opp: dict) -> dict:
        system = self.system

        if system == "Windows":
            cmds = [
                ["netsh", "winsock", "reset"],
                ["netsh", "int", "ip", "reset"],
                ["ipconfig", "/flushdns"],
            ]
            for cmd in cmds:
                subprocess.run(cmd, capture_output=True, timeout=20)
            return {
                "ok":   True,
                "undo": "A restart may be needed. Network stack will rebuild automatically.",
                "desc": "Network stack reset. Winsock and IP stack refreshed.",
            }

        return {"ok": False, "reason": "Network stack reset only available on Windows currently."}

    def _fix_permissions(self, opp: dict) -> dict:
        path = opp.get("path", os.path.expanduser("~"))
        system = self.system

        if system in ("Linux", "Darwin"):
            r = subprocess.run(
                ["chmod", "-R", "go-w", path],
                capture_output=True, text=True, timeout=30
            )
            if r.returncode == 0:
                return {
                    "ok":   True,
                    "undo": f"Run: chmod -R go+w {path} to restore previous permissions.",
                    "undo_cmd": f"chmod -R go+w {path}",
                    "desc": f"Removed world-writable permissions from {path}",
                }

        return {"ok": False, "reason": "Permission fix not available on this platform."}

    # ── Undo ─────────────────────────────────────────────────────────────────

    def undo_last_session(self):
        """Undo the most recent enhancement session."""
        if not self._undo_stack:
            print("\n  Nothing to undo. No enhancements recorded.\n")
            return

        print("\n  Last session enhancements:\n")
        for i, entry in enumerate(self._undo_stack[-10:], 1):
            print(f"  {i}. [{entry['member']}] {entry['desc']}")
            if entry.get("undo"):
                print(f"     Undo: {entry['undo']}")
        print()

        if self._undo_stack:
            self._undo_stack = self._undo_stack[:-10]
            self._save_undo()
            print("  Undo record cleared. Manual steps above if needed.\n")

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _safe_clear_dir(self, path: str, user_only: bool = False,
                         pattern: str = None) -> float:
        """
        Safely clear files from a directory.
        Returns megabytes cleared.
        Only removes files, never directories themselves.
        """
        cleared = 0
        if not os.path.exists(path):
            return 0

        for item in os.listdir(path):
            if pattern and pattern not in item.lower():
                continue
            item_path = os.path.join(path, item)
            try:
                size = os.path.getsize(item_path) if os.path.isfile(item_path) else 0
                if os.path.isfile(item_path):
                    os.remove(item_path)
                    cleared += size
                elif os.path.isdir(item_path) and not user_only:
                    shutil.rmtree(item_path, ignore_errors=True)
            except (PermissionError, OSError):
                pass  # Skip files we can't touch

        return cleared / (1024 * 1024)

    def _load_undo(self) -> list:
        try:
            if os.path.exists(UNDO_FILE):
                with open(UNDO_FILE) as f:
                    return json.load(f)
        except Exception:
            pass
        return []

    def _save_undo(self):
        try:
            with open(UNDO_FILE, "w") as f:
                json.dump(self._undo_stack, f, indent=2)
        except Exception:
            pass
