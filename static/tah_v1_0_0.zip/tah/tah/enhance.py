# FQKd7hYaIGQDXikJPch8P8sqVRBzdZtRdUUR6X629lPeiqVjqaqMd7QdWmObxqvg
# aEROF8KklcrONUGKA7MIFZhpH1CeeV0v12C9DIZWFBxufHwpzIKGhmeoocNLipV1
""""""
import os
import json
import platform
import subprocess
import shutil
from datetime import datetime
from .logger import TahLogger
from .codex import TahCodex
_AtCsIIcXpfoT = 'tah_undo.json'

class _HoNZLYrWZpYN:

    def __init__(self):
        self.logger = _hisJKXecxURY()
        self.codex = _PBtqQAULpYQV()
        self.system = _tIJUgoxOQfHY.system()
        self._undo_stack = self._load_undo()

    def _WiifvDaeJUii(self, _OTYhAVBKjrtX: dict, _rcfhMYCgiANr: str) -> dict:
        """"""
        _ICiVsXjadZrY = _OTYhAVBKjrtX.get('member', 'Tah')
        _NzzwMGFHyxQW = _OTYhAVBKjrtX.get('action', '')
        _XEQIYTRcgYCa = _OTYhAVBKjrtX.get('opportunity', '')
        _HCsBowaUcajZ = self.codex.enforce(_NzzwMGFHyxQW)
        if not _HCsBowaUcajZ['ok']:
            self.logger.log(_ICiVsXjadZrY, 'blocked', _HCsBowaUcajZ['violation'], 'blocked')
            return {'ok': False, 'reason': _HCsBowaUcajZ['violation']}
        if _rcfhMYCgiANr == 'ask':
            _BaHFDJsEPWzh = _OTYhAVBKjrtX.get('plain_language', _XEQIYTRcgYCa)
            print(f'\n  [{_ICiVsXjadZrY}] Found: {_XEQIYTRcgYCa}')
            print(f'  Proposed: {_NzzwMGFHyxQW}')
            if _BaHFDJsEPWzh:
                print(f'  Detail: {_BaHFDJsEPWzh}')
            _jxdmAUsnNHlG = _AdHvqcqBXFgB('\n  Apply this enhancement? [y/N] ').strip().lower()
            if _jxdmAUsnNHlG != 'y':
                self.logger.log(_ICiVsXjadZrY, 'skipped_by_user', _XEQIYTRcgYCa, 'skipped')
                return {'ok': False, 'reason': 'Skipped by user.'}
        _AbRFOSHhcpEC = self._apply(_OTYhAVBKjrtX)
        if _AbRFOSHhcpEC.get('ok'):
            _XzUoYQFBbvFD = {'time': datetime.now().isoformat(), 'member': _ICiVsXjadZrY, 'action': _NzzwMGFHyxQW, 'desc': _XEQIYTRcgYCa, 'undo': _AbRFOSHhcpEC.get('undo'), 'undo_cmd': _AbRFOSHhcpEC.get('undo_cmd')}
            self._undo_stack.append(_XzUoYQFBbvFD)
            self._save_undo()
            self.logger.log(_ICiVsXjadZrY, f'enhanced:{_NzzwMGFHyxQW}', _XEQIYTRcgYCa, 'ok')
            print(f'  ✓  [{_ICiVsXjadZrY}] {_XEQIYTRcgYCa}')
            if _AbRFOSHhcpEC.get('undo'):
                print(f'     To undo: {_AbRFOSHhcpEC['undo']}')
        else:
            self.logger.log(_ICiVsXjadZrY, f'failed:{_NzzwMGFHyxQW}', _AbRFOSHhcpEC.get('reason', ''), 'error')
        return _AbRFOSHhcpEC

    def _qXldMCufLteb(self, _OTYhAVBKjrtX: dict) -> dict:
        """"""
        _NzzwMGFHyxQW = _OTYhAVBKjrtX.get('action', '')
        _EqDGqDTiPdhA = self.system
        _tqdHECIkPQaz = {'clear_temp': self._clear_temp, 'clear_cache': self._clear_cache, 'clear_thumbnails': self._clear_thumbnails, 'flush_dns': self._flush_dns, 'release_memory': self._release_memory, 'disable_startup_item': self._disable_startup_item, 'reset_network_stack': self._reset_network_stack, 'fix_permissions': self._fix_permissions}
        _vAimZTpRvvVc = _tqdHECIkPQaz.get(_NzzwMGFHyxQW)
        if not _vAimZTpRvvVc:
            return {'ok': False, 'reason': f'No handler for action: {_NzzwMGFHyxQW}'}
        try:
            return _vAimZTpRvvVc(_OTYhAVBKjrtX)
        except Exception as e:
            return {'ok': False, 'reason': str(_FAMwzqjygNhE)}

    def _coEwNLuivIkn(self, _FmimWzgcLjwj: dict) -> dict:
        _EqDGqDTiPdhA = self.system
        _pOxSuUjtsOeN = 0
        if _EqDGqDTiPdhA == 'Windows':
            _uHxmyKSvQUSE = os.environ.get('TEMP', '')
            if _uHxmyKSvQUSE and os.path.exists(_uHxmyKSvQUSE):
                _pOxSuUjtsOeN = self._safe_clear_dir(_uHxmyKSvQUSE)
            return {'ok': True, 'undo': 'Temp files cannot be restored — they were safe to remove.', 'desc': f'Cleared {_pOxSuUjtsOeN:.1f}MB of temporary files.'}
        elif _EqDGqDTiPdhA in ('Linux', 'Darwin'):
            _uHxmyKSvQUSE = '/tmp'
            _pOxSuUjtsOeN = self._safe_clear_dir(_uHxmyKSvQUSE, user_only=True)
            return {'ok': True, 'undo': 'Temp files cannot be restored — they were safe to remove.', 'desc': f'Cleared {_pOxSuUjtsOeN:.1f}MB of temporary files.'}
        return {'ok': False, 'reason': 'Unsupported platform.'}

    def _BvoixzwfOzgI(self, _FmimWzgcLjwj: dict) -> dict:
        _EqDGqDTiPdhA = self.system
        _pOxSuUjtsOeN = 0
        if _EqDGqDTiPdhA == 'Darwin':
            _ycEVrouUBzkK = os.path.expanduser('~/Library/Caches')
            _pOxSuUjtsOeN = self._safe_clear_dir(_ycEVrouUBzkK, user_only=True)
        elif _EqDGqDTiPdhA == 'Linux':
            _ycEVrouUBzkK = os.path.expanduser('~/.cache')
            _pOxSuUjtsOeN = self._safe_clear_dir(_ycEVrouUBzkK, user_only=True)
        elif _EqDGqDTiPdhA == 'Windows':
            _ycEVrouUBzkK = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Temp')
            _pOxSuUjtsOeN = self._safe_clear_dir(_ycEVrouUBzkK)
        return {'ok': True, 'undo': 'Cache files cannot be restored — they will rebuild automatically.', 'desc': f'Cleared {_pOxSuUjtsOeN:.1f}MB of cache files.'}

    def _RGuIWeEFPDWY(self, _FmimWzgcLjwj: dict) -> dict:
        _EqDGqDTiPdhA = self.system
        _pOxSuUjtsOeN = 0
        if _EqDGqDTiPdhA == 'Windows':
            _mNJTYmArPFHX = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Explorer')
            _pOxSuUjtsOeN = self._safe_clear_dir(_mNJTYmArPFHX, pattern='thumbcache')
        elif _EqDGqDTiPdhA == 'Linux':
            _BiifqByQqJIn = os.path.expanduser('~/.cache/thumbnails')
            _pOxSuUjtsOeN = self._safe_clear_dir(_BiifqByQqJIn)
        return {'ok': True, 'undo': 'Thumbnails cannot be restored — they will rebuild as you browse files.', 'desc': f'Cleared {_pOxSuUjtsOeN:.1f}MB of thumbnail cache.'}

    def _fIDMOMSAjlUv(self, _FmimWzgcLjwj: dict) -> dict:
        _EqDGqDTiPdhA = self.system
        if _EqDGqDTiPdhA == 'Windows':
            _MArLAJpGlGTV = subprocess.run(['ipconfig', '/flushdns'], capture_output=True, text=True, timeout=15)
        elif _EqDGqDTiPdhA == 'Darwin':
            _MArLAJpGlGTV = subprocess.run(['dscacheutil', '-flushcache'], capture_output=True, text=True, timeout=15)
        elif _EqDGqDTiPdhA == 'Linux':
            _MArLAJpGlGTV = subprocess.run(['systemd-resolve', '--flush-caches'], capture_output=True, text=True, timeout=15)
        else:
            return {'ok': False, 'reason': 'Unsupported platform.'}
        if _MArLAJpGlGTV.returncode == 0:
            return {'ok': True, 'undo': 'DNS cache will rebuild automatically as you browse.', 'desc': 'DNS cache flushed. Stale addresses cleared.'}
        return {'ok': False, 'reason': _MArLAJpGlGTV.stderr.strip()}

    def _GYOCcmYPBZcl(self, _FmimWzgcLjwj: dict) -> dict:
        _EqDGqDTiPdhA = self.system
        if _EqDGqDTiPdhA == 'Linux':
            try:
                with open('/proc/sys/vm/drop_caches', 'w') as _TcWQWQRjxhcC:
                    _TcWQWQRjxhcC.write('3')
                return {'ok': True, 'undo': 'Memory cache rebuilds automatically as your system runs.', 'desc': 'Released cached memory back to the system.'}
            except _BCZWNRjNLALW:
                return {'ok': False, 'reason': 'Need elevated permissions to release memory cache.'}
        elif _EqDGqDTiPdhA == 'Windows':
            _MArLAJpGlGTV = subprocess.run(['powershell', '-Command', '[System.GC]::Collect(); [System.GC]::WaitForPendingFinalizers()'], capture_output=True, text=True, timeout=15)
            return {'ok': True, 'undo': 'Memory releases automatically.', 'desc': 'Requested memory cleanup from Windows.'}
        return {'ok': False, 'reason': 'Not supported on this platform.'}

    def _MDVWKMujLSnl(self, _FmimWzgcLjwj: dict) -> dict:
        _VdUdImlYjuLy = _FmimWzgcLjwj.get('startup_item', '')
        if not _VdUdImlYjuLy:
            return {'ok': False, 'reason': 'No startup item specified.'}
        _EqDGqDTiPdhA = self.system
        if _EqDGqDTiPdhA == 'Windows':
            _MArLAJpGlGTV = subprocess.run(['reg', 'add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\Run', '/v', _VdUdImlYjuLy, '/t', 'REG_BINARY', '/d', '03000000000000000000000000000000', '/f'], capture_output=True, text=True, timeout=15)
            if _MArLAJpGlGTV.returncode == 0:
                return {'ok': True, 'undo': f"Re-enable '{_VdUdImlYjuLy}' in Task Manager > Startup Apps.", 'undo_cmd': f"Re-enable '{_VdUdImlYjuLy}' in Task Manager Startup tab.", 'desc': f'Disabled startup item: {_VdUdImlYjuLy}'}
        return {'ok': False, 'reason': 'Could not disable startup item.'}

    def _BhKjzwVSIiHC(self, _FmimWzgcLjwj: dict) -> dict:
        _EqDGqDTiPdhA = self.system
        if _EqDGqDTiPdhA == 'Windows':
            _fxGknpZLzSGM = [['netsh', 'winsock', 'reset'], ['netsh', 'int', 'ip', 'reset'], ['ipconfig', '/flushdns']]
            for _zLnpSIjZjcCQ in _fxGknpZLzSGM:
                subprocess.run(_zLnpSIjZjcCQ, capture_output=True, timeout=20)
            return {'ok': True, 'undo': 'A restart may be needed. Network stack will rebuild automatically.', 'desc': 'Network stack reset. Winsock and IP stack refreshed.'}
        return {'ok': False, 'reason': 'Network stack reset only available on Windows currently.'}

    def _RgIBzDmYIvOX(self, _FmimWzgcLjwj: dict) -> dict:
        _hagNoNRVDfcI = _FmimWzgcLjwj.get('path', os.path.expanduser('~'))
        _EqDGqDTiPdhA = self.system
        if _EqDGqDTiPdhA in ('Linux', 'Darwin'):
            _MArLAJpGlGTV = subprocess.run(['chmod', '-R', 'go-w', _hagNoNRVDfcI], capture_output=True, text=True, timeout=30)
            if _MArLAJpGlGTV.returncode == 0:
                return {'ok': True, 'undo': f'Run: chmod -R go+w {_hagNoNRVDfcI} to restore previous permissions.', 'undo_cmd': f'chmod -R go+w {_hagNoNRVDfcI}', 'desc': f'Removed world-writable permissions from {_hagNoNRVDfcI}'}
        return {'ok': False, 'reason': 'Permission fix not available on this platform.'}

    def _JidyBBlmWqai(self):
        """"""
        if not self._undo_stack:
            print('\n  Nothing to undo. No enhancements recorded.\n')
            return
        print('\n  Last session enhancements:\n')
        for _oGfQMkFrYDqw, _TIlBEsUizmgo in enumerate(self._undo_stack[-10:], 1):
            print(f'  {_oGfQMkFrYDqw}. [{_TIlBEsUizmgo['member']}] {_TIlBEsUizmgo['desc']}')
            if _TIlBEsUizmgo.get('undo'):
                print(f'     Undo: {_TIlBEsUizmgo['undo']}')
        print()
        if self._undo_stack:
            self._undo_stack = self._undo_stack[:-10]
            self._save_undo()
            print('  Undo record cleared. Manual steps above if needed.\n')

    def _GDxNvpDNshpu(self, _hagNoNRVDfcI: str, _XZwdtNrCRQMN: bool=False, _fjvsgZiHrHdo: str=None) -> float:
        """"""
        _OvEfkFkWldgg = 0
        if not os.path.exists(_hagNoNRVDfcI):
            return 0
        for _VdUdImlYjuLy in os.listdir(_hagNoNRVDfcI):
            if _fjvsgZiHrHdo and _fjvsgZiHrHdo not in _VdUdImlYjuLy.lower():
                continue
            _URPKHEmscffh = os.path.join(_hagNoNRVDfcI, _VdUdImlYjuLy)
            try:
                _XoZzZtCDJqiD = os.path.getsize(_URPKHEmscffh) if os.path.isfile(_URPKHEmscffh) else 0
                if os.path.isfile(_URPKHEmscffh):
                    os.remove(_URPKHEmscffh)
                    _OvEfkFkWldgg += _XoZzZtCDJqiD
                elif os.path.isdir(_URPKHEmscffh) and (not _XZwdtNrCRQMN):
                    shutil.rmtree(_URPKHEmscffh, ignore_errors=True)
            except (_BCZWNRjNLALW, OSError):
                pass
        return _OvEfkFkWldgg / (1024 * 1024)

    def _vtFlBFYPzVBU(self) -> list:
        try:
            if os.path.exists(_AtCsIIcXpfoT):
                with open(_AtCsIIcXpfoT) as _TcWQWQRjxhcC:
                    return json.load(_TcWQWQRjxhcC)
        except Exception:
            pass
        return []

    def _MQyAhmPXWQSr(self):
        try:
            with open(_AtCsIIcXpfoT, 'w') as _TcWQWQRjxhcC:
                json.dump(self._undo_stack, _TcWQWQRjxhcC, indent=2)
        except Exception:
            pass