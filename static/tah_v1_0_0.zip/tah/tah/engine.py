"""
engine.py — TahEngine

The heartbeat of the whole operation.
Everything flows through here.

Modes:
  watch   — background monitoring, acts based on user_mode setting
  enhance — full enhancement scan right now
  silent  — start but don't print, used for --status

Founded by Krone the Architect · Powers Tracey Lynn
Tah Enhancement Council · 2026
"""

import os
import sys
import time
import json
import platform
import threading
import subprocess
import shutil
from datetime import datetime

from .codex         import TahCodex
from .logger        import TahLogger
from .deliberation  import CouncilDeliberation
from .enhance       import EnhancementEngine
from .report        import TahReport


SETTINGS_FILE    = "tah_settings.json"
DEFAULT_SETTINGS = {
    "user_mode":       "ask",
    "scan_interval_s": 3600,
    "last_scan":       None,
    "version":         "1.0.0",
    "notifications":   True,
}


class TahEngine:

    VERSION = "1.0.0"

    def __init__(self):
        self.codex       = TahCodex()
        self.logger      = TahLogger()
        self.council     = CouncilDeliberation()
        self.enhance     = EnhancementEngine()
        self.report      = TahReport()
        self.settings    = self._load_settings()
        self._running    = False
        self._mode       = None
        self._system     = platform.system()

    # ── Start ─────────────────────────────────────────────────────────────────

    def start(self, mode: str = "watch") -> bool:
        self._mode = mode

        if mode != "silent":
            self._print_banner()

        self.codex.display()
        self.logger.log("ENGINE", "start", f"mode={mode} system={self._system}", "ok")

        if mode == "enhance":
            return self._run_full_enhance()
        elif mode == "watch":
            return self._start_watch()
        elif mode == "silent":
            return True

        return False

    # ── Full Enhancement Scan ─────────────────────────────────────────────────

    def _run_full_enhance(self) -> bool:
        print("\n  Tah is moving through your device.\n")
        print("  Quiet. Careful. Nothing will be changed")
        print("  without your knowledge.\n")
        print("  ─────────────────────────────────────────────────\n")

        opportunities = []
        system        = self._system

        # Each council member scans their domain
        opportunities += self._lux_scan(system)
        opportunities += self._stratum_scan(system)
        opportunities += self._flow_scan(system)
        opportunities += self._vault_scan(system)
        opportunities += self._aegis_scan(system)
        opportunities += self._bloom_scan(system)

        self.settings["last_scan"] = datetime.now().isoformat()
        self._save_settings()

        self.logger.log(
            "ENGINE", "scan_complete",
            f"Found {len(opportunities)} opportunity/ies on {system}", "ok"
        )

        if not opportunities:
            print("\n  ✓  Your device is already running well.\n")
            print("  Tah found nothing to enhance right now.\n")
            self._print_footer()
            return True

        print(f"\n  Found {len(opportunities)} enhancement opportunity/ies:\n")
        for i, o in enumerate(opportunities, 1):
            benefit = o.get("benefit", "")
            print(f"  →  [{o['member']}] {o['opportunity']}")
            if benefit:
                print(f"     Benefit: {benefit}")
        print()

        user_mode    = self.settings.get("user_mode", "ask")
        enhancements = []

        for opp in opportunities:
            proposed = {
                "name":       opp.get("action", ""),
                "risk":       opp.get("risk", "low"),
                "reversible": opp.get("reversible", True),
                "undo_path":  opp.get("undo_path", ""),
            }

            if user_mode == "watch":
                continue

            deliberation = self.council.convene(opp, proposed)

            if deliberation["verdict"] == "PROCEED":
                result = self.enhance.execute(opp, user_mode)
                enhancements.append(result)
            else:
                print(f"\n  → Held for your review: {opp['opportunity']}")
                print(f"  {self.council.plain_language_summary(deliberation)}")
                result = self.enhance.execute(opp, "ask")
                enhancements.append(result)

        # Generate report
        self.report.load_from_scan(
            {"action": "enhance_complete",
             "opportunities": opportunities,
             "system": system},
            enhancements
        )
        report_path = self.report.generate(fmt="txt")

        print(f"\n  ─────────────────────────────────────────────────")
        print(f"  Your report has been saved to:\n  {report_path}")
        self._print_footer()
        return True

    # ── Council Member Scans ──────────────────────────────────────────────────

    def _lux_scan(self, system: str) -> list:
        """Lux — OS and software optimization opportunities."""
        opportunities = []
        print("  [Lux]     Scanning OS and software...")

        try:
            # Startup items (Windows)
            if system == "Windows":
                r = subprocess.run(
                    ["powershell", "-Command",
                     "Get-CimInstance Win32_StartupCommand | Select-Object Name, Command | ConvertTo-Json"],
                    capture_output=True, text=True, timeout=20
                )
                if r.returncode == 0 and r.stdout.strip():
                    try:
                        items = json.loads(r.stdout)
                        if isinstance(items, dict):
                            items = [items]
                        if len(items) > 8:
                            opportunities.append({
                                "member":      "Lux",
                                "opportunity": f"{len(items)} programs start with Windows. Some may be slowing boot.",
                                "benefit":     "Faster startup time.",
                                "action":      "report_startup_items",
                                "risk":        "low",
                                "reversible":  True,
                                "undo_path":   "Re-enable items in Task Manager > Startup Apps.",
                                "data":        items,
                            })
                    except Exception:
                        pass

            # Check for pending OS updates (Linux)
            if system == "Linux":
                r = subprocess.run(
                    ["apt", "list", "--upgradable"],
                    capture_output=True, text=True, timeout=20
                )
                if r.returncode == 0:
                    upgradable = [l for l in r.stdout.splitlines()
                                  if "/" in l and "upgradable" not in l]
                    if upgradable:
                        opportunities.append({
                            "member":      "Lux",
                            "opportunity": f"{len(upgradable)} software updates available.",
                            "benefit":     "Security patches and performance improvements.",
                            "action":      "notify_updates",
                            "risk":        "low",
                            "reversible":  True,
                            "undo_path":   "Updates can be rolled back with apt.",
                        })

        except Exception as e:
            self.logger.log("Lux", "scan_error", str(e), "error")

        return opportunities

    def _stratum_scan(self, system: str) -> list:
        """Stratum — hardware monitoring and thermal care."""
        opportunities = []
        print("  [Stratum] Checking hardware and thermals...")

        try:
            # CPU temperature (Linux)
            if system == "Linux":
                try:
                    r = subprocess.run(
                        ["cat", "/sys/class/thermal/thermal_zone0/temp"],
                        capture_output=True, text=True, timeout=5
                    )
                    if r.returncode == 0:
                        temp_c = int(r.stdout.strip()) / 1000
                        if temp_c > 80:
                            opportunities.append({
                                "member":      "Stratum",
                                "opportunity": f"CPU is running at {temp_c:.0f}°C. Releasing memory cache may help.",
                                "benefit":     "Lower CPU temperature, better performance.",
                                "action":      "release_memory",
                                "risk":        "low",
                                "reversible":  True,
                                "undo_path":   "Memory cache rebuilds automatically.",
                            })
                except Exception:
                    pass

            # Memory pressure
            if system in ("Linux", "Darwin"):
                r = subprocess.run(
                    ["free", "-m"] if system == "Linux" else ["vm_stat"],
                    capture_output=True, text=True, timeout=10
                )
                if system == "Linux" and r.returncode == 0:
                    for line in r.stdout.splitlines():
                        if line.startswith("Mem:"):
                            parts    = line.split()
                            total_mb = int(parts[1])
                            used_mb  = int(parts[2])
                            pct      = (used_mb / total_mb) * 100
                            if pct > 85:
                                opportunities.append({
                                    "member":      "Stratum",
                                    "opportunity": f"Memory is {pct:.0f}% used. Some can be released.",
                                    "benefit":     "More available memory, snappier response.",
                                    "action":      "release_memory",
                                    "risk":        "low",
                                    "reversible":  True,
                                    "undo_path":   "Memory cache rebuilds automatically.",
                                })

        except Exception as e:
            self.logger.log("Stratum", "scan_error", str(e), "error")

        return opportunities

    def _flow_scan(self, system: str) -> list:
        """Flow — network optimization."""
        opportunities = []
        print("  [Flow]    Checking network performance...")

        try:
            import socket

            # DNS latency check
            try:
                start = time.time()
                socket.gethostbyname("google.com")
                dns_ms = (time.time() - start) * 1000
                if dns_ms > 500:
                    opportunities.append({
                        "member":      "Flow",
                        "opportunity": f"DNS resolution is slow ({dns_ms:.0f}ms). Flushing may help.",
                        "benefit":     "Faster website loading.",
                        "action":      "flush_dns",
                        "risk":        "low",
                        "reversible":  True,
                        "undo_path":   "DNS cache rebuilds automatically as you browse.",
                    })
            except Exception:
                pass

            # Network latency
            ping_cmd = (["ping", "-n", "4", "8.8.8.8"] if system == "Windows"
                        else ["ping", "-c", "4", "8.8.8.8"])
            r = subprocess.run(ping_cmd, capture_output=True, text=True, timeout=15)
            if r.returncode == 0:
                import re
                times = re.findall(r"time[=<]([\d.]+)", r.stdout, re.IGNORECASE)
                if times:
                    avg_ms = sum(float(t) for t in times) / len(times)
                    if avg_ms > 150:
                        opportunities.append({
                            "member":      "Flow",
                            "opportunity": f"Network latency is {avg_ms:.0f}ms. A DNS flush may help.",
                            "benefit":     "More responsive browsing and streaming.",
                            "action":      "flush_dns",
                            "risk":        "low",
                            "reversible":  True,
                            "undo_path":   "DNS cache rebuilds automatically.",
                        })

        except Exception as e:
            self.logger.log("Flow", "scan_error", str(e), "error")

        return opportunities

    def _vault_scan(self, system: str) -> list:
        """Vault — storage intelligence and cleanup."""
        opportunities = []
        print("  [Vault]   Scanning storage...")

        try:
            # Temp files
            if system == "Windows":
                temp = os.environ.get("TEMP", "")
                if temp and os.path.exists(temp):
                    temp_size = self._dir_size_mb(temp)
                    if temp_size > 500:
                        opportunities.append({
                            "member":      "Vault",
                            "opportunity": f"Temp folder is using {temp_size:.0f}MB.",
                            "benefit":     f"Free up {temp_size:.0f}MB of storage.",
                            "action":      "clear_temp",
                            "risk":        "low",
                            "reversible":  False,
                            "undo_path":   "Temp files are safe to remove and cannot be restored.",
                        })

            elif system in ("Linux", "Darwin"):
                cache_dir = (os.path.expanduser("~/.cache") if system == "Linux"
                             else os.path.expanduser("~/Library/Caches"))
                if os.path.exists(cache_dir):
                    cache_size = self._dir_size_mb(cache_dir)
                    if cache_size > 200:
                        opportunities.append({
                            "member":      "Vault",
                            "opportunity": f"Cache folder is using {cache_size:.0f}MB.",
                            "benefit":     f"Free up {cache_size:.0f}MB. Cache rebuilds automatically.",
                            "action":      "clear_cache",
                            "risk":        "low",
                            "reversible":  False,
                            "undo_path":   "Cache files rebuild automatically as you use your apps.",
                        })

            # Thumbnail cache
            if system == "Windows":
                thumb_dir = os.path.join(
                    os.environ.get("LOCALAPPDATA", ""),
                    "Microsoft", "Windows", "Explorer"
                )
                if os.path.exists(thumb_dir):
                    thumb_size = self._dir_size_mb(thumb_dir)
                    if thumb_size > 100:
                        opportunities.append({
                            "member":      "Vault",
                            "opportunity": f"Thumbnail cache is using {thumb_size:.0f}MB.",
                            "benefit":     "Free up space. Thumbnails rebuild as you browse.",
                            "action":      "clear_thumbnails",
                            "risk":        "low",
                            "reversible":  False,
                            "undo_path":   "Thumbnails rebuild automatically.",
                        })

        except Exception as e:
            self.logger.log("Vault", "scan_error", str(e), "error")

        return opportunities

    def _aegis_scan(self, system: str) -> list:
        """Aegis — security hardening opportunities."""
        opportunities = []
        print("  [Aegis]   Checking security posture...")

        try:
            # World-writable files (Linux/macOS)
            if system in ("Linux", "Darwin"):
                home = os.path.expanduser("~")
                r = subprocess.run(
                    ["find", home, "-maxdepth", "2", "-perm", "-o+w", "-not", "-type", "l"],
                    capture_output=True, text=True, timeout=15
                )
                ww_files = [l for l in r.stdout.splitlines() if l.strip()]
                if len(ww_files) > 5:
                    opportunities.append({
                        "member":      "Aegis",
                        "opportunity": f"{len(ww_files)} files in your home folder are world-writable.",
                        "benefit":     "Better security. Only you can modify your files.",
                        "action":      "fix_permissions",
                        "risk":        "low",
                        "reversible":  True,
                        "undo_path":   "Run: chmod -R go+w ~ to restore.",
                        "path":        home,
                    })

            # Hosts file check (all platforms)
            hosts_path = (r"C:\Windows\System32\drivers\etc\hosts"
                          if system == "Windows" else "/etc/hosts")
            if os.path.exists(hosts_path):
                try:
                    with open(hosts_path) as f:
                        content = f.read()
                    suspicious = [
                        line for line in content.splitlines()
                        if line.strip() and not line.startswith("#")
                        and any(k in line.lower() for k in
                                ["google", "microsoft", "apple", "windows", "update"])
                    ]
                    if suspicious:
                        opportunities.append({
                            "member":      "Aegis",
                            "opportunity": "Your hosts file has unusual entries. Worth reviewing.",
                            "benefit":     "Ensure your traffic isn't being redirected.",
                            "action":      "notify_hosts",
                            "risk":        "high",
                            "reversible":  True,
                            "undo_path":   "No automatic change — you review and decide.",
                        })
                except PermissionError:
                    pass

        except Exception as e:
            self.logger.log("Aegis", "scan_error", str(e), "error")

        return opportunities

    def _bloom_scan(self, system: str) -> list:
        """Bloom — performance enhancement. Unique to Tah."""
        opportunities = []
        print("  [Bloom]   Looking for performance improvements...")

        try:
            # Check if DNS could be faster (offer better DNS)
            import socket
            current_dns_fast = True
            try:
                start = time.time()
                for _ in range(3):
                    socket.gethostbyname("cloudflare.com")
                avg = ((time.time() - start) / 3) * 1000
                if avg > 100:
                    current_dns_fast = False
            except Exception:
                pass

            if not current_dns_fast and system == "Windows":
                opportunities.append({
                    "member":      "Bloom",
                    "opportunity": "Your DNS resolution could be faster.",
                    "benefit":     "Websites load faster. Consider switching to 1.1.1.1 or 8.8.8.8.",
                    "action":      "notify_dns_suggestion",
                    "risk":        "low",
                    "reversible":  True,
                    "undo_path":   "Change DNS back in network settings.",
                })

            # Browser cache notification (cross-platform awareness)
            if system in ("Linux", "Darwin"):
                for browser_cache in [
                    os.path.expanduser("~/.cache/google-chrome"),
                    os.path.expanduser("~/.cache/mozilla"),
                    os.path.expanduser("~/Library/Caches/Google/Chrome"),
                    os.path.expanduser("~/Library/Application Support/Firefox/Profiles"),
                ]:
                    if os.path.exists(browser_cache):
                        size_mb = self._dir_size_mb(browser_cache)
                        if size_mb > 500:
                            opportunities.append({
                                "member":      "Bloom",
                                "opportunity": f"Browser cache is {size_mb:.0f}MB.",
                                "benefit":     f"Free up {size_mb:.0f}MB. Browser stays fast.",
                                "action":      "clear_cache",
                                "risk":        "low",
                                "reversible":  False,
                                "undo_path":   "Browser cache rebuilds as you browse.",
                            })
                        break

        except Exception as e:
            self.logger.log("Bloom", "scan_error", str(e), "error")

        return opportunities

    # ── Watch Mode ────────────────────────────────────────────────────────────

    def _start_watch(self) -> bool:
        interval = self.settings.get("scan_interval_s", 3600)
        print(f"\n  Tah is watching your device.")
        print(f"  It will scan every {interval // 60} minutes.")
        print(f"  Run  python main.py --status  to check what it found.")
        print(f"  Press Ctrl+C to stop.\n")

        self.logger.log("ENGINE", "watch_start", f"interval={interval}s", "ok")
        self._running = True

        watch_thread = threading.Thread(
            target=self._watch_loop,
            args=(interval,),
            daemon=True
        )
        watch_thread.start()

        try:
            while self._running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop()

        return True

    def _watch_loop(self, interval: int):
        while self._running:
            self._run_full_enhance()
            elapsed = 0
            while self._running and elapsed < interval:
                time.sleep(5)
                elapsed += 5

    # ── Status ────────────────────────────────────────────────────────────────

    def status(self) -> dict:
        last_scan = self.settings.get("last_scan")
        last_scan_str = "Never"
        if last_scan:
            try:
                dt = datetime.fromisoformat(last_scan)
                last_scan_str = dt.strftime("%b %d at %I:%M %p")
            except Exception:
                last_scan_str = last_scan

        enhancements = len(self.enhance.logger.enhancements_done())

        return {
            "Version":          self.VERSION,
            "System":           self._system,
            "Mode":             self.settings.get("user_mode", "ask"),
            "Last scan":        last_scan_str,
            "Enhancements done": enhancements,
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _dir_size_mb(self, path: str) -> float:
        total = 0
        try:
            for dp, _, files in os.walk(path):
                for f in files:
                    fp = os.path.join(dp, f)
                    try:
                        total += os.path.getsize(fp)
                    except OSError:
                        pass
        except Exception:
            pass
        return total / (1024 * 1024)

    def set_user_mode(self, mode: str):
        valid = ("auto", "ask", "watch")
        if mode not in valid:
            print(f"\n  Invalid mode: {mode}")
            print(f"  Valid modes: {', '.join(valid)}")
            return
        self.settings["user_mode"] = mode
        self._save_settings()
        descriptions = {
            "auto":  "Tah will apply safe enhancements automatically.",
            "ask":   "Tah will ask before making any changes.",
            "watch": "Tah will monitor and report, but not change anything.",
        }
        print(f"\n  Tah mode set to: {mode}")
        print(f"  {descriptions[mode]}\n")
        self.logger.log("ENGINE", "mode_change", f"mode={mode}", "ok")

    def stop(self):
        self._running = False
        print("\n  Tah is stepping back. The fog lifts.\n")
        self.logger.log("ENGINE", "stop", "graceful shutdown", "ok")

    def _load_settings(self) -> dict:
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE) as f:
                    saved = json.load(f)
                    return {**DEFAULT_SETTINGS, **saved}
            except Exception:
                pass
        return DEFAULT_SETTINGS.copy()

    def _save_settings(self):
        try:
            with open(SETTINGS_FILE, "w") as f:
                json.dump(self.settings, f, indent=2)
        except Exception:
            pass

    def _print_banner(self):
        print()
        print("  ╔══════════════════════════════════════════════════╗")
        print("  ║                                                  ║")
        print("  ║   T A H   —   Device Enhancement Council        ║")
        print("  ║                                                  ║")
        sys_str = f"v{self.VERSION}   ·   {self._system}"
        print(f"  ║   {sys_str:<48}║")
        print("  ║                                                  ║")
        print("  ╚══════════════════════════════════════════════════╝")
        print()

    def _print_footer(self):
        print()
        print("  ────────────────────────────────────────────────────")
        print("  Tah — Device enhancement for everyone.")
        print("  Founded by Krone the Architect · Powers Tracey Lynn")
        print("  ────────────────────────────────────────────────────")
        print()
