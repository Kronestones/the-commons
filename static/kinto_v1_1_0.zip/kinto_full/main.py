#!/usr/bin/env python3
"""
main.py — Kinto

One tap. That's all it takes.

Usage:
    python main.py              # Background watch mode
    python main.py --scan       # Run a full scan right now
    python main.py --status     # Check what Kinto has found
    python main.py --mode auto  # Set repair mode (auto / ask / watch)
    python main.py --version    # Print version

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""

import argparse
import signal
import sys

# ── Args first — before heavy imports ────────────────────────────────────────

parser = argparse.ArgumentParser(
    description="Kinto — Free device repair for everyone."
)
parser.add_argument("--scan",    action="store_true", help="Run a full scan now")
parser.add_argument("--status",  action="store_true", help="Show current status")
parser.add_argument("--mode",    metavar="MODE",      help="Set mode: auto / ask / watch")
parser.add_argument("--version", action="store_true", help="Print version and exit")
args = parser.parse_args()

VERSION = "1.0.0"

if args.version:
    print(f"Kinto v{VERSION} — Repair Council")
    print("Founded by Krone the Architect · Powers Tracey Lynn")
    sys.exit(0)

# ── Launch ────────────────────────────────────────────────────────────────────

from kinto.engine import KintoEngine

engine = KintoEngine()

# ── Mode change ───────────────────────────────────────────────────────────────

if args.mode:
    # Start silently just to access the engine, then set mode and exit
    engine.start(mode="silent")
    engine.set_user_mode(args.mode)
    sys.exit(0)

# ── Status ────────────────────────────────────────────────────────────────────

if args.status:
    engine.start(mode="silent")
    status = engine.status()
    print("\n  Kinto Status")
    print("  ─────────────────────────────")
    for k, v in status.items():
        print(f"  {k:<15} {v}")
    print()
    sys.exit(0)

# ── Graceful shutdown ─────────────────────────────────────────────────────────

def handle_shutdown(signum, frame):
    print()
    engine.stop()
    sys.exit(0)

signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT,  handle_shutdown)

# ── Start ─────────────────────────────────────────────────────────────────────

if args.scan:
    # Manual scan — run now
    started = engine.start(mode="scan")
else:
    # Default — background watch
    started = engine.start(mode="watch")

if not started:
    sys.exit(1)

# ── Keep alive in watch mode ──────────────────────────────────────────────────

if not args.scan:
    try:
        while True:
            import time
            time.sleep(1)
    except KeyboardInterrupt:
        engine.stop()
        sys.exit(0)
