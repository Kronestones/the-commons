# VTOMdse5Ti8GmZqWkbLD5rU2NWC6fRQlOclbGW1Kq84p3gHVg8DjMqFfB2eeNJ27
# DcqNJe6eDDMwS4uaqO8DfEdcYraRJqxAsOuaekSoQ1zQX939zpSudGX1Efgu0E8L
""""""
import argparse
import signal
import sys
_oCCbyTNGlLgQ = argparse.ArgumentParser(description='Kinto — Free device repair for everyone.')
_oCCbyTNGlLgQ.add_argument('--scan', action='store_true', help='Run a full scan now')
_oCCbyTNGlLgQ.add_argument('--status', action='store_true', help='Show current status')
_oCCbyTNGlLgQ.add_argument('--mode', metavar='MODE', help='Set mode: auto / ask / watch')
_oCCbyTNGlLgQ.add_argument('--version', action='store_true', help='Print version and exit')
_GPrjdstktzCJ = _oCCbyTNGlLgQ.parse_args()
_rinoSbdCvfaR = '1.0.0'
if _GPrjdstktzCJ.version:
    print(f'Kinto v{_rinoSbdCvfaR} — Repair Council')
    print('Founded by Krone the Architect · Powers Tracey Lynn')
    sys.exit(0)
from kinto.engine import KintoEngine
_BNegWobtjLEf = _GBEOdZqayGLN()
if _GPrjdstktzCJ.mode:
    _BNegWobtjLEf.start(mode='silent')
    _BNegWobtjLEf.set_user_mode(_GPrjdstktzCJ.mode)
    sys.exit(0)
if _GPrjdstktzCJ.status:
    _BNegWobtjLEf.start(mode='silent')
    _uoudGKaeRDVT = _BNegWobtjLEf.status()
    print('\n  Kinto Status')
    print('  ─────────────────────────────')
    for _LyTfEJhCtMOw, _PArHbiKTzsyg in _uoudGKaeRDVT.items():
        print(f'  {_LyTfEJhCtMOw:<15} {_PArHbiKTzsyg}')
    print()
    sys.exit(0)

def _LVEihdQuHQKP(_zStJZAZhDVch, _AeUyihDlaFNy):
    print()
    _BNegWobtjLEf.stop()
    sys.exit(0)
_NxqTxuPKhCbf.signal(_NxqTxuPKhCbf.SIGTERM, _LVEihdQuHQKP)
_NxqTxuPKhCbf.signal(_NxqTxuPKhCbf.SIGINT, _LVEihdQuHQKP)
if _GPrjdstktzCJ.scan:
    _jdqfFjVtYasG = _BNegWobtjLEf.start(mode='scan')
else:
    _jdqfFjVtYasG = _BNegWobtjLEf.start(mode='watch')
if not _jdqfFjVtYasG:
    sys.exit(1)
if not _GPrjdstktzCJ.scan:
    try:
        while True:
            import time
            time.sleep(1)
    except _QtTqDJupWjvx:
        _BNegWobtjLEf.stop()
        sys.exit(0)