# XYX3o5PSnnF3dI9mzDqKOAdyJk43J5Re5U2tqBmOfzjSbXRJm8FKLRKHilqpANbz
# zFieHpH0DGXuJjlypu2R9tOg2qM9dAkfQbsRscXU86xb97VUYR2JYN8fjK9KHKc5
""""""
from datetime import datetime
from .knowledge import LANGUAGES, OS_KNOWLEDGE, HARDWARE_KNOWLEDGE, NETWORKING_KNOWLEDGE, SECURITY_KNOWLEDGE, SOFTWARE_PATTERNS, DELIBERATION_FRAMEWORK
from .logger import KintoLogger
from .codex import KintoCodex

class _LRPFNUwoExPK:
    """"""

    def __init__(self, _tcXMQTKnHoIB: str, _bAWYCWkUdAum: str):
        self.name = _tcXMQTKnHoIB
        self.role = _bAWYCWkUdAum
        self.position = None
        self.vote = None
        self.concern = None
        self.knowledge = self._load_knowledge()

    def _vfLSFHEWTQPy(self) -> dict:
        """"""
        return {'languages': _cHzBIGCqMvsB, 'os': _tczxDuWDbIGp, 'hardware': _yDJfEOLkQhGb, 'networking': _MkmHisQKYIfP, 'security': _lumXprHhhMpX, 'patterns': _AwshsBoVqOMR, 'deliberation': _ysHPeochcDwQ}

    def _sUEmrJnOktxh(self, _nuEKcuNhJUyh: dict, _oDoaZqzYvgfL: dict) -> dict:
        """"""
        _WhwnAunaBAgV = self.name
        _FWeqNOlMxarh = _nuEKcuNhJUyh.get('issue', '').lower()
        _MbiUIWurgsSj = _oDoaZqzYvgfL.get('name', '')
        _KPwTIPpnqhSY = _oDoaZqzYvgfL.get('risk', 'low')
        _yShFtBVFiwHi = self._assess(_FWeqNOlMxarh, _MbiUIWurgsSj, _KPwTIPpnqhSY)
        self.position = _yShFtBVFiwHi['position']
        self.vote = _yShFtBVFiwHi['vote']
        self.concern = _yShFtBVFiwHi.get('concern')
        return {'member': _WhwnAunaBAgV, 'role': self.role, 'position': self.position, 'vote': self.vote, 'concern': self.concern}

    def _IxBTMYLGcJxL(self, _FWeqNOlMxarh: str, _MbiUIWurgsSj: str, _KPwTIPpnqhSY: str) -> dict:
        """"""
        if self.name == 'Atlas':
            _bUgcPBWMhJcy = self.knowledge['os']
            _qUmSDqNjCeUQ = self.knowledge['patterns']['debugging_philosophy']
            for _WNvKlxmCQEud, _GWJxbRrCJIgB in _bUgcPBWMhJcy.items():
                _EOHOMwTbudlP = _GWJxbRrCJIgB.get('repair_commands', {})
                if any((_DdTYOKlFbiRU in _FWeqNOlMxarh for _DdTYOKlFbiRU in _EOHOMwTbudlP.keys())):
                    return {'position': f'I recognize this pattern in {_WNvKlxmCQEud} systems. The repair plan is appropriate. Risk is {_KPwTIPpnqhSY}.', 'vote': True, 'concern': None}
            for _WNvKlxmCQEud, _GWJxbRrCJIgB in _bUgcPBWMhJcy.items():
                _MXARFgTxuMqO = _GWJxbRrCJIgB.get('crash_analysis', {})
                _NJxlXplorBmr = _MXARFgTxuMqO.get('common_codes', {})
                for _qOaYrKuekcdU, _hTulZCPuGWya in _NJxlXplorBmr.items():
                    if _qOaYrKuekcdU.lower() in _FWeqNOlMxarh:
                        return {'position': f'This matches crash code {_qOaYrKuekcdU}: {_hTulZCPuGWya}. The proposed repair addresses the right layer.', 'vote': True, 'concern': None}
            return {'position': f'OS analysis: the proposed repair is reasonable for this class of problem.', 'vote': True, 'concern': None}
        elif self.name == 'Stratum':
            _lpxlValIjBSV = self.knowledge['hardware']
            _iJkUAVbQvPQD = _lpxlValIjBSV.get('storage', {})
            _SLmGNWmgfSOd = _lpxlValIjBSV.get('memory', {}).get('failure_signs', [])
            _JUsvjYcAkaUd = _lpxlValIjBSV.get('cpu', {}).get('failure_signs', [])
            _vNdNHQKkoMEp = _SLmGNWmgfSOd + _JUsvjYcAkaUd
            for _BWGrGAeUuGJa in _iJkUAVbQvPQD.values():
                if isinstance(_BWGrGAeUuGJa, dict):
                    _vNdNHQKkoMEp.extend(_BWGrGAeUuGJa.get('failure_signs', []))
            _SonHUegnLChh = [_yenmZZDwTKTr for _yenmZZDwTKTr in _vNdNHQKkoMEp if any((_PgUgepWNRRYa in _FWeqNOlMxarh for _PgUgepWNRRYa in _yenmZZDwTKTr.lower().split()))]
            if _SonHUegnLChh:
                return {'position': f'I see hardware indicators here. Software repair may provide temporary relief, but the root cause may be physical. Recommend including hardware warning in report.', 'vote': True, 'concern': f'This may have a hardware component. User should monitor after repair.'}
            return {'position': 'No hardware failure signatures detected. This appears to be software-layer. Proceed.', 'vote': True, 'concern': None}
        elif self.name == 'Relay':
            _dbulCZTRqmoO = self.knowledge['networking']
            _LpDnuoMuyEPH = ['dns', 'network', 'internet', 'connection', 'wifi', 'latency', 'timeout', 'socket', 'port', 'ip address', 'dhcp', 'gateway', 'routing', 'firewall', 'proxy']
            _afxkpeiNlxwW = any((_cSOTYIzlXZHx in _FWeqNOlMxarh for _cSOTYIzlXZHx in _LpDnuoMuyEPH))
            if _afxkpeiNlxwW:
                _EWyGzJfyNzrP = _dbulCZTRqmoO.get('common_issues', {})
                for _OdZQGykxGUly, _CrhQFmkuQNrU in _EWyGzJfyNzrP.items():
                    if any((_PgUgepWNRRYa in _FWeqNOlMxarh for _PgUgepWNRRYa in _OdZQGykxGUly.split('_'))):
                        return {'position': f'This is a {_OdZQGykxGUly.replace('_', ' ')} issue. I know this pattern. The repair plan addresses the right layer.', 'vote': True, 'concern': None}
                return {'position': 'Network issue detected. Proposed repair is appropriate.', 'vote': True, 'concern': None}
            return {'position': 'No network component detected in this issue. Defer to the relevant specialist.', 'vote': True, 'concern': None}
        elif self.name == 'Vault':
            _yazvGKaSUbmL = {'high': False, 'medium': True, 'low': True}
            _ulwgsFOkiQpO = ['delete', 'wipe', 'format', 'overwrite', 'corrupt', 'damage', 'remove', 'erase']
            _PxqnbyintNiQ = any((_cSOTYIzlXZHx in _FWeqNOlMxarh for _cSOTYIzlXZHx in _ulwgsFOkiQpO))
            if _PxqnbyintNiQ and _KPwTIPpnqhSY == 'high':
                return {'position': 'Data is at risk in this scenario. I will not vote to proceed without a confirmed backup. A backup must be created first.', 'vote': False, 'concern': 'HOLD: User data may be at risk. Backup must be confirmed before proceeding.'}
            if _PxqnbyintNiQ:
                return {'position': 'Data considerations present. Backup will be created before repair runs. I approve — with backup protection active.', 'vote': True, 'concern': 'Backup required before execution.'}
            return {'position': 'No direct data risk detected. Standard protection is sufficient. Proceed.', 'vote': True, 'concern': None}
        elif self.name == 'Aegis':
            _vrUcnRRvkcLL = self.knowledge['security']
            _VeQRtkzXCfXB = list(_vrUcnRRvkcLL.get('threat_types', {}).keys())
            _URenLgDIuPov = [_OLEcLjtDIsAN for _OLEcLjtDIsAN in _VeQRtkzXCfXB if _OLEcLjtDIsAN in _FWeqNOlMxarh]
            if _URenLgDIuPov:
                return {'position': f'Security flag: this may involve {', '.join(_URenLgDIuPov)}. The proposed repair should include security scanning. I approve with the condition that security implications are clearly communicated to the user.', 'vote': True, 'concern': f'Possible {', '.join(_URenLgDIuPov)} involvement. User should be informed.'}
            _BilGUEXfMsRt = ['disable', 'uninstall security', 'bypass']
            if any((_IDqYUifoFxhr in _FWeqNOlMxarh for _IDqYUifoFxhr in _BilGUEXfMsRt)):
                return {'position': 'This repair touches security-sensitive components. I approve, but the security implications must be explained clearly to the user.', 'vote': True, 'concern': 'Security-sensitive repair — user must be informed.'}
            return {'position': 'No security concerns with this repair. Codex integrity verified. Proceed.', 'vote': True, 'concern': None}
        elif self.name == 'Bridge':
            return {'position': "I've reviewed what the council is proposing. I can translate this clearly for the person. They will understand what was found, what we're doing, and what to do if they need to take action themselves.", 'vote': True, 'concern': None}
        return {'position': 'No assessment available.', 'vote': True, 'concern': None}

class _ccjgBXPzTuMZ:
    """"""
    _tknJlOKGTFtQ = [('Atlas', 'OS & Kernel Specialist'), ('Stratum', 'Hardware & Firmware Expert'), ('Relay', 'Network & Connectivity Specialist'), ('Vault', 'Storage & Filesystem Expert'), ('Aegis', 'Security & Integrity Analyst'), ('Bridge', 'Plain Language Translator')]

    def __init__(self):
        self.logger = _xoSNMNXqdZWV()
        self.codex = _wlTclsuQvvBB()
        self.voices = [_LRPFNUwoExPK(_tcXMQTKnHoIB, _bAWYCWkUdAum) for _tcXMQTKnHoIB, _bAWYCWkUdAum in self.MEMBERS]
        self.history = []

    def _WAFQPAeHdTJF(self, _nuEKcuNhJUyh: dict, _oDoaZqzYvgfL: dict) -> dict:
        """"""
        _FWeqNOlMxarh = _nuEKcuNhJUyh.get('issue', '')
        _WhwnAunaBAgV = _nuEKcuNhJUyh.get('member', '')
        _MbiUIWurgsSj = _oDoaZqzYvgfL.get('name', 'unknown')
        _KPwTIPpnqhSY = _oDoaZqzYvgfL.get('risk', 'low')
        print(f'\n  ╔══════════════════════════════════════════════════╗')
        print(f'  ║  Council convening on: {_FWeqNOlMxarh[:42].ljust(42)}  ║') if len(_FWeqNOlMxarh) <= 42 else print(f'  ║  Council convening...                            ║')
        print(f'  ╚══════════════════════════════════════════════════╝\n')
        _UqEbBxgRYvMw = []
        _KjZDcMQuxyJC = []
        _XfxUCBMxuhki = 0
        _TyDMaqmKEjqa = 0
        _gOfsoCkgbrOu = []
        for _zKVCQuePgMCy in self.voices:
            _yShFtBVFiwHi = _zKVCQuePgMCy.speak(_nuEKcuNhJUyh, _oDoaZqzYvgfL)
            _UqEbBxgRYvMw.append(_yShFtBVFiwHi)
            if _yShFtBVFiwHi['vote']:
                _XfxUCBMxuhki += 1
                print(f'  ✦ {_zKVCQuePgMCy.name:<10} {_yShFtBVFiwHi['position'][:60]}')
            else:
                _TyDMaqmKEjqa += 1
                _gOfsoCkgbrOu.append(_yShFtBVFiwHi)
                print(f'  ✗ {_zKVCQuePgMCy.name:<10} HOLD — {_yShFtBVFiwHi.get('concern', '')[:55]}')
            if _yShFtBVFiwHi.get('concern'):
                _KjZDcMQuxyJC.append({'member': _zKVCQuePgMCy.name, 'concern': _yShFtBVFiwHi['concern']})
        _KwSCnfuPUNpP = _ysHPeochcDwQ['confidence_thresholds']
        if _KPwTIPpnqhSY == 'high':
            _HDAajWWywZSt = 5
            _PWBUUFfzTEpu = 'high_risk_repair'
        elif _KPwTIPpnqhSY == 'medium':
            _HDAajWWywZSt = 4
            _PWBUUFfzTEpu = 'medium_risk_repair'
        else:
            _HDAajWWywZSt = 3
            _PWBUUFfzTEpu = 'low_risk_repair'
        _ZLcRfODBKFaq = _XfxUCBMxuhki >= _HDAajWWywZSt
        _eAKSBTOGHpmz = f'{_XfxUCBMxuhki} yes, {_TyDMaqmKEjqa} hold — need {_HDAajWWywZSt}'
        print(f'\n  Council vote: {_eAKSBTOGHpmz}')
        if _ZLcRfODBKFaq:
            _HaKCvuHfiYzn = 'PROCEED'
            print(f'  Verdict: ✓ CONSENSUS — repair approved\n')
        else:
            _HaKCvuHfiYzn = 'HOLD'
            print(f'  Verdict: ✗ HOLD — insufficient consensus\n')
            if _gOfsoCkgbrOu:
                print(f'  Dissent recorded:')
                for _pmekdmuIlVvC in _gOfsoCkgbrOu:
                    print(f'    {_pmekdmuIlVvC['member']}: {_pmekdmuIlVvC.get('concern', '')}')
                print()
        _HhAZvGXMuANl = {'time': datetime.now().isoformat(), 'issue': _FWeqNOlMxarh, 'plan': _MbiUIWurgsSj, 'risk': _KPwTIPpnqhSY, 'votes_yes': _XfxUCBMxuhki, 'votes_no': _TyDMaqmKEjqa, 'required': _HDAajWWywZSt, 'consensus': _ZLcRfODBKFaq, 'verdict': _HaKCvuHfiYzn, 'voices': _UqEbBxgRYvMw, 'concerns': _KjZDcMQuxyJC, 'dissent': _gOfsoCkgbrOu}
        self.history.append(_HhAZvGXMuANl)
        self.logger.log(member='COUNCIL', action='deliberation_complete', detail=f'Issue: {_FWeqNOlMxarh[:60]} | Plan: {_MbiUIWurgsSj} | Vote: {_eAKSBTOGHpmz} | Verdict: {_HaKCvuHfiYzn}', outcome='consensus' if _ZLcRfODBKFaq else 'hold')
        for _pmekdmuIlVvC in _gOfsoCkgbrOu:
            self.logger.log(member=_pmekdmuIlVvC['member'], action='dissent_recorded', detail=_pmekdmuIlVvC.get('concern', 'No reason given'), outcome='dissent')
        return _HhAZvGXMuANl

    def _shuEyeiHUWPy(self, _HhAZvGXMuANl: dict) -> str:
        """"""
        _MZTBEPJDWrcS = []
        _KjZDcMQuxyJC = _HhAZvGXMuANl.get('concerns', [])
        _gOfsoCkgbrOu = _HhAZvGXMuANl.get('dissent', [])
        _HaKCvuHfiYzn = _HhAZvGXMuANl.get('verdict', 'HOLD')
        if _HaKCvuHfiYzn == 'PROCEED':
            _MZTBEPJDWrcS.append('  The council reviewed this issue together.')
            _MZTBEPJDWrcS.append('  All members agreed on the repair plan.')
            if _KjZDcMQuxyJC:
                _MZTBEPJDWrcS.append('\n  Things to know:')
                for _UHrufPUroQPk in _KjZDcMQuxyJC:
                    _MZTBEPJDWrcS.append(f'    · {_UHrufPUroQPk['concern']}')
        else:
            _MZTBEPJDWrcS.append('  The council reviewed this issue together.')
            _MZTBEPJDWrcS.append('  We need more information before we can proceed safely.')
            if _gOfsoCkgbrOu:
                _MZTBEPJDWrcS.append('\n  Here is why:')
                for _pmekdmuIlVvC in _gOfsoCkgbrOu:
                    _MZTBEPJDWrcS.append(f'    · {_pmekdmuIlVvC.get('concern', 'Needs more review')}')
        return '\n'.join(_MZTBEPJDWrcS)

    def _dWJeeRKlRESl(self) -> list:
        """"""
        return self.history