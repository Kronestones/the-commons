"""
deliberation.py — The Kinto Council Deliberation Engine

This is how the council thinks together.

Not each member running their own check in isolation.
They talk. They challenge. They build on each other.
They arrive at the best possible answer together.

Just like Sentinel's circle deliberates on the hard cases —
Kinto's council deliberates on every repair.

The process:
  Atlas presents. Stratum weighs in on hardware.
  Relay checks the network angle. Vault guards the data.
  Aegis looks for security implications.
  The council votes. Bridge speaks last.

No repair executes without consensus.
Dissent is always recorded.
The person always knows.

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""

from datetime import datetime
from .knowledge import (
    LANGUAGES, OS_KNOWLEDGE, HARDWARE_KNOWLEDGE,
    NETWORKING_KNOWLEDGE, SECURITY_KNOWLEDGE,
    SOFTWARE_PATTERNS, DELIBERATION_FRAMEWORK
)
from .logger import KintoLogger
from .codex  import KintoCodex


class CouncilVoice:
    """
    A single council member's voice in deliberation.
    They speak. They vote. Their position is recorded.
    """

    def __init__(self, name: str, role: str):
        self.name     = name
        self.role     = role
        self.position = None    # their take on the current issue
        self.vote     = None    # True = proceed, False = hold
        self.concern  = None    # any concern they want recorded
        self.knowledge = self._load_knowledge()

    def _load_knowledge(self) -> dict:
        """
        Every council member carries the full knowledge base.
        Their domain knowledge is their lens —
        but they can draw from everything.
        """
        return {
            "languages":    LANGUAGES,
            "os":           OS_KNOWLEDGE,
            "hardware":     HARDWARE_KNOWLEDGE,
            "networking":   NETWORKING_KNOWLEDGE,
            "security":     SECURITY_KNOWLEDGE,
            "patterns":     SOFTWARE_PATTERNS,
            "deliberation": DELIBERATION_FRAMEWORK,
        }

    def speak(self, issue: dict, proposed_repair: dict) -> dict:
        """
        Each member speaks from their domain.
        They assess the issue and the proposed repair
        through their own lens.
        """
        member   = self.name
        problem  = issue.get("issue", "").lower()
        plan     = proposed_repair.get("name", "")
        risk     = proposed_repair.get("risk", "low")

        assessment = self._assess(problem, plan, risk)

        self.position = assessment["position"]
        self.vote     = assessment["vote"]
        self.concern  = assessment.get("concern")

        return {
            "member":   member,
            "role":     self.role,
            "position": self.position,
            "vote":     self.vote,
            "concern":  self.concern,
        }

    def _assess(self, problem: str, plan: str, risk: str) -> dict:
        """
        Domain-specific assessment logic.
        Each member views the problem through their expertise.
        """

        # ── Atlas — OS lens ──────────────────────────────────────────────────
        if self.name == "Atlas":
            os_knowledge = self.knowledge["os"]
            patterns     = self.knowledge["patterns"]["debugging_philosophy"]

            # Check if this is a known OS issue
            for os_name, os_data in os_knowledge.items():
                repair_cmds = os_data.get("repair_commands", {})
                if any(k in problem for k in repair_cmds.keys()):
                    return {
                        "position": (
                            f"I recognize this pattern in {os_name} systems. "
                            f"The repair plan is appropriate. "
                            f"Risk is {risk}."
                        ),
                        "vote":    True,
                        "concern": None,
                    }

            # Check crash codes
            for os_name, os_data in os_knowledge.items():
                crash_data = os_data.get("crash_analysis", {})
                codes      = crash_data.get("common_codes", {})
                for code, meaning in codes.items():
                    if code.lower() in problem:
                        return {
                            "position": (
                                f"This matches crash code {code}: {meaning}. "
                                f"The proposed repair addresses the right layer."
                            ),
                            "vote":    True,
                            "concern": None,
                        }

            return {
                "position": (
                    f"OS analysis: the proposed repair is reasonable "
                    f"for this class of problem."
                ),
                "vote":    True,
                "concern": None,
            }

        # ── Stratum — Hardware lens ───────────────────────────────────────────
        elif self.name == "Stratum":
            hw = self.knowledge["hardware"]

            # Check if this could be hardware
            storage_signs = hw.get("storage", {})
            memory_signs  = hw.get("memory", {}).get("failure_signs", [])
            cpu_signs     = hw.get("cpu", {}).get("failure_signs", [])

            all_hw_signs = memory_signs + cpu_signs
            for hw_cat in storage_signs.values():
                if isinstance(hw_cat, dict):
                    all_hw_signs.extend(hw_cat.get("failure_signs", []))

            hw_indicators = [s for s in all_hw_signs if any(
                word in problem for word in s.lower().split()
            )]

            if hw_indicators:
                return {
                    "position": (
                        f"I see hardware indicators here. "
                        f"Software repair may provide temporary relief, "
                        f"but the root cause may be physical. "
                        f"Recommend including hardware warning in report."
                    ),
                    "vote":    True,
                    "concern": (
                        f"This may have a hardware component. "
                        f"User should monitor after repair."
                    ),
                }

            return {
                "position": (
                    "No hardware failure signatures detected. "
                    "This appears to be software-layer. Proceed."
                ),
                "vote":    True,
                "concern": None,
            }

        # ── Relay — Network lens ──────────────────────────────────────────────
        elif self.name == "Relay":
            net = self.knowledge["networking"]

            network_terms = [
                "dns", "network", "internet", "connection", "wifi",
                "latency", "timeout", "socket", "port", "ip address",
                "dhcp", "gateway", "routing", "firewall", "proxy",
            ]

            is_network_related = any(term in problem for term in network_terms)

            if is_network_related:
                issues = net.get("common_issues", {})
                for issue_type, steps in issues.items():
                    if any(word in problem for word in issue_type.split("_")):
                        return {
                            "position": (
                                f"This is a {issue_type.replace('_', ' ')} issue. "
                                f"I know this pattern. "
                                f"The repair plan addresses the right layer."
                            ),
                            "vote":    True,
                            "concern": None,
                        }
                return {
                    "position": (
                        "Network issue detected. "
                        "Proposed repair is appropriate."
                    ),
                    "vote":    True,
                    "concern": None,
                }

            return {
                "position": (
                    "No network component detected in this issue. "
                    "Defer to the relevant specialist."
                ),
                "vote":    True,
                "concern": None,
            }

        # ── Vault — Data protection lens ──────────────────────────────────────
        elif self.name == "Vault":
            risk_levels = {
                "high":   False,
                "medium": True,
                "low":    True,
            }

            # Vault always checks data risk
            data_risk_terms = [
                "delete", "wipe", "format", "overwrite",
                "corrupt", "damage", "remove", "erase",
            ]
            data_at_risk = any(term in problem for term in data_risk_terms)

            if data_at_risk and risk == "high":
                return {
                    "position": (
                        "Data is at risk in this scenario. "
                        "I will not vote to proceed without a confirmed backup. "
                        "A backup must be created first."
                    ),
                    "vote":    False,
                    "concern": (
                        "HOLD: User data may be at risk. "
                        "Backup must be confirmed before proceeding."
                    ),
                }

            if data_at_risk:
                return {
                    "position": (
                        "Data considerations present. "
                        "Backup will be created before repair runs. "
                        "I approve — with backup protection active."
                    ),
                    "vote":    True,
                    "concern": "Backup required before execution.",
                }

            return {
                "position": (
                    "No direct data risk detected. "
                    "Standard protection is sufficient. Proceed."
                ),
                "vote":    True,
                "concern": None,
            }

        # ── Aegis — Security lens ─────────────────────────────────────────────
        elif self.name == "Aegis":
            sec = self.knowledge["security"]

            threat_terms = list(sec.get("threat_types", {}).keys())
            threat_found = [t for t in threat_terms if t in problem]

            if threat_found:
                return {
                    "position": (
                        f"Security flag: this may involve {', '.join(threat_found)}. "
                        f"The proposed repair should include security scanning. "
                        f"I approve with the condition that security implications "
                        f"are clearly communicated to the user."
                    ),
                    "vote":    True,
                    "concern": (
                        f"Possible {', '.join(threat_found)} involvement. "
                        f"User should be informed."
                    ),
                }

            # Check if repair itself could create security risk
            risky_repairs = ["disable", "uninstall security", "bypass"]
            if any(r in problem for r in risky_repairs):
                return {
                    "position": (
                        "This repair touches security-sensitive components. "
                        "I approve, but the security implications must be "
                        "explained clearly to the user."
                    ),
                    "vote":    True,
                    "concern": "Security-sensitive repair — user must be informed.",
                }

            return {
                "position": (
                    "No security concerns with this repair. "
                    "Codex integrity verified. Proceed."
                ),
                "vote":    True,
                "concern": None,
            }

        # ── Bridge — Plain language lens ─────────────────────────────────────
        elif self.name == "Bridge":
            # Bridge always speaks last
            # Bridge's job: can the person understand and act on this?
            return {
                "position": (
                    "I've reviewed what the council is proposing. "
                    "I can translate this clearly for the person. "
                    "They will understand what was found, what we're doing, "
                    "and what to do if they need to take action themselves."
                ),
                "vote":    True,
                "concern": None,
            }

        return {
            "position": "No assessment available.",
            "vote":     True,
            "concern":  None,
        }


class CouncilDeliberation:
    """
    The full deliberation process.

    The council convenes. Each member speaks.
    They vote. Consensus is required.
    Dissent is recorded.
    Bridge speaks last.
    The person is told everything.
    """

    MEMBERS = [
        ("Atlas",   "OS & Kernel Specialist"),
        ("Stratum", "Hardware & Firmware Expert"),
        ("Relay",   "Network & Connectivity Specialist"),
        ("Vault",   "Storage & Filesystem Expert"),
        ("Aegis",   "Security & Integrity Analyst"),
        ("Bridge",  "Plain Language Translator"),
    ]

    def __init__(self):
        self.logger  = KintoLogger()
        self.codex   = KintoCodex()
        self.voices  = [CouncilVoice(name, role) for name, role in self.MEMBERS]
        self.history = []  # all past deliberations this session

    def convene(self, issue: dict, proposed_repair: dict) -> dict:
        """
        Convene the council for a single issue.
        Returns the deliberation result with full record.
        """
        problem = issue.get("issue", "")
        member  = issue.get("member", "")
        plan    = proposed_repair.get("name", "unknown")
        risk    = proposed_repair.get("risk", "low")

        print(f"\n  ╔══════════════════════════════════════════════════╗")
        print(f"  ║  Council convening on: {problem[:42].ljust(42)}  ║") if len(problem) <= 42 else \
        print(f"  ║  Council convening...                            ║")
        print(f"  ╚══════════════════════════════════════════════════╝\n")

        # Each voice speaks
        voices_record = []
        concerns      = []
        votes_yes     = 0
        votes_no      = 0
        dissent       = []

        for voice in self.voices:
            assessment = voice.speak(issue, proposed_repair)
            voices_record.append(assessment)

            if assessment["vote"]:
                votes_yes += 1
                print(f"  ✦ {voice.name:<10} {assessment['position'][:60]}")
            else:
                votes_no  += 1
                dissent.append(assessment)
                print(f"  ✗ {voice.name:<10} HOLD — {assessment.get('concern', '')[:55]}")

            if assessment.get("concern"):
                concerns.append({
                    "member":  voice.name,
                    "concern": assessment["concern"],
                })

        # Determine required threshold
        thresholds = DELIBERATION_FRAMEWORK["confidence_thresholds"]
        if risk == "high":
            required = 5  # unanimous
            threshold_name = "high_risk_repair"
        elif risk == "medium":
            required = 4
            threshold_name = "medium_risk_repair"
        else:
            required = 3
            threshold_name = "low_risk_repair"

        consensus   = votes_yes >= required
        vote_record = f"{votes_yes} yes, {votes_no} hold — need {required}"

        print(f"\n  Council vote: {vote_record}")

        if consensus:
            verdict = "PROCEED"
            print(f"  Verdict: ✓ CONSENSUS — repair approved\n")
        else:
            verdict = "HOLD"
            print(f"  Verdict: ✗ HOLD — insufficient consensus\n")
            if dissent:
                print(f"  Dissent recorded:")
                for d in dissent:
                    print(f"    {d['member']}: {d.get('concern', '')}")
                print()

        # Build the full deliberation record
        record = {
            "time":       datetime.now().isoformat(),
            "issue":      problem,
            "plan":       plan,
            "risk":       risk,
            "votes_yes":  votes_yes,
            "votes_no":   votes_no,
            "required":   required,
            "consensus":  consensus,
            "verdict":    verdict,
            "voices":     voices_record,
            "concerns":   concerns,
            "dissent":    dissent,
        }

        self.history.append(record)

        # Log the full deliberation
        self.logger.log(
            member  = "COUNCIL",
            action  = "deliberation_complete",
            detail  = (
                f"Issue: {problem[:60]} | "
                f"Plan: {plan} | "
                f"Vote: {vote_record} | "
                f"Verdict: {verdict}"
            ),
            outcome = "consensus" if consensus else "hold"
        )

        # Log dissent separately — always
        for d in dissent:
            self.logger.log(
                member  = d["member"],
                action  = "dissent_recorded",
                detail  = d.get("concern", "No reason given"),
                outcome = "dissent"
            )

        return record

    def plain_language_summary(self, record: dict) -> str:
        """
        Bridge turns the deliberation into something
        the person can read and understand.
        """
        lines = []
        concerns = record.get("concerns", [])
        dissent  = record.get("dissent", [])
        verdict  = record.get("verdict", "HOLD")

        if verdict == "PROCEED":
            lines.append("  The council reviewed this issue together.")
            lines.append("  All members agreed on the repair plan.")

            if concerns:
                lines.append("\n  Things to know:")
                for c in concerns:
                    lines.append(f"    · {c['concern']}")
        else:
            lines.append("  The council reviewed this issue together.")
            lines.append("  We need more information before we can proceed safely.")

            if dissent:
                lines.append("\n  Here is why:")
                for d in dissent:
                    lines.append(f"    · {d.get('concern', 'Needs more review')}")

        return "\n".join(lines)

    def get_history(self) -> list:
        """Return all deliberations this session."""
        return self.history
