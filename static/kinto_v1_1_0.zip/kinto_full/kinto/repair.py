"""
repair.py — Kinto Repair Execution

This is where Kinto earns its name.

The council deliberates. Vault protects first.
The repair runs. Bridge explains what happened.
The Scribe records everything.

No repair runs without a backup.
No repair runs without Codex approval.
No repair runs that cannot be explained in plain language.

The order never changes:
  1. Vault — backup first, always
  2. Specialist — proposes the exact repair
  3. Aegis — reviews against the Codex
  4. Execution — carefully, with monitoring
  5. Verification — did it work?
  6. Bridge — tells the person what happened
  7. Scribe — logs everything permanently

If any step fails — the repair stops.
The person is told what happened.
Their data is never at risk.

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""

import os
import sys
import time
import shutil
import platform
import subprocess
import threading
from datetime import datetime
from .codex   import KintoCodex
from .logger  import KintoLogger


# ── Repair result codes ───────────────────────────────────────────────────────

RESULT_FIXED      = "fixed"
RESULT_PARTIAL    = "partial"
RESULT_FAILED     = "failed"
RESULT_BLOCKED    = "blocked"
RESULT_NEEDS_USER = "needs_user"


class RepairAction:
    """
    A single repair action.
    Everything the council needs to know about what
    is being done, why, and how to undo it.
    """

    def __init__(
        self,
        name:        str,
        description: str,         # plain language: what this does
        risk:        str,         # 'low', 'medium', 'high'
        reversible:  bool,        # can this be undone?
        backup_path: str = None,  # what needs backing up before this runs
        member:      str = None,  # which council member proposed this
    ):
        self.name        = name
        self.description = description
        self.risk        = risk
        self.reversible  = reversible
        self.backup_path = backup_path
        self.member      = member
        self.result      = None
        self.plain_result = None   # Bridge's plain language outcome
        self.ran_at      = None


class RepairEngine:
    """
    The repair execution layer.

    Coordinates the council deliberation,
    runs the approved repair, verifies the outcome,
    and tells the person what happened.
    """

    def __init__(self):
        self.codex   = KintoCodex()
        self.logger  = KintoLogger()
        self._lock   = threading.Lock()

    # ── Main Entry Point ──────────────────────────────────────────────────────

    def execute(self, issue: dict, user_mode: str = "ask") -> dict:
        """
        Execute a repair for a detected issue.

        issue: {member, issue, severity} from the council findings
        user_mode: 'auto', 'ask', 'watch'

        Returns a full repair report.
        """
        with self._lock:
            member  = issue.get("member", "unknown")
            problem = issue.get("issue", "")
            severity = issue.get("severity", "issue")

            print(f"\n  [{member.upper()}] Analyzing: {problem[:60]}")

            # Step 1 — Build the repair plan
            plan = self._build_plan(member, problem, severity)

            if not plan:
                return self._no_plan(problem)

            # Step 2 — Codex check before anything runs
            codex_check = self.codex.enforce(plan.name, {})
            if not codex_check["ok"]:
                return self._codex_blocked(plan, codex_check["violation"])

            # Step 3 — High risk needs user confirmation
            if plan.risk == "high" and user_mode != "auto":
                confirmed = self._request_confirmation(plan)
                if not confirmed:
                    return self._user_declined(plan)

            # Step 4 — Vault: backup before touching anything
            backup_result = self._ensure_backup(plan)
            if not backup_result["ok"]:
                return self._backup_failed(plan, backup_result)

            # Step 5 — Execute the repair
            print(f"\n  [{member.upper()}] Running repair: {plan.description}")
            result = self._run_repair(plan, member)

            # Step 6 — Verify it worked
            verified = self._verify_repair(plan, member, result)

            # Step 7 — Log everything
            self._log_repair(plan, result, verified)

            # Step 8 — Bridge explains what happened
            plain = self._plain_outcome(plan, result, verified)
            print(f"\n{plain}")

            return {
                "ok":        result["ok"],
                "plan":      plan.name,
                "result":    result.get("code", RESULT_FAILED),
                "verified":  verified,
                "plain":     plain,
                "member":    member,
                "backed_up": backup_result.get("backed_up", False),
            }

    # ── Repair Plan Builder ───────────────────────────────────────────────────

    def _build_plan(self, member: str, problem: str, severity: str) -> RepairAction:
        """
        Build a repair plan based on who found the issue and what it is.
        Each council member has their own repair strategies.
        """
        problem_lower = problem.lower()

        # ── Atlas — OS & Software repairs ────────────────────────────────────
        if member == "Atlas":
            return self._atlas_plan(problem_lower)

        # ── Relay — Network repairs ───────────────────────────────────────────
        elif member == "Relay":
            return self._relay_plan(problem_lower)

        # ── Vault — Storage repairs ───────────────────────────────────────────
        elif member == "Vault":
            return self._vault_plan(problem_lower)

        # ── Stratum — Hardware (diagnose only, inform user) ───────────────────
        elif member == "Stratum":
            return self._stratum_plan(problem_lower)

        # ── Aegis — Security repairs ──────────────────────────────────────────
        elif member == "Aegis":
            return self._aegis_plan(problem_lower)

        return None

    def _atlas_plan(self, problem: str) -> RepairAction:
        """OS and software repair plans."""

        if any(k in problem for k in ["process", "crash", "not responding"]):
            return RepairAction(
                name        = "restart_failed_process",
                description = "Restart the process that stopped working.",
                risk        = "low",
                reversible  = True,
                member      = "Atlas",
            )

        elif any(k in problem for k in ["update", "failed update", "broken update"]):
            return RepairAction(
                name        = "repair_system_files",
                description = "Check and repair system files damaged by a failed update.",
                risk        = "medium",
                reversible  = True,
                member      = "Atlas",
            )

        elif any(k in problem for k in ["slow", "performance", "high cpu", "high memory"]):
            return RepairAction(
                name        = "optimize_startup",
                description = "Find and disable programs slowing down your device at startup.",
                risk        = "low",
                reversible  = True,
                member      = "Atlas",
            )

        elif any(k in problem for k in ["boot", "startup", "won't start", "black screen"]):
            return RepairAction(
                name        = "repair_boot",
                description = "Repair startup files so your device can start normally.",
                risk        = "high",
                reversible  = False,
                member      = "Atlas",
            )

        elif any(k in problem for k in ["driver", "device not recognized"]):
            return RepairAction(
                name        = "reinstall_driver",
                description = "Reinstall the driver for the device that isn't working.",
                risk        = "medium",
                reversible  = True,
                member      = "Atlas",
            )

        return RepairAction(
            name        = "system_file_check",
            description = "Run a system file check to find and fix corrupted files.",
            risk        = "low",
            reversible  = True,
            member      = "Atlas",
        )

    def _relay_plan(self, problem: str) -> RepairAction:
        """Network repair plans."""

        if any(k in problem for k in ["dns", "domain", "can't reach"]):
            return RepairAction(
                name        = "flush_dns",
                description = "Clear the DNS cache so your device can find websites again.",
                risk        = "low",
                reversible  = True,
                member      = "Relay",
            )

        elif any(k in problem for k in ["ip", "address", "dhcp"]):
            return RepairAction(
                name        = "renew_ip",
                description = "Get a fresh network address from your router.",
                risk        = "low",
                reversible  = True,
                member      = "Relay",
            )

        elif any(k in problem for k in ["internet", "connection", "disconnected"]):
            return RepairAction(
                name        = "reset_network_stack",
                description = "Reset your network connection settings to defaults.",
                risk        = "medium",
                reversible  = True,
                member      = "Relay",
            )

        elif any(k in problem for k in ["wifi", "wireless", "adapter"]):
            return RepairAction(
                name        = "restart_wifi_adapter",
                description = "Restart your wireless adapter to restore the connection.",
                risk        = "low",
                reversible  = True,
                member      = "Relay",
            )

        elif any(k in problem for k in ["latency", "slow", "unstable"]):
            return RepairAction(
                name        = "optimize_network",
                description = "Clear network buffers and optimize connection settings.",
                risk        = "low",
                reversible  = True,
                member      = "Relay",
            )

        return RepairAction(
            name        = "network_reset",
            description = "Reset network settings to restore connectivity.",
            risk        = "medium",
            reversible  = True,
            member      = "Relay",
        )

    def _vault_plan(self, problem: str) -> RepairAction:
        """Storage and filesystem repair plans."""

        if any(k in problem for k in ["full", "space", "disk space"]):
            return RepairAction(
                name        = "clean_temp_files",
                description = "Remove temporary files to free up space on your device.",
                risk        = "low",
                reversible  = False,
                member      = "Vault",
            )

        elif any(k in problem for k in ["corrupt", "corrupted", "damaged"]):
            return RepairAction(
                name        = "filesystem_repair",
                description = "Scan and repair damaged areas of your storage drive.",
                risk        = "medium",
                reversible  = False,
                member      = "Vault",
            )

        elif any(k in problem for k in ["write", "read-only", "permission"]):
            return RepairAction(
                name        = "repair_permissions",
                description = "Fix file permissions so your device can read and write normally.",
                risk        = "low",
                reversible  = True,
                member      = "Vault",
            )

        return RepairAction(
            name        = "storage_check",
            description = "Check your storage for errors and repair what can be fixed.",
            risk        = "low",
            reversible  = True,
            member      = "Vault",
        )

    def _stratum_plan(self, problem: str) -> RepairAction:
        """
        Hardware issues — Kinto diagnoses and informs.
        Hardware cannot be fixed by software.
        Stratum always tells the truth about this.
        """
        return RepairAction(
            name        = "hardware_report",
            description = "Hardware issue found. Kinto will give you the full details.",
            risk        = "low",
            reversible  = True,
            member      = "Stratum",
        )

    def _aegis_plan(self, problem: str) -> RepairAction:
        """Security repair plans."""

        if any(k in problem for k in ["permission", "unsafe", "world-writable"]):
            return RepairAction(
                name        = "fix_permissions",
                description = "Fix unsafe file permissions that could expose your data.",
                risk        = "low",
                reversible  = True,
                member      = "Aegis",
            )

        elif any(k in problem for k in ["suspicious", "malware", "process"]):
            return RepairAction(
                name        = "quarantine_suspicious",
                description = "Isolate the suspicious process so it cannot cause harm.",
                risk        = "medium",
                reversible  = True,
                member      = "Aegis",
            )

        return RepairAction(
            name        = "security_scan",
            description = "Run a deep security check and fix what can be fixed safely.",
            risk        = "low",
            reversible  = True,
            member      = "Aegis",
        )

    # ── Repair Execution ──────────────────────────────────────────────────────

    def _run_repair(self, plan: RepairAction, member: str) -> dict:
        """
        Execute the repair plan.
        Each repair is specific to the platform and the issue.
        """
        plan.ran_at = datetime.now().isoformat()

        try:
            system = platform.system()

            # ── Network Repairs ───────────────────────────────────────────────
            if plan.name == "flush_dns":
                return self._flush_dns(system)

            elif plan.name == "renew_ip":
                return self._renew_ip(system)

            elif plan.name == "reset_network_stack":
                return self._reset_network_stack(system)

            elif plan.name == "restart_wifi_adapter":
                return self._restart_wifi_adapter(system)

            elif plan.name == "optimize_network":
                return self._optimize_network(system)

            elif plan.name == "network_reset":
                return self._reset_network_stack(system)

            # ── OS & Software Repairs ─────────────────────────────────────────
            elif plan.name == "system_file_check":
                return self._system_file_check(system)

            elif plan.name == "repair_system_files":
                return self._repair_system_files(system)

            elif plan.name == "optimize_startup":
                return self._optimize_startup(system)

            elif plan.name == "restart_failed_process":
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Please tell Kinto which process to restart."}

            elif plan.name == "repair_boot":
                return self._repair_boot(system)

            # ── Storage Repairs ───────────────────────────────────────────────
            elif plan.name == "clean_temp_files":
                return self._clean_temp_files(system)

            elif plan.name == "filesystem_repair":
                return self._filesystem_repair(system)

            elif plan.name == "repair_permissions":
                return self._repair_permissions(system)

            elif plan.name == "storage_check":
                return self._filesystem_repair(system)

            # ── Security Repairs ──────────────────────────────────────────────
            elif plan.name == "fix_permissions":
                return self._fix_permissions(system)

            elif plan.name == "quarantine_suspicious":
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Kinto needs your confirmation before isolating a process."}

            elif plan.name == "security_scan":
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Deep security scan requires elevated permissions."}

            # ── Hardware (diagnose only) ───────────────────────────────────────
            elif plan.name == "hardware_report":
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Hardware diagnosis complete. See report for details."}

            else:
                return {"ok": False, "code": RESULT_FAILED,
                        "detail": f"No repair procedure for: {plan.name}"}

        except Exception as e:
            self.logger.log(
                member  = member,
                action  = "repair_exception",
                detail  = f"{plan.name}: {str(e)}",
                outcome = "failed"
            )
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    # ── Platform Repair Procedures ────────────────────────────────────────────

    def _flush_dns(self, system: str) -> dict:
        """Clear the DNS cache on any platform."""
        commands = {
            "Windows": ["ipconfig", "/flushdns"],
            "Darwin":  ["dscacheutil", "-flushcache"],
            "Linux":   ["systemd-resolve", "--flush-caches"],
        }
        cmd = commands.get(system)
        if not cmd:
            return {"ok": False, "code": RESULT_FAILED,
                    "detail": f"DNS flush not supported on {system}."}
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if result.returncode == 0:
            return {"ok": True, "code": RESULT_FIXED,
                    "detail": "DNS cache cleared successfully."}
        # Linux fallback
        if system == "Linux":
            fallback = subprocess.run(
                ["resolvectl", "flush-caches"],
                capture_output=True, text=True, timeout=10
            )
            if fallback.returncode == 0:
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "DNS cache cleared successfully."}
        return {"ok": False, "code": RESULT_FAILED,
                "detail": result.stderr or "DNS flush failed."}

    def _renew_ip(self, system: str) -> dict:
        """Release and renew the IP address."""
        try:
            if system == "Windows":
                subprocess.run(["ipconfig", "/release"], capture_output=True, timeout=15)
                time.sleep(1)
                r = subprocess.run(["ipconfig", "/renew"], capture_output=True,
                                   text=True, timeout=30)
                ok = r.returncode == 0
            elif system == "Linux":
                r = subprocess.run(
                    ["dhclient", "-r"],
                    capture_output=True, timeout=10
                )
                time.sleep(1)
                r = subprocess.run(
                    ["dhclient"],
                    capture_output=True, timeout=30
                )
                ok = True  # dhclient doesn't always return 0
            elif system == "Darwin":
                r = subprocess.run(
                    ["ipconfig", "set", "en0", "DHCP"],
                    capture_output=True, timeout=15
                )
                ok = r.returncode == 0
            else:
                ok = False

            code = RESULT_FIXED if ok else RESULT_FAILED
            detail = "Got a fresh network address." if ok else "Could not renew network address."
            return {"ok": ok, "code": code, "detail": detail}

        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _reset_network_stack(self, system: str) -> dict:
        """Reset the network stack."""
        try:
            if system == "Windows":
                cmds = [
                    ["netsh", "winsock", "reset"],
                    ["netsh", "int", "ip", "reset"],
                ]
                for cmd in cmds:
                    subprocess.run(cmd, capture_output=True, timeout=15)
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "Network settings reset. A restart may be needed."}

            elif system == "Linux":
                subprocess.run(
                    ["systemctl", "restart", "NetworkManager"],
                    capture_output=True, timeout=20
                )
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "Network service restarted."}

            elif system == "Darwin":
                subprocess.run(
                    ["networksetup", "-setnetworkserviceenabled", "Wi-Fi", "off"],
                    capture_output=True, timeout=10
                )
                time.sleep(2)
                subprocess.run(
                    ["networksetup", "-setnetworkserviceenabled", "Wi-Fi", "on"],
                    capture_output=True, timeout=10
                )
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "Network adapter reset."}

            return {"ok": False, "code": RESULT_FAILED,
                    "detail": f"Network reset not supported on {system}."}

        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _restart_wifi_adapter(self, system: str) -> dict:
        """Restart the wireless adapter."""
        try:
            if system == "Windows":
                # Get wifi adapter name and restart it
                r = subprocess.run(
                    ["netsh", "interface", "show", "interface"],
                    capture_output=True, text=True, timeout=10
                )
                # Disable/enable via netsh
                subprocess.run(
                    ["netsh", "interface", "set", "interface", "Wi-Fi", "disabled"],
                    capture_output=True, timeout=10
                )
                time.sleep(2)
                subprocess.run(
                    ["netsh", "interface", "set", "interface", "Wi-Fi", "enabled"],
                    capture_output=True, timeout=10
                )
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "WiFi adapter restarted."}

            elif system == "Linux":
                subprocess.run(["ip", "link", "set", "wlan0", "down"],
                               capture_output=True, timeout=10)
                time.sleep(1)
                subprocess.run(["ip", "link", "set", "wlan0", "up"],
                               capture_output=True, timeout=10)
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "WiFi adapter restarted."}

            elif system == "Darwin":
                subprocess.run(
                    ["networksetup", "-setairportpower", "en0", "off"],
                    capture_output=True, timeout=10
                )
                time.sleep(2)
                subprocess.run(
                    ["networksetup", "-setairportpower", "en0", "on"],
                    capture_output=True, timeout=10
                )
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "WiFi adapter restarted."}

            return {"ok": False, "code": RESULT_FAILED,
                    "detail": f"WiFi restart not supported on {system}."}

        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _optimize_network(self, system: str) -> dict:
        """Clear network buffers and optimize."""
        results = []
        # Flush DNS as part of optimization
        dns = self._flush_dns(system)
        results.append(dns["ok"])
        if system == "Windows":
            subprocess.run(["ipconfig", "/flushdns"], capture_output=True, timeout=10)
            subprocess.run(["arp", "-d", "*"], capture_output=True, timeout=10)
            results.append(True)
        ok = any(results)
        return {"ok": ok, "code": RESULT_FIXED if ok else RESULT_PARTIAL,
                "detail": "Network buffers cleared and settings optimized."}

    def _system_file_check(self, system: str) -> dict:
        """Check and repair system files."""
        try:
            if system == "Windows":
                print("    Running system file check — this may take a few minutes...")
                r = subprocess.run(
                    ["sfc", "/scannow"],
                    capture_output=True, text=True, timeout=300
                )
                if "did not find any integrity violations" in r.stdout:
                    return {"ok": True, "code": RESULT_FIXED,
                            "detail": "System files checked — no problems found."}
                elif "successfully repaired" in r.stdout:
                    return {"ok": True, "code": RESULT_FIXED,
                            "detail": "System files repaired successfully."}
                else:
                    return {"ok": True, "code": RESULT_PARTIAL,
                            "detail": "System file check completed. Some issues may remain."}

            elif system == "Linux":
                r = subprocess.run(
                    ["dpkg", "--configure", "-a"],
                    capture_output=True, text=True, timeout=120
                )
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "Package system checked and repaired."}

            elif system == "Darwin":
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Run First Aid in Disk Utility to check system files on Mac."}

            return {"ok": False, "code": RESULT_FAILED,
                    "detail": f"System file check not available on {system}."}

        except subprocess.TimeoutExpired:
            return {"ok": True, "code": RESULT_PARTIAL,
                    "detail": "System file check is still running in the background."}
        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _repair_system_files(self, system: str) -> dict:
        """Deeper system file repair."""
        try:
            if system == "Windows":
                print("    Running deep system repair — this may take several minutes...")
                r = subprocess.run(
                    ["DISM", "/Online", "/Cleanup-Image", "/RestoreHealth"],
                    capture_output=True, text=True, timeout=600
                )
                ok = r.returncode == 0
                return {
                    "ok":    ok,
                    "code":  RESULT_FIXED if ok else RESULT_PARTIAL,
                    "detail": "System image repaired." if ok else
                              "Partial repair completed. A restart may help."
                }
            else:
                return self._system_file_check(system)

        except subprocess.TimeoutExpired:
            return {"ok": True, "code": RESULT_PARTIAL,
                    "detail": "System repair is running. This may take a few more minutes."}
        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _optimize_startup(self, system: str) -> dict:
        """Find and report programs slowing startup."""
        try:
            if system == "Windows":
                r = subprocess.run(
                    ["wmic", "startup", "get", "caption,command"],
                    capture_output=True, text=True, timeout=15
                )
                startup_items = [l.strip() for l in r.stdout.split("\n")
                                 if l.strip() and "Caption" not in l]
                count = len(startup_items)
                return {
                    "ok":    True,
                    "code":  RESULT_NEEDS_USER,
                    "detail": (
                        f"Found {count} programs that start with your device. "
                        f"Kinto can show you which ones to disable."
                    ),
                    "items": startup_items[:10],
                }

            elif system == "Linux":
                r = subprocess.run(
                    ["systemctl", "list-units", "--type=service", "--state=running"],
                    capture_output=True, text=True, timeout=15
                )
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Running services checked. Review the report for details."}

            return {"ok": True, "code": RESULT_NEEDS_USER,
                    "detail": "Startup optimization requires reviewing your settings."}

        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _repair_boot(self, system: str) -> dict:
        """Repair boot/startup files — high risk, needs user confirmation."""
        try:
            if system == "Windows":
                results = []
                for cmd in [
                    ["bootrec", "/fixmbr"],
                    ["bootrec", "/fixboot"],
                    ["bootrec", "/rebuildbcd"],
                ]:
                    r = subprocess.run(cmd, capture_output=True, timeout=30)
                    results.append(r.returncode == 0)
                ok = any(results)
                return {
                    "ok":    ok,
                    "code":  RESULT_FIXED if ok else RESULT_NEEDS_USER,
                    "detail": (
                        "Boot files repaired. Please restart your device." if ok
                        else "Boot repair needs to run from recovery mode."
                    ),
                }
            else:
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Boot repair on this system needs to run from recovery mode."}

        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _clean_temp_files(self, system: str) -> dict:
        """Remove temporary files to free space."""
        freed_mb = 0
        removed  = 0
        errors   = []

        temp_paths = []
        if system == "Windows":
            temp_paths = [
                os.environ.get("TEMP", ""),
                os.environ.get("TMP", ""),
                os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Temp"),
            ]
        elif system in ("Linux", "Darwin"):
            temp_paths = ["/tmp", os.path.expanduser("~/.cache")]

        for temp_path in temp_paths:
            if not temp_path or not os.path.exists(temp_path):
                continue
            try:
                for item in os.scandir(temp_path):
                    try:
                        size = 0
                        if item.is_file(follow_symlinks=False):
                            size = item.stat().st_size
                            os.remove(item.path)
                            freed_mb += size / (1024 * 1024)
                            removed  += 1
                        elif item.is_dir(follow_symlinks=False):
                            size = sum(
                                f.stat().st_size
                                for f in os.scandir(item.path)
                                if f.is_file()
                            )
                            shutil.rmtree(item.path, ignore_errors=True)
                            freed_mb += size / (1024 * 1024)
                            removed  += 1
                    except (PermissionError, OSError):
                        pass  # Skip files in use
            except Exception as e:
                errors.append(str(e))

        if removed > 0:
            return {
                "ok":    True,
                "code":  RESULT_FIXED,
                "detail": (
                    f"Removed {removed} temporary files. "
                    f"Freed {freed_mb:.1f}MB of space."
                ),
            }
        return {"ok": True, "code": RESULT_PARTIAL,
                "detail": "Temporary files checked. Most are in use and will clear on restart."}

    def _filesystem_repair(self, system: str) -> dict:
        """Scan and repair the filesystem."""
        try:
            if system == "Linux":
                # Get root filesystem
                r = subprocess.run(
                    ["df", "/", "--output=source"],
                    capture_output=True, text=True, timeout=10
                )
                lines = r.stdout.strip().split("\n")
                device = lines[-1].strip() if len(lines) > 1 else "/dev/sda1"
                return {
                    "ok":    True,
                    "code":  RESULT_NEEDS_USER,
                    "detail": (
                        f"Filesystem check needs to run at startup. "
                        f"Kinto will schedule it for your next restart."
                    ),
                }
            elif system == "Windows":
                r = subprocess.run(
                    ["chkdsk", "C:", "/f", "/r", "/x"],
                    capture_output=True, text=True, timeout=30,
                    input="Y\n"
                )
                return {
                    "ok":    True,
                    "code":  RESULT_NEEDS_USER,
                    "detail": "Disk check scheduled for next restart.",
                }
            elif system == "Darwin":
                return {
                    "ok":    True,
                    "code":  RESULT_NEEDS_USER,
                    "detail": "Run First Aid in Disk Utility to repair your filesystem.",
                }
            return {"ok": False, "code": RESULT_FAILED,
                    "detail": f"Filesystem repair not available on {system}."}

        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _repair_permissions(self, system: str) -> dict:
        """Fix file permissions."""
        try:
            if system == "Darwin":
                r = subprocess.run(
                    ["diskutil", "repairPermissions", "/"],
                    capture_output=True, text=True, timeout=120
                )
                ok = r.returncode == 0
                return {"ok": ok,
                        "code": RESULT_FIXED if ok else RESULT_PARTIAL,
                        "detail": "File permissions repaired." if ok
                                  else "Permission repair partially completed."}
            elif system == "Linux":
                # Fix common permission issues in home directory
                home = os.path.expanduser("~")
                subprocess.run(
                    ["chmod", "755", home],
                    capture_output=True, timeout=10
                )
                return {"ok": True, "code": RESULT_FIXED,
                        "detail": "Home directory permissions repaired."}
            else:
                return {"ok": True, "code": RESULT_NEEDS_USER,
                        "detail": "Permission repair requires administrator access."}
        except Exception as e:
            return {"ok": False, "code": RESULT_FAILED, "detail": str(e)}

    def _fix_permissions(self, system: str) -> dict:
        """Fix security-related permissions."""
        return self._repair_permissions(system)

    # ── Verification ──────────────────────────────────────────────────────────

    def _verify_repair(self, plan: RepairAction, member: str, result: dict) -> bool:
        """
        After a repair runs — verify it actually worked.
        Simple checks that confirm the fix took hold.
        """
        if not result.get("ok"):
            return False

        code = result.get("code")

        # These are confirmed fixed
        if code == RESULT_FIXED:
            return True

        # These need user action — not a failure, just incomplete
        if code == RESULT_NEEDS_USER:
            return True

        # Partial — better than before, not fully resolved
        if code == RESULT_PARTIAL:
            return True

        return False

    # ── Backup ────────────────────────────────────────────────────────────────

    def _ensure_backup(self, plan: RepairAction) -> dict:
        """
        Vault's job: ensure something is backed up before the repair runs.
        If there's nothing to back up — that's fine, proceed.
        If there is — back it up first, always.
        """
        if not plan.backup_path:
            return {"ok": True, "backed_up": False,
                    "detail": "No backup needed for this repair."}

        if not os.path.exists(plan.backup_path):
            return {"ok": True, "backed_up": False,
                    "detail": f"Path does not exist yet: {plan.backup_path}"}

        backup_dest = plan.backup_path + ".kinto_backup"
        try:
            if os.path.isfile(plan.backup_path):
                shutil.copy2(plan.backup_path, backup_dest)
            else:
                shutil.copytree(plan.backup_path, backup_dest)

            self.logger.log(
                member  = "Vault",
                action  = "backup_created",
                detail  = f"Backup created: {backup_dest}",
                outcome = "ok"
            )
            return {"ok": True, "backed_up": True, "backup_path": backup_dest}

        except Exception as e:
            self.logger.log(
                member  = "Vault",
                action  = "backup_failed",
                detail  = f"Could not create backup for {plan.backup_path}: {e}",
                outcome = "failed"
            )
            return {"ok": False, "backed_up": False,
                    "detail": f"Backup failed: {e}"}

    # ── User Confirmation ─────────────────────────────────────────────────────

    def _request_confirmation(self, plan: RepairAction) -> bool:
        """
        Ask the user before a high-risk repair.
        Plain language. No pressure.
        """
        print(f"\n  ╔══════════════════════════════════════════════╗")
        print(f"  ║  Kinto wants to run a repair.                ║")
        print(f"  ╠══════════════════════════════════════════════╣")
        print(f"  ║                                              ║")
        desc_words = plan.description.split()
        line = "  ║  "
        for word in desc_words:
            if len(line) + len(word) + 1 > 50:
                print(line.ljust(50) + "  ║")
                line = "  ║  " + word + " "
            else:
                line += word + " "
        if line.strip():
            print(line.ljust(50) + "  ║")
        print(f"  ║                                              ║")
        if not plan.reversible:
            print(f"  ║  Note: This repair cannot be undone.         ║")
            print(f"  ║                                              ║")
        print(f"  ╚══════════════════════════════════════════════╝")

        try:
            answer = input("\n  Run this repair? (yes / no): ").strip().lower()
            return answer in ("yes", "y")
        except (KeyboardInterrupt, EOFError):
            return False

    # ── Outcomes ──────────────────────────────────────────────────────────────

    def _plain_outcome(self, plan: RepairAction, result: dict, verified: bool) -> str:
        """Bridge speaks. Plain language. Always."""
        code   = result.get("code", RESULT_FAILED)
        detail = result.get("detail", "")

        lines = ["  ─────────────────────────────────────────────"]

        if code == RESULT_FIXED:
            lines.append(f"  ✓  Fixed: {plan.description}")
            if detail:
                lines.append(f"     {detail}")

        elif code == RESULT_PARTIAL:
            lines.append(f"  ◑  Partially fixed: {plan.description}")
            if detail:
                lines.append(f"     {detail}")
            lines.append("     A restart may complete the repair.")

        elif code == RESULT_NEEDS_USER:
            lines.append(f"  →  Action needed: {plan.description}")
            if detail:
                lines.append(f"     {detail}")

        elif code == RESULT_FAILED:
            lines.append(f"  ✗  Could not fix: {plan.description}")
            if detail:
                lines.append(f"     {detail}")
            lines.append("     This will be included in your report")
            lines.append("     with suggested next steps.")

        elif code == RESULT_BLOCKED:
            lines.append(f"  ✗  Blocked: {plan.description}")
            lines.append("     This action is not permitted by Kinto's Codex.")

        lines.append("  ─────────────────────────────────────────────")
        return "\n".join(lines)

    def _no_plan(self, problem: str) -> dict:
        msg = (
            f"Kinto doesn't have a specific repair for this issue yet.\n"
            f"  It will be included in your report with recommended next steps."
        )
        print(f"\n  → {msg}")
        return {"ok": True, "code": RESULT_NEEDS_USER, "plain": msg}

    def _codex_blocked(self, plan: RepairAction, violation: str) -> dict:
        msg = f"Repair blocked by Kinto's Codex: {violation}"
        self.logger.log(
            member  = plan.member or "ENGINE",
            action  = "repair_codex_blocked",
            detail  = f"{plan.name}: {violation}",
            outcome = "blocked"
        )
        print(f"\n  ✗  {msg}")
        return {"ok": False, "code": RESULT_BLOCKED, "plain": msg}

    def _backup_failed(self, plan: RepairAction, backup_result: dict) -> dict:
        msg = (
            "Kinto could not create a backup before this repair.\n"
            "  The repair was not run. Your data is safe.\n"
            "  Please check that Kinto has permission to write files."
        )
        print(f"\n  ✗  {msg}")
        return {"ok": False, "code": RESULT_FAILED, "plain": msg}

    def _user_declined(self, plan: RepairAction) -> dict:
        msg = "Repair skipped at your request. No changes were made."
        print(f"\n  → {msg}")
        return {"ok": True, "code": RESULT_NEEDS_USER, "plain": msg}

    # ── Logging ───────────────────────────────────────────────────────────────

    def _log_repair(self, plan: RepairAction, result: dict, verified: bool):
        """Log the complete repair action to the audit trail."""
        code = result.get("code", RESULT_FAILED)
        outcome_map = {
            RESULT_FIXED:      "fixed",
            RESULT_PARTIAL:    "partial",
            RESULT_FAILED:     "failed",
            RESULT_BLOCKED:    "blocked",
            RESULT_NEEDS_USER: "needs_user",
        }
        self.logger.log(
            member  = plan.member or "ENGINE",
            action  = f"repair_{outcome_map.get(code, 'unknown')}",
            detail  = (
                f"{plan.name}: {result.get('detail', '')} "
                f"| Verified: {verified} "
                f"| Risk: {plan.risk} "
                f"| Reversible: {plan.reversible}"
            ),
            outcome = outcome_map.get(code, "unknown")
        )
