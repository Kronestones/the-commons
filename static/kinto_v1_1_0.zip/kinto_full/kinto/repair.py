# EBVV8ulhGPQDkbAGCBiqYhnt1hMINg8WmyuQJjpUf4jTBzRI0Xhqn3o8fuUnDima
# 4g7JxMV51FWqFrx6iuLeJKdsUEyH6GUEDkliuZ13H0dBg8er3QeWFo2ZNqbsGbDz
""""""
import os
import sys
import time
import shutil
import platform
import subprocess
import threading
from datetime import datetime
from .codex import KintoCodex
from .logger import KintoLogger
_BeKvpBbQjASm = 'fixed'
_KTuZWVgqYRpq = 'partial'
_lPpKQbXYYYdP = 'failed'
_NhzETvUUeJLk = 'blocked'
_lQFMPMXsGCLP = 'needs_user'

class _YlgqCuPyufzt:
    """"""

    def __init__(self, _JIPrucpnCsUu: str, _MTzQepWwQuIv: str, _XoVVIEiiSkKn: str, _NskdJTENSrhr: bool, _qDKgJFzpbeHV: str=None, _URJjUlOPPQvO: str=None):
        self.name = _JIPrucpnCsUu
        self.description = _MTzQepWwQuIv
        self.risk = _XoVVIEiiSkKn
        self.reversible = _NskdJTENSrhr
        self.backup_path = _qDKgJFzpbeHV
        self.member = _URJjUlOPPQvO
        self.result = None
        self.plain_result = None
        self.ran_at = None

class _zbrJtrDXxJXm:
    """"""

    def __init__(self):
        self.codex = _ZdOBrwTHgmeu()
        self.logger = _qtpdxbgVKlhS()
        self._lock = threading.Lock()

    def _aflZtNABZMXp(self, _OqYfZmUdRRSS: dict, _MUZXypdWwSvb: str='ask') -> dict:
        """"""
        with self._lock:
            _URJjUlOPPQvO = _OqYfZmUdRRSS.get('member', 'unknown')
            _QVmGYJZJbKgg = _OqYfZmUdRRSS.get('issue', '')
            _xFmJSWxwAyjR = _OqYfZmUdRRSS.get('severity', 'issue')
            print(f'\n  [{_URJjUlOPPQvO.upper()}] Analyzing: {_QVmGYJZJbKgg[:60]}')
            _gIFmlXvnFvoH = self._build_plan(_URJjUlOPPQvO, _QVmGYJZJbKgg, _xFmJSWxwAyjR)
            if not _gIFmlXvnFvoH:
                return self._no_plan(_QVmGYJZJbKgg)
            _nFuAKgJRSFuB = self.codex.enforce(_gIFmlXvnFvoH.name, {})
            if not _nFuAKgJRSFuB['ok']:
                return self._codex_blocked(_gIFmlXvnFvoH, _nFuAKgJRSFuB['violation'])
            if _gIFmlXvnFvoH.risk == 'high' and _MUZXypdWwSvb != 'auto':
                _kkigTQcVLyrL = self._request_confirmation(_gIFmlXvnFvoH)
                if not _kkigTQcVLyrL:
                    return self._user_declined(_gIFmlXvnFvoH)
            _BnIuCgqZqJNw = self._ensure_backup(_gIFmlXvnFvoH)
            if not _BnIuCgqZqJNw['ok']:
                return self._backup_failed(_gIFmlXvnFvoH, _BnIuCgqZqJNw)
            print(f'\n  [{_URJjUlOPPQvO.upper()}] Running repair: {_gIFmlXvnFvoH.description}')
            _qKvUBlAHoIlE = self._run_repair(_gIFmlXvnFvoH, _URJjUlOPPQvO)
            _bVSWubGlONJN = self._verify_repair(_gIFmlXvnFvoH, _URJjUlOPPQvO, _qKvUBlAHoIlE)
            self._log_repair(_gIFmlXvnFvoH, _qKvUBlAHoIlE, _bVSWubGlONJN)
            _wvDIDDYKqILi = self._plain_outcome(_gIFmlXvnFvoH, _qKvUBlAHoIlE, _bVSWubGlONJN)
            print(f'\n{_wvDIDDYKqILi}')
            return {'ok': _qKvUBlAHoIlE['ok'], 'plan': _gIFmlXvnFvoH.name, 'result': _qKvUBlAHoIlE.get('code', _lPpKQbXYYYdP), 'verified': _bVSWubGlONJN, 'plain': _wvDIDDYKqILi, 'member': _URJjUlOPPQvO, 'backed_up': _BnIuCgqZqJNw.get('backed_up', False)}

    def _pwsVZjSoGloq(self, _URJjUlOPPQvO: str, _QVmGYJZJbKgg: str, _xFmJSWxwAyjR: str) -> _YlgqCuPyufzt:
        """"""
        _mxDuunJYvlgN = _QVmGYJZJbKgg.lower()
        if _URJjUlOPPQvO == 'Atlas':
            return self._atlas_plan(_mxDuunJYvlgN)
        elif _URJjUlOPPQvO == 'Relay':
            return self._relay_plan(_mxDuunJYvlgN)
        elif _URJjUlOPPQvO == 'Vault':
            return self._vault_plan(_mxDuunJYvlgN)
        elif _URJjUlOPPQvO == 'Stratum':
            return self._stratum_plan(_mxDuunJYvlgN)
        elif _URJjUlOPPQvO == 'Aegis':
            return self._aegis_plan(_mxDuunJYvlgN)
        return None

    def _YMhpePUpJXxf(self, _QVmGYJZJbKgg: str) -> _YlgqCuPyufzt:
        """"""
        if any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['process', 'crash', 'not responding'])):
            return _YlgqCuPyufzt(name='restart_failed_process', description='Restart the process that stopped working.', risk='low', reversible=True, member='Atlas')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['update', 'failed update', 'broken update'])):
            return _YlgqCuPyufzt(name='repair_system_files', description='Check and repair system files damaged by a failed update.', risk='medium', reversible=True, member='Atlas')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['slow', 'performance', 'high cpu', 'high memory'])):
            return _YlgqCuPyufzt(name='optimize_startup', description='Find and disable programs slowing down your device at startup.', risk='low', reversible=True, member='Atlas')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['boot', 'startup', "won't start", 'black screen'])):
            return _YlgqCuPyufzt(name='repair_boot', description='Repair startup files so your device can start normally.', risk='high', reversible=False, member='Atlas')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['driver', 'device not recognized'])):
            return _YlgqCuPyufzt(name='reinstall_driver', description="Reinstall the driver for the device that isn't working.", risk='medium', reversible=True, member='Atlas')
        return _YlgqCuPyufzt(name='system_file_check', description='Run a system file check to find and fix corrupted files.', risk='low', reversible=True, member='Atlas')

    def _kaNwaBTFzHiQ(self, _QVmGYJZJbKgg: str) -> _YlgqCuPyufzt:
        """"""
        if any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['dns', 'domain', "can't reach"])):
            return _YlgqCuPyufzt(name='flush_dns', description='Clear the DNS cache so your device can find websites again.', risk='low', reversible=True, member='Relay')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['ip', 'address', 'dhcp'])):
            return _YlgqCuPyufzt(name='renew_ip', description='Get a fresh network address from your router.', risk='low', reversible=True, member='Relay')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['internet', 'connection', 'disconnected'])):
            return _YlgqCuPyufzt(name='reset_network_stack', description='Reset your network connection settings to defaults.', risk='medium', reversible=True, member='Relay')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['wifi', 'wireless', 'adapter'])):
            return _YlgqCuPyufzt(name='restart_wifi_adapter', description='Restart your wireless adapter to restore the connection.', risk='low', reversible=True, member='Relay')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['latency', 'slow', 'unstable'])):
            return _YlgqCuPyufzt(name='optimize_network', description='Clear network buffers and optimize connection settings.', risk='low', reversible=True, member='Relay')
        return _YlgqCuPyufzt(name='network_reset', description='Reset network settings to restore connectivity.', risk='medium', reversible=True, member='Relay')

    def _eHhTyVUkpOgs(self, _QVmGYJZJbKgg: str) -> _YlgqCuPyufzt:
        """"""
        if any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['full', 'space', 'disk space'])):
            return _YlgqCuPyufzt(name='clean_temp_files', description='Remove temporary files to free up space on your device.', risk='low', reversible=False, member='Vault')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['corrupt', 'corrupted', 'damaged'])):
            return _YlgqCuPyufzt(name='filesystem_repair', description='Scan and repair damaged areas of your storage drive.', risk='medium', reversible=False, member='Vault')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['write', 'read-only', 'permission'])):
            return _YlgqCuPyufzt(name='repair_permissions', description='Fix file permissions so your device can read and write normally.', risk='low', reversible=True, member='Vault')
        return _YlgqCuPyufzt(name='storage_check', description='Check your storage for errors and repair what can be fixed.', risk='low', reversible=True, member='Vault')

    def _BtDhYQgWqfXM(self, _QVmGYJZJbKgg: str) -> _YlgqCuPyufzt:
        """"""
        return _YlgqCuPyufzt(name='hardware_report', description='Hardware issue found. Kinto will give you the full details.', risk='low', reversible=True, member='Stratum')

    def _IJdKIvqdxKTo(self, _QVmGYJZJbKgg: str) -> _YlgqCuPyufzt:
        """"""
        if any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['permission', 'unsafe', 'world-writable'])):
            return _YlgqCuPyufzt(name='fix_permissions', description='Fix unsafe file permissions that could expose your data.', risk='low', reversible=True, member='Aegis')
        elif any((_JcGqVQmidznz in _QVmGYJZJbKgg for _JcGqVQmidznz in ['suspicious', 'malware', 'process'])):
            return _YlgqCuPyufzt(name='quarantine_suspicious', description='Isolate the suspicious process so it cannot cause harm.', risk='medium', reversible=True, member='Aegis')
        return _YlgqCuPyufzt(name='security_scan', description='Run a deep security check and fix what can be fixed safely.', risk='low', reversible=True, member='Aegis')

    def _JyERRiNtsmSE(self, _gIFmlXvnFvoH: _YlgqCuPyufzt, _URJjUlOPPQvO: str) -> dict:
        """"""
        _gIFmlXvnFvoH.ran_at = datetime.now().isoformat()
        try:
            _JPuzEKTKyLEH = _fqTyNLgANvRf.system()
            if _gIFmlXvnFvoH.name == 'flush_dns':
                return self._flush_dns(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'renew_ip':
                return self._renew_ip(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'reset_network_stack':
                return self._reset_network_stack(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'restart_wifi_adapter':
                return self._restart_wifi_adapter(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'optimize_network':
                return self._optimize_network(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'network_reset':
                return self._reset_network_stack(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'system_file_check':
                return self._system_file_check(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'repair_system_files':
                return self._repair_system_files(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'optimize_startup':
                return self._optimize_startup(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'restart_failed_process':
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Please tell Kinto which process to restart.'}
            elif _gIFmlXvnFvoH.name == 'repair_boot':
                return self._repair_boot(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'clean_temp_files':
                return self._clean_temp_files(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'filesystem_repair':
                return self._filesystem_repair(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'repair_permissions':
                return self._repair_permissions(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'storage_check':
                return self._filesystem_repair(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'fix_permissions':
                return self._fix_permissions(_JPuzEKTKyLEH)
            elif _gIFmlXvnFvoH.name == 'quarantine_suspicious':
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Kinto needs your confirmation before isolating a process.'}
            elif _gIFmlXvnFvoH.name == 'security_scan':
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Deep security scan requires elevated permissions.'}
            elif _gIFmlXvnFvoH.name == 'hardware_report':
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Hardware diagnosis complete. See report for details.'}
            else:
                return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': f'No repair procedure for: {_gIFmlXvnFvoH.name}'}
        except Exception as e:
            self.logger.log(member=_URJjUlOPPQvO, action='repair_exception', detail=f'{_gIFmlXvnFvoH.name}: {str(_ZzKQqAfQTafR)}', outcome='failed')
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _pERApriXHUAN(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        _bmfHdbmHIuQu = {'Windows': ['ipconfig', '/flushdns'], 'Darwin': ['dscacheutil', '-flushcache'], 'Linux': ['systemd-resolve', '--flush-caches']}
        _npgAxZtYWKzg = _bmfHdbmHIuQu.get(_JPuzEKTKyLEH)
        if not _npgAxZtYWKzg:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': f'DNS flush not supported on {_JPuzEKTKyLEH}.'}
        _qKvUBlAHoIlE = subprocess.run(_npgAxZtYWKzg, capture_output=True, text=True, timeout=15)
        if _qKvUBlAHoIlE.returncode == 0:
            return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'DNS cache cleared successfully.'}
        if _JPuzEKTKyLEH == 'Linux':
            _qegCsCBaPbxV = subprocess.run(['resolvectl', 'flush-caches'], capture_output=True, text=True, timeout=10)
            if _qegCsCBaPbxV.returncode == 0:
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'DNS cache cleared successfully.'}
        return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': _qKvUBlAHoIlE.stderr or 'DNS flush failed.'}

    def _FSqkPPgLIAum(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                subprocess.run(['ipconfig', '/release'], capture_output=True, timeout=15)
                time.sleep(1)
                _ecGkkkGnCpzF = subprocess.run(['ipconfig', '/renew'], capture_output=True, text=True, timeout=30)
                _AKUTXbdTBwlJ = _ecGkkkGnCpzF.returncode == 0
            elif _JPuzEKTKyLEH == 'Linux':
                _ecGkkkGnCpzF = subprocess.run(['dhclient', '-r'], capture_output=True, timeout=10)
                time.sleep(1)
                _ecGkkkGnCpzF = subprocess.run(['dhclient'], capture_output=True, timeout=30)
                _AKUTXbdTBwlJ = True
            elif _JPuzEKTKyLEH == 'Darwin':
                _ecGkkkGnCpzF = subprocess.run(['ipconfig', 'set', 'en0', 'DHCP'], capture_output=True, timeout=15)
                _AKUTXbdTBwlJ = _ecGkkkGnCpzF.returncode == 0
            else:
                _AKUTXbdTBwlJ = False
            _JDxycEkRIXoi = _BeKvpBbQjASm if _AKUTXbdTBwlJ else _lPpKQbXYYYdP
            _xaklVyQMbnDp = 'Got a fresh network address.' if _AKUTXbdTBwlJ else 'Could not renew network address.'
            return {'ok': _AKUTXbdTBwlJ, 'code': _JDxycEkRIXoi, 'detail': _xaklVyQMbnDp}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _RXqTkxjgkujb(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                _fwHZiOEmJflv = [['netsh', 'winsock', 'reset'], ['netsh', 'int', 'ip', 'reset']]
                for _npgAxZtYWKzg in _fwHZiOEmJflv:
                    subprocess.run(_npgAxZtYWKzg, capture_output=True, timeout=15)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'Network settings reset. A restart may be needed.'}
            elif _JPuzEKTKyLEH == 'Linux':
                subprocess.run(['systemctl', 'restart', 'NetworkManager'], capture_output=True, timeout=20)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'Network service restarted.'}
            elif _JPuzEKTKyLEH == 'Darwin':
                subprocess.run(['networksetup', '-setnetworkserviceenabled', 'Wi-Fi', 'off'], capture_output=True, timeout=10)
                time.sleep(2)
                subprocess.run(['networksetup', '-setnetworkserviceenabled', 'Wi-Fi', 'on'], capture_output=True, timeout=10)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'Network adapter reset.'}
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': f'Network reset not supported on {_JPuzEKTKyLEH}.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _SwZTEPTawdRb(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                _ecGkkkGnCpzF = subprocess.run(['netsh', 'interface', 'show', 'interface'], capture_output=True, text=True, timeout=10)
                subprocess.run(['netsh', 'interface', 'set', 'interface', 'Wi-Fi', 'disabled'], capture_output=True, timeout=10)
                time.sleep(2)
                subprocess.run(['netsh', 'interface', 'set', 'interface', 'Wi-Fi', 'enabled'], capture_output=True, timeout=10)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'WiFi adapter restarted.'}
            elif _JPuzEKTKyLEH == 'Linux':
                subprocess.run(['ip', 'link', 'set', 'wlan0', 'down'], capture_output=True, timeout=10)
                time.sleep(1)
                subprocess.run(['ip', 'link', 'set', 'wlan0', 'up'], capture_output=True, timeout=10)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'WiFi adapter restarted.'}
            elif _JPuzEKTKyLEH == 'Darwin':
                subprocess.run(['networksetup', '-setairportpower', 'en0', 'off'], capture_output=True, timeout=10)
                time.sleep(2)
                subprocess.run(['networksetup', '-setairportpower', 'en0', 'on'], capture_output=True, timeout=10)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'WiFi adapter restarted.'}
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': f'WiFi restart not supported on {_JPuzEKTKyLEH}.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _TtepDNVxqILi(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        _kOzXHqsKzhmT = []
        _usCFDnXYSyqK = self._flush_dns(_JPuzEKTKyLEH)
        _kOzXHqsKzhmT.append(_usCFDnXYSyqK['ok'])
        if _JPuzEKTKyLEH == 'Windows':
            subprocess.run(['ipconfig', '/flushdns'], capture_output=True, timeout=10)
            subprocess.run(['arp', '-d', '*'], capture_output=True, timeout=10)
            _kOzXHqsKzhmT.append(True)
        _AKUTXbdTBwlJ = any(_kOzXHqsKzhmT)
        return {'ok': _AKUTXbdTBwlJ, 'code': _BeKvpBbQjASm if _AKUTXbdTBwlJ else _KTuZWVgqYRpq, 'detail': 'Network buffers cleared and settings optimized.'}

    def _yreXMUxntksX(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                print('    Running system file check — this may take a few minutes...')
                _ecGkkkGnCpzF = subprocess.run(['sfc', '/scannow'], capture_output=True, text=True, timeout=300)
                if 'did not find any integrity violations' in _ecGkkkGnCpzF.stdout:
                    return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'System files checked — no problems found.'}
                elif 'successfully repaired' in _ecGkkkGnCpzF.stdout:
                    return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'System files repaired successfully.'}
                else:
                    return {'ok': True, 'code': _KTuZWVgqYRpq, 'detail': 'System file check completed. Some issues may remain.'}
            elif _JPuzEKTKyLEH == 'Linux':
                _ecGkkkGnCpzF = subprocess.run(['dpkg', '--configure', '-a'], capture_output=True, text=True, timeout=120)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'Package system checked and repaired.'}
            elif _JPuzEKTKyLEH == 'Darwin':
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Run First Aid in Disk Utility to check system files on Mac.'}
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': f'System file check not available on {_JPuzEKTKyLEH}.'}
        except subprocess.TimeoutExpired:
            return {'ok': True, 'code': _KTuZWVgqYRpq, 'detail': 'System file check is still running in the background.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _VZHQYYXaKkdL(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                print('    Running deep system repair — this may take several minutes...')
                _ecGkkkGnCpzF = subprocess.run(['DISM', '/Online', '/Cleanup-Image', '/RestoreHealth'], capture_output=True, text=True, timeout=600)
                _AKUTXbdTBwlJ = _ecGkkkGnCpzF.returncode == 0
                return {'ok': _AKUTXbdTBwlJ, 'code': _BeKvpBbQjASm if _AKUTXbdTBwlJ else _KTuZWVgqYRpq, 'detail': 'System image repaired.' if _AKUTXbdTBwlJ else 'Partial repair completed. A restart may help.'}
            else:
                return self._system_file_check(_JPuzEKTKyLEH)
        except subprocess.TimeoutExpired:
            return {'ok': True, 'code': _KTuZWVgqYRpq, 'detail': 'System repair is running. This may take a few more minutes.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _NKfpFJnmAVcf(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                _ecGkkkGnCpzF = subprocess.run(['wmic', 'startup', 'get', 'caption,command'], capture_output=True, text=True, timeout=15)
                _jVOlKAUDVBHp = [_TVYRiYjtoCeC.strip() for _TVYRiYjtoCeC in _ecGkkkGnCpzF.stdout.split('\n') if _TVYRiYjtoCeC.strip() and 'Caption' not in _TVYRiYjtoCeC]
                _qHzKwqbyiwbO = len(_jVOlKAUDVBHp)
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': f'Found {_qHzKwqbyiwbO} programs that start with your device. Kinto can show you which ones to disable.', 'items': _jVOlKAUDVBHp[:10]}
            elif _JPuzEKTKyLEH == 'Linux':
                _ecGkkkGnCpzF = subprocess.run(['systemctl', 'list-units', '--type=service', '--state=running'], capture_output=True, text=True, timeout=15)
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Running services checked. Review the report for details.'}
            return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Startup optimization requires reviewing your settings.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _PeSAnQgdUkre(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Windows':
                _kOzXHqsKzhmT = []
                for _npgAxZtYWKzg in [['bootrec', '/fixmbr'], ['bootrec', '/fixboot'], ['bootrec', '/rebuildbcd']]:
                    _ecGkkkGnCpzF = subprocess.run(_npgAxZtYWKzg, capture_output=True, timeout=30)
                    _kOzXHqsKzhmT.append(_ecGkkkGnCpzF.returncode == 0)
                _AKUTXbdTBwlJ = any(_kOzXHqsKzhmT)
                return {'ok': _AKUTXbdTBwlJ, 'code': _BeKvpBbQjASm if _AKUTXbdTBwlJ else _lQFMPMXsGCLP, 'detail': 'Boot files repaired. Please restart your device.' if _AKUTXbdTBwlJ else 'Boot repair needs to run from recovery mode.'}
            else:
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Boot repair on this system needs to run from recovery mode.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _jjVOsKklsTRo(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        _wKhmviZVmYAa = 0
        _hLgJdNtETfCD = 0
        _tgNtXRyvzxHK = []
        _hmenLcxkbyRH = []
        if _JPuzEKTKyLEH == 'Windows':
            _hmenLcxkbyRH = [os.environ.get('TEMP', ''), os.environ.get('TMP', ''), os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Temp')]
        elif _JPuzEKTKyLEH in ('Linux', 'Darwin'):
            _hmenLcxkbyRH = ['/tmp', os.path.expanduser('~/.cache')]
        for _zHrGjGSMrpmd in _hmenLcxkbyRH:
            if not _zHrGjGSMrpmd or not os.path.exists(_zHrGjGSMrpmd):
                continue
            try:
                for _tqDaXJyOpdgZ in os.scandir(_zHrGjGSMrpmd):
                    try:
                        _caXhjpOuzjJm = 0
                        if _tqDaXJyOpdgZ.is_file(follow_symlinks=False):
                            _caXhjpOuzjJm = _tqDaXJyOpdgZ.stat().st_size
                            os.remove(_tqDaXJyOpdgZ.path)
                            _wKhmviZVmYAa += _caXhjpOuzjJm / (1024 * 1024)
                            _hLgJdNtETfCD += 1
                        elif _tqDaXJyOpdgZ.is_dir(follow_symlinks=False):
                            _caXhjpOuzjJm = sum((_DuTSFRctTGUt.stat().st_size for _DuTSFRctTGUt in os.scandir(_tqDaXJyOpdgZ.path) if _DuTSFRctTGUt.is_file()))
                            shutil.rmtree(_tqDaXJyOpdgZ.path, ignore_errors=True)
                            _wKhmviZVmYAa += _caXhjpOuzjJm / (1024 * 1024)
                            _hLgJdNtETfCD += 1
                    except (_VWBKzpVpEuBX, OSError):
                        pass
            except Exception as e:
                _tgNtXRyvzxHK.append(str(_ZzKQqAfQTafR))
        if _hLgJdNtETfCD > 0:
            return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': f'Removed {_hLgJdNtETfCD} temporary files. Freed {_wKhmviZVmYAa:.1f}MB of space.'}
        return {'ok': True, 'code': _KTuZWVgqYRpq, 'detail': 'Temporary files checked. Most are in use and will clear on restart.'}

    def _FsvLdHYMXoTf(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Linux':
                _ecGkkkGnCpzF = subprocess.run(['df', '/', '--output=source'], capture_output=True, text=True, timeout=10)
                _bXoKRRpcXwhC = _ecGkkkGnCpzF.stdout.strip().split('\n')
                _KSfoCaoHMPwH = _bXoKRRpcXwhC[-1].strip() if len(_bXoKRRpcXwhC) > 1 else '/dev/sda1'
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': f'Filesystem check needs to run at startup. Kinto will schedule it for your next restart.'}
            elif _JPuzEKTKyLEH == 'Windows':
                _ecGkkkGnCpzF = subprocess.run(['chkdsk', 'C:', '/f', '/r', '/x'], capture_output=True, text=True, timeout=30, input='Y\n')
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Disk check scheduled for next restart.'}
            elif _JPuzEKTKyLEH == 'Darwin':
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Run First Aid in Disk Utility to repair your filesystem.'}
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': f'Filesystem repair not available on {_JPuzEKTKyLEH}.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _wjOeTLmYVSAo(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        try:
            if _JPuzEKTKyLEH == 'Darwin':
                _ecGkkkGnCpzF = subprocess.run(['diskutil', 'repairPermissions', '/'], capture_output=True, text=True, timeout=120)
                _AKUTXbdTBwlJ = _ecGkkkGnCpzF.returncode == 0
                return {'ok': _AKUTXbdTBwlJ, 'code': _BeKvpBbQjASm if _AKUTXbdTBwlJ else _KTuZWVgqYRpq, 'detail': 'File permissions repaired.' if _AKUTXbdTBwlJ else 'Permission repair partially completed.'}
            elif _JPuzEKTKyLEH == 'Linux':
                _uzZiMymraNOz = os.path.expanduser('~')
                subprocess.run(['chmod', '755', _uzZiMymraNOz], capture_output=True, timeout=10)
                return {'ok': True, 'code': _BeKvpBbQjASm, 'detail': 'Home directory permissions repaired.'}
            else:
                return {'ok': True, 'code': _lQFMPMXsGCLP, 'detail': 'Permission repair requires administrator access.'}
        except Exception as e:
            return {'ok': False, 'code': _lPpKQbXYYYdP, 'detail': str(_ZzKQqAfQTafR)}

    def _ngeJPwGaBiYH(self, _JPuzEKTKyLEH: str) -> dict:
        """"""
        return self._repair_permissions(_JPuzEKTKyLEH)

    def _rZOFCVbXybYC(self, _gIFmlXvnFvoH: _YlgqCuPyufzt, _URJjUlOPPQvO: str, _qKvUBlAHoIlE: dict) -> bool:
        """"""
        if not _qKvUBlAHoIlE.get('ok'):
            return False
        _JDxycEkRIXoi = _qKvUBlAHoIlE.get('code')
        if _JDxycEkRIXoi == _BeKvpBbQjASm:
            return True
        if _JDxycEkRIXoi == _lQFMPMXsGCLP:
            return True
        if _JDxycEkRIXoi == _KTuZWVgqYRpq:
            return True
        return False

    def _skpUWijyYFqi(self, _gIFmlXvnFvoH: _YlgqCuPyufzt) -> dict:
        """"""
        if not _gIFmlXvnFvoH.backup_path:
            return {'ok': True, 'backed_up': False, 'detail': 'No backup needed for this repair.'}
        if not os.path.exists(_gIFmlXvnFvoH.backup_path):
            return {'ok': True, 'backed_up': False, 'detail': f'Path does not exist yet: {_gIFmlXvnFvoH.backup_path}'}
        _MPabAVlUbpfe = _gIFmlXvnFvoH.backup_path + '.kinto_backup'
        try:
            if os.path.isfile(_gIFmlXvnFvoH.backup_path):
                shutil.copy2(_gIFmlXvnFvoH.backup_path, _MPabAVlUbpfe)
            else:
                shutil.copytree(_gIFmlXvnFvoH.backup_path, _MPabAVlUbpfe)
            self.logger.log(member='Vault', action='backup_created', detail=f'Backup created: {_MPabAVlUbpfe}', outcome='ok')
            return {'ok': True, 'backed_up': True, 'backup_path': _MPabAVlUbpfe}
        except Exception as e:
            self.logger.log(member='Vault', action='backup_failed', detail=f'Could not create backup for {_gIFmlXvnFvoH.backup_path}: {_ZzKQqAfQTafR}', outcome='failed')
            return {'ok': False, 'backed_up': False, 'detail': f'Backup failed: {_ZzKQqAfQTafR}'}

    def _WVithoYxSlCI(self, _gIFmlXvnFvoH: _YlgqCuPyufzt) -> bool:
        """"""
        print(f'\n  ╔══════════════════════════════════════════════╗')
        print(f'  ║  Kinto wants to run a repair.                ║')
        print(f'  ╠══════════════════════════════════════════════╣')
        print(f'  ║                                              ║')
        _yhKfYrNNtBaj = _gIFmlXvnFvoH.description.split()
        _soNnlsywmoue = '  ║  '
        for _SnDVHkhiqVsG in _yhKfYrNNtBaj:
            if len(_soNnlsywmoue) + len(_SnDVHkhiqVsG) + 1 > 50:
                print(_soNnlsywmoue.ljust(50) + '  ║')
                _soNnlsywmoue = '  ║  ' + _SnDVHkhiqVsG + ' '
            else:
                _soNnlsywmoue += _SnDVHkhiqVsG + ' '
        if _soNnlsywmoue.strip():
            print(_soNnlsywmoue.ljust(50) + '  ║')
        print(f'  ║                                              ║')
        if not _gIFmlXvnFvoH.reversible:
            print(f'  ║  Note: This repair cannot be undone.         ║')
            print(f'  ║                                              ║')
        print(f'  ╚══════════════════════════════════════════════╝')
        try:
            _uwgLiQRmQrvL = _JvIWQuAfVakU('\n  Run this repair? (yes / no): ').strip().lower()
            return _uwgLiQRmQrvL in ('yes', 'y')
        except (_vCvJPuclbMzv, _LZTxtrLhTZDC):
            return False

    def _LMNWNHntGODA(self, _gIFmlXvnFvoH: _YlgqCuPyufzt, _qKvUBlAHoIlE: dict, _bVSWubGlONJN: bool) -> str:
        """"""
        _JDxycEkRIXoi = _qKvUBlAHoIlE.get('code', _lPpKQbXYYYdP)
        _xaklVyQMbnDp = _qKvUBlAHoIlE.get('detail', '')
        _bXoKRRpcXwhC = ['  ─────────────────────────────────────────────']
        if _JDxycEkRIXoi == _BeKvpBbQjASm:
            _bXoKRRpcXwhC.append(f'  ✓  Fixed: {_gIFmlXvnFvoH.description}')
            if _xaklVyQMbnDp:
                _bXoKRRpcXwhC.append(f'     {_xaklVyQMbnDp}')
        elif _JDxycEkRIXoi == _KTuZWVgqYRpq:
            _bXoKRRpcXwhC.append(f'  ◑  Partially fixed: {_gIFmlXvnFvoH.description}')
            if _xaklVyQMbnDp:
                _bXoKRRpcXwhC.append(f'     {_xaklVyQMbnDp}')
            _bXoKRRpcXwhC.append('     A restart may complete the repair.')
        elif _JDxycEkRIXoi == _lQFMPMXsGCLP:
            _bXoKRRpcXwhC.append(f'  →  Action needed: {_gIFmlXvnFvoH.description}')
            if _xaklVyQMbnDp:
                _bXoKRRpcXwhC.append(f'     {_xaklVyQMbnDp}')
        elif _JDxycEkRIXoi == _lPpKQbXYYYdP:
            _bXoKRRpcXwhC.append(f'  ✗  Could not fix: {_gIFmlXvnFvoH.description}')
            if _xaklVyQMbnDp:
                _bXoKRRpcXwhC.append(f'     {_xaklVyQMbnDp}')
            _bXoKRRpcXwhC.append('     This will be included in your report')
            _bXoKRRpcXwhC.append('     with suggested next steps.')
        elif _JDxycEkRIXoi == _NhzETvUUeJLk:
            _bXoKRRpcXwhC.append(f'  ✗  Blocked: {_gIFmlXvnFvoH.description}')
            _bXoKRRpcXwhC.append("     This action is not permitted by Kinto's Codex.")
        _bXoKRRpcXwhC.append('  ─────────────────────────────────────────────')
        return '\n'.join(_bXoKRRpcXwhC)

    def _IhacewvCJRGs(self, _QVmGYJZJbKgg: str) -> dict:
        _CTmEuJbDaXmk = f"Kinto doesn't have a specific repair for this issue yet.\n  It will be included in your report with recommended next steps."
        print(f'\n  → {_CTmEuJbDaXmk}')
        return {'ok': True, 'code': _lQFMPMXsGCLP, 'plain': _CTmEuJbDaXmk}

    def _nHpZGevGUsua(self, _gIFmlXvnFvoH: _YlgqCuPyufzt, _encFcZECTNsy: str) -> dict:
        _CTmEuJbDaXmk = f"Repair blocked by Kinto's Codex: {_encFcZECTNsy}"
        self.logger.log(member=_gIFmlXvnFvoH.member or 'ENGINE', action='repair_codex_blocked', detail=f'{_gIFmlXvnFvoH.name}: {_encFcZECTNsy}', outcome='blocked')
        print(f'\n  ✗  {_CTmEuJbDaXmk}')
        return {'ok': False, 'code': _NhzETvUUeJLk, 'plain': _CTmEuJbDaXmk}

    def _nemJdtEDfcSR(self, _gIFmlXvnFvoH: _YlgqCuPyufzt, _BnIuCgqZqJNw: dict) -> dict:
        _CTmEuJbDaXmk = 'Kinto could not create a backup before this repair.\n  The repair was not run. Your data is safe.\n  Please check that Kinto has permission to write files.'
        print(f'\n  ✗  {_CTmEuJbDaXmk}')
        return {'ok': False, 'code': _lPpKQbXYYYdP, 'plain': _CTmEuJbDaXmk}

    def _gBulANpBiNqe(self, _gIFmlXvnFvoH: _YlgqCuPyufzt) -> dict:
        _CTmEuJbDaXmk = 'Repair skipped at your request. No changes were made.'
        print(f'\n  → {_CTmEuJbDaXmk}')
        return {'ok': True, 'code': _lQFMPMXsGCLP, 'plain': _CTmEuJbDaXmk}

    def _XRDgMjplNYbo(self, _gIFmlXvnFvoH: _YlgqCuPyufzt, _qKvUBlAHoIlE: dict, _bVSWubGlONJN: bool):
        """"""
        _JDxycEkRIXoi = _qKvUBlAHoIlE.get('code', _lPpKQbXYYYdP)
        _sZlslLdLYsEA = {_BeKvpBbQjASm: 'fixed', _KTuZWVgqYRpq: 'partial', _lPpKQbXYYYdP: 'failed', _NhzETvUUeJLk: 'blocked', _lQFMPMXsGCLP: 'needs_user'}
        self.logger.log(member=_gIFmlXvnFvoH.member or 'ENGINE', action=f'repair_{_sZlslLdLYsEA.get(_JDxycEkRIXoi, 'unknown')}', detail=f'{_gIFmlXvnFvoH.name}: {_qKvUBlAHoIlE.get('detail', '')} | Verified: {_bVSWubGlONJN} | Risk: {_gIFmlXvnFvoH.risk} | Reversible: {_gIFmlXvnFvoH.reversible}', outcome=_sZlslLdLYsEA.get(_JDxycEkRIXoi, 'unknown'))