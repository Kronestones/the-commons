import os, json
from datetime import datetime

class KintoLogger:
    LOG_FILE = "kinto_audit.log"
    def log(self, member, action, detail, outcome):
        entry = {"time": datetime.now().isoformat(), "member": member,
                 "action": action, "detail": detail, "outcome": outcome}
        try:
            with open(self.LOG_FILE, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass
