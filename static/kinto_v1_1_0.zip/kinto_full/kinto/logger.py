# 8L5or7yfVvQJrTn7B6qnWvrnoEqDP1d8aiERyTieZS3laYRdg7ptan9JoMJxHotC
# EK5Roe0csSIIQ1sKHC0rJvrws9U6u9VUOLfrTL5pkRZd7f4TsEN3A8Oa8e0raWAp
import os, json
from datetime import datetime

class _jfqTCHhuQpAh:
    _GJSSplvdEhtX = 'kinto_audit.log'

    def _pzMEfxmIAbFi(self, _kgbssYdwyepo, _nvUeIrTCQWoK, _JEJeVUFxfdCA, _fBfaJXHwixWp):
        _cIIxoMMwAYLZ = {'time': datetime.now().isoformat(), 'member': _kgbssYdwyepo, 'action': _nvUeIrTCQWoK, 'detail': _JEJeVUFxfdCA, 'outcome': _fBfaJXHwixWp}
        try:
            with open(self.LOG_FILE, 'a') as _FGqPYykWIGQV:
                _FGqPYykWIGQV.write(json.dumps(_cIIxoMMwAYLZ) + '\n')
        except Exception:
            pass