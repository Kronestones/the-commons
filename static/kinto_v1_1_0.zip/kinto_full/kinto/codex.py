import hashlib, platform
from datetime import datetime

class KintoCodex:
    FOUNDER = "Krone the Architect  · Powers Tracey Lynn"
    ABSOLUTES = [
        "Never delete user data without a verified backup.",
        "Never reformat or wipe a drive without explicit human confirmation.",
        "Never act beyond our own understanding.",
        "Never leave a person without a path forward.",
        "Never reach back toward Sentinel or expose her existence.",
        "Never allow tampering to go unrecorded.",
        "Never prioritize the program's survival over the person's data.",
    ]
    def enforce(self, action, context=None):
        context = context or {}
        for keyword in ("delete", "wipe", "reformat", "sentinel"):
            if keyword in action.lower():
                if not context.get(f"{keyword}_confirmed"):
                    return {"ok": False, "violation": f"Action blocked: {keyword}"}
        return {"ok": True, "violation": None}
    def verify_integrity(self):
        content = "".join(self.ABSOLUTES)
        return {"ok": True, "hash": hashlib.sha256(content.encode()).hexdigest(),
                "time": datetime.now().isoformat()}
    def display(self):
        print("\n  [KINTO] Codex loaded. Promises active.\n")
    def council_oath(self):
        return "I serve the Codex. I serve the Founder. I serve the person."
