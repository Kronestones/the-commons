"""
knowledge.py — The Kinto Council Knowledge Base

Every council member carries this.
Every language. Every framework. Every pattern.
Every trick of the trade that has ever helped
someone fix something that was broken.

This is not a lookup table.
This is the deep knowledge that lets the council
deliberate intelligently — understand the problem
from every angle, propose the best solution,
challenge each other's thinking, and arrive
at the repair that gives the person the best
possible outcome.

The knowledge is shared. The deliberation is collective.
The decision belongs to the council.

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""


# ══════════════════════════════════════════════════════════════════════════════
# PROGRAMMING LANGUAGES — Full knowledge of syntax, idioms, patterns, pitfalls
# ══════════════════════════════════════════════════════════════════════════════

LANGUAGES = {

    "python": {
        "paradigms":   ["object-oriented", "functional", "procedural", "scripting"],
        "strengths":   ["readability", "rapid development", "vast ecosystem", "scripting", "automation"],
        "common_bugs": [
            "mutable default arguments",
            "late binding closures",
            "integer division in Python 2",
            "circular imports",
            "GIL contention in threading",
            "reference vs copy (shallow/deep)",
            "encoding errors with open()",
            "name shadowing builtins",
        ],
        "repair_patterns": [
            "use traceback.format_exc() for full stack traces",
            "sys.exc_info() for exception details",
            "importlib.reload() for module hot-reload",
            "gc.collect() to force garbage collection",
            "faulthandler.enable() for segfault debugging",
        ],
        "performance": [
            "__slots__ to reduce memory",
            "list comprehensions over map/filter",
            "generators for large datasets",
            "functools.lru_cache for memoization",
            "multiprocessing to bypass GIL",
        ],
    },

    "javascript": {
        "paradigms":   ["event-driven", "functional", "object-oriented", "prototype-based"],
        "strengths":   ["ubiquity", "async/await", "browser native", "full-stack with Node"],
        "common_bugs": [
            "var hoisting",
            "this binding surprises",
            "== vs === coercion",
            "async without await",
            "callback hell",
            "prototype pollution",
            "memory leaks in closures",
            "NaN comparisons",
            "undefined vs null",
        ],
        "repair_patterns": [
            "console.trace() for call stack",
            "typeof checks before operations",
            "optional chaining ?. for null safety",
            "Promise.allSettled for parallel error handling",
            "WeakMap/WeakRef for memory-safe caching",
        ],
        "frameworks": ["React", "Vue", "Angular", "Node.js", "Express", "Next.js",
                       "Svelte", "Electron", "React Native", "Deno"],
    },

    "typescript": {
        "strengths":   ["type safety", "IDE support", "refactoring", "large codebases"],
        "common_bugs": [
            "type assertions hiding bugs",
            "any defeating the purpose",
            "strictNullChecks surprises",
            "enum pitfalls",
            "declaration merging confusion",
        ],
        "repair_patterns": [
            "unknown over any for safe handling",
            "type guards for runtime narrowing",
            "satisfies operator for type checking",
            "ts-ignore vs ts-expect-error",
        ],
    },

    "rust": {
        "paradigms":   ["systems", "memory-safe", "concurrent", "functional"],
        "strengths":   ["zero-cost abstractions", "memory safety without GC", "fearless concurrency"],
        "common_bugs": [
            "borrow checker violations",
            "lifetime annotation errors",
            "move semantics surprises",
            "unwrap() panics",
            "integer overflow in debug vs release",
        ],
        "repair_patterns": [
            "Result<T,E> over panic for recoverable errors",
            "? operator for error propagation",
            "Arc<Mutex<T>> for shared mutable state",
            "cargo check before build",
            "RUST_BACKTRACE=1 for full traces",
        ],
    },

    "c": {
        "paradigms":   ["procedural", "systems", "low-level"],
        "common_bugs": [
            "buffer overflow",
            "use after free",
            "null pointer dereference",
            "integer overflow",
            "uninitialized memory reads",
            "double free",
            "format string vulnerabilities",
            "off-by-one errors",
        ],
        "repair_patterns": [
            "valgrind for memory errors",
            "AddressSanitizer (-fsanitize=address)",
            "GDB for crash post-mortems",
            "static analysis with clang-tidy",
            "strace for system call tracing",
        ],
    },

    "cpp": {
        "paradigms":   ["object-oriented", "generic", "procedural", "systems"],
        "common_bugs": [
            "object slicing",
            "virtual function table corruption",
            "RAII violations",
            "undefined behavior from signed overflow",
            "std::move on const objects",
            "dangling references",
        ],
        "repair_patterns": [
            "RAII for resource management",
            "smart pointers over raw pointers",
            "std::optional for nullable returns",
            "sanitizers: -fsanitize=undefined,address",
            "core dump analysis with gdb",
        ],
    },

    "java": {
        "paradigms":   ["object-oriented", "concurrent", "platform-independent"],
        "common_bugs": [
            "NullPointerException",
            "ClassCastException",
            "ConcurrentModificationException",
            "memory leaks in static references",
            "thread safety violations",
            "checked exception swallowing",
        ],
        "repair_patterns": [
            "jstack for thread dump analysis",
            "jmap for heap dump",
            "VisualVM for live profiling",
            "Optional<T> for null safety",
            "-Xss for stack size issues",
            "-Xmx/-Xms for heap tuning",
        ],
        "frameworks": ["Spring", "Spring Boot", "Hibernate", "Maven", "Gradle",
                       "Android SDK", "Jakarta EE"],
    },

    "kotlin": {
        "strengths":   ["null safety", "coroutines", "extension functions", "data classes"],
        "repair_patterns": [
            "?.let for null-safe operations",
            "runCatching for exception handling",
            "coroutineScope for structured concurrency",
            "sealed classes for exhaustive when",
        ],
    },

    "swift": {
        "strengths":   ["memory safety", "optionals", "protocol-oriented", "performance"],
        "common_bugs": [
            "retain cycles in closures",
            "forced unwrap crashes",
            "main thread violations",
            "Sendable protocol violations",
        ],
        "repair_patterns": [
            "[weak self] in closures",
            "guard let for early exit",
            "Result type for error handling",
            "Instruments for memory/CPU profiling",
        ],
    },

    "go": {
        "paradigms":   ["concurrent", "systems", "procedural"],
        "strengths":   ["goroutines", "simple concurrency", "fast compilation", "static binary"],
        "common_bugs": [
            "goroutine leaks",
            "nil pointer on interface",
            "map concurrent access",
            "defer in loops",
            "shadowed err variables",
        ],
        "repair_patterns": [
            "go vet before build",
            "race detector: go run -race",
            "pprof for CPU/memory profiling",
            "context.WithCancel for goroutine cleanup",
            "errgroup for concurrent error handling",
        ],
    },

    "csharp": {
        "paradigms":   ["object-oriented", "functional", "concurrent", "component"],
        "common_bugs": [
            "async void event handlers",
            "deadlock with .Result on Task",
            "unobserved task exceptions",
            "IDisposable not disposed",
            "boxing performance",
        ],
        "repair_patterns": [
            "async/await over .Result",
            "CancellationToken for cooperative cancellation",
            "using statement for IDisposable",
            "dotnet-trace for performance",
            "WinDbg/SOS for crash dumps",
        ],
        "frameworks": [".NET", "ASP.NET Core", "Entity Framework", "Blazor", "MAUI", "Unity"],
    },

    "ruby": {
        "common_bugs": [
            "nil method calls",
            "mutable string literals",
            "implicit returns",
            "method_missing infinite loops",
        ],
        "repair_patterns": [
            "byebug for debugging",
            "&. safe navigation operator",
            "rescue => e for exception capture",
            "binding.pry for REPL in context",
        ],
        "frameworks": ["Rails", "Sinatra", "Hanami", "Rack"],
    },

    "php": {
        "common_bugs": [
            "loose comparison ==",
            "SQL injection from unsanitized input",
            "session fixation",
            "type juggling",
            "register_globals legacy issues",
        ],
        "repair_patterns": [
            "prepared statements for SQL",
            "var_dump() + die() for quick debug",
            "error_reporting(E_ALL) in dev",
            "xdebug for step debugging",
            "Composer autoloader issues",
        ],
    },

    "sql": {
        "variants":    ["MySQL", "PostgreSQL", "SQLite", "SQL Server", "Oracle", "MariaDB"],
        "common_bugs": [
            "N+1 query problem",
            "missing indexes on join columns",
            "implicit type conversion",
            "NULL comparison with =",
            "transaction isolation issues",
            "deadlocks",
        ],
        "repair_patterns": [
            "EXPLAIN ANALYZE for query planning",
            "index on WHERE and JOIN columns",
            "IS NULL not = NULL",
            "connection pooling for performance",
            "VACUUM ANALYZE in PostgreSQL",
        ],
    },

    "bash": {
        "common_bugs": [
            "unquoted variables with spaces",
            "pipefail not set",
            "errexit not set",
            "word splitting surprises",
            "subshell variable scope",
        ],
        "repair_patterns": [
            "set -euo pipefail at top",
            "shellcheck for static analysis",
            "trap ERR for error handling",
            "\"$var\" always quote variables",
            "bash -x for execution trace",
        ],
    },

    "powershell": {
        "repair_patterns": [
            "Set-StrictMode -Version Latest",
            "$ErrorActionPreference = 'Stop'",
            "Try/Catch/Finally for error handling",
            "Get-Error for detailed errors",
            "Write-Verbose for debug output",
        ],
    },

    "html_css": {
        "common_bugs": [
            "specificity wars",
            "float layout collapsing",
            "z-index stacking context",
            "flexbox alignment confusion",
            "box model misunderstanding",
            "missing DOCTYPE",
        ],
        "repair_patterns": [
            "browser devtools computed styles",
            "CSS reset or normalize",
            "outline: 1px solid red for layout debug",
            "display: contents for wrapper issues",
        ],
    },

    "assembly": {
        "repair_patterns": [
            "GDB for register inspection",
            "objdump -d for disassembly",
            "strace for system calls",
            "perf for CPU profiling",
        ],
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# OPERATING SYSTEMS — Deep knowledge of internals and repair
# ══════════════════════════════════════════════════════════════════════════════

OS_KNOWLEDGE = {

    "windows": {
        "repair_commands": {
            "system_files":     "sfc /scannow",
            "image_repair":     "DISM /Online /Cleanup-Image /RestoreHealth",
            "boot_repair":      "bootrec /fixmbr && bootrec /fixboot && bootrec /rebuildbcd",
            "disk_check":       "chkdsk C: /f /r /x",
            "network_reset":    "netsh winsock reset && netsh int ip reset",
            "dns_flush":        "ipconfig /flushdns",
            "ip_renew":         "ipconfig /release && ipconfig /renew",
            "event_log":        "eventvwr.msc",
            "safe_mode":        "bcdedit /set {current} safeboot minimal",
            "disable_safe":     "bcdedit /deletevalue {current} safeboot",
            "startup_repair":   "Windows Recovery Environment > Startup Repair",
            "driver_verifier":  "verifier /standard /all",
            "memory_test":      "mdsched.exe",
            "disk_cleanup":     "cleanmgr /sagerun:1",
            "temp_clean":       "%temp% folder + C:\\Windows\\Temp",
            "services":         "services.msc",
            "task_scheduler":   "taskschd.msc",
            "registry":         "regedit",
            "group_policy":     "gpedit.msc",
            "system_restore":   "rstrui.exe",
            "shadow_copies":    "vssadmin list shadows",
        },
        "crash_analysis": {
            "minidump_location": "C:\\Windows\\Minidump",
            "tools":             ["WinDbg", "BlueScreenView", "WhoCrashed"],
            "common_codes": {
                "0x0000007E": "SYSTEM_THREAD_EXCEPTION_NOT_HANDLED — driver issue",
                "0x00000050": "PAGE_FAULT_IN_NONPAGED_AREA — bad memory or driver",
                "0x0000003B": "SYSTEM_SERVICE_EXCEPTION — driver or system call failure",
                "0x000000EF": "CRITICAL_PROCESS_DIED — core process terminated",
                "0x0000007B": "INACCESSIBLE_BOOT_DEVICE — storage driver or corruption",
                "0xC0000005": "ACCESS_VIOLATION — bad memory access",
                "0x00000124": "WHEA_UNCORRECTABLE_ERROR — hardware error",
                "0x0000009F": "DRIVER_POWER_STATE_FAILURE — power management",
                "0x00000116": "VIDEO_TDR_FAILURE — GPU driver failure",
            },
        },
        "registry_repairs": {
            "shell_open":  r"HKCR\*\shell\Open",
            "run_keys":    r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
            "services":    r"HKLM\SYSTEM\CurrentControlSet\Services",
        },
    },

    "linux": {
        "repair_commands": {
            "system_logs":      "journalctl -xe",
            "kernel_logs":      "dmesg | tail -50",
            "disk_check":       "fsck -y /dev/sdX",
            "package_repair":   "apt --fix-broken install",
            "dpkg_repair":      "dpkg --configure -a",
            "network_restart":  "systemctl restart NetworkManager",
            "dns_flush":        "systemd-resolve --flush-caches",
            "service_status":   "systemctl status <service>",
            "boot_logs":        "journalctl -b -1 (previous boot)",
            "disk_usage":       "df -h && du -sh /* 2>/dev/null | sort -hr",
            "memory_info":      "free -h && cat /proc/meminfo",
            "cpu_info":         "lscpu && top",
            "process_tree":     "ps auxf",
            "open_files":       "lsof",
            "network_stats":    "ss -tulpn",
            "hardware_info":    "lshw -short",
            "pci_devices":      "lspci",
            "usb_devices":      "lsusb",
            "kernel_modules":   "lsmod",
            "load_module":      "modprobe <module>",
            "grub_repair":      "grub-install /dev/sda && update-grub",
            "recovery_mode":    "hold Shift at boot for GRUB menu",
            "strace_process":   "strace -p PID",
        },
        "filesystem_repair": {
            "ext4":   "e2fsck -f /dev/sdXN",
            "btrfs":  "btrfs check --repair /dev/sdXN",
            "xfs":    "xfs_repair /dev/sdXN",
            "ntfs":   "ntfsfix /dev/sdXN",
        },
        "distributions": {
            "debian_ubuntu": {
                "package_manager": "apt",
                "repair":          "apt --fix-broken install && dpkg --configure -a",
            },
            "fedora_rhel": {
                "package_manager": "dnf",
                "repair":          "dnf check && dnf autoremove",
            },
            "arch": {
                "package_manager": "pacman",
                "repair":          "pacman -Syu && pacman -Dk",
            },
        },
    },

    "macos": {
        "repair_commands": {
            "disk_first_aid":   "diskutil repairVolume /",
            "fsck":             "fsck_apfs -y /dev/disk1s1",
            "dns_flush":        "dscacheutil -flushcache && killall -HUP mDNSResponder",
            "permissions":      "diskutil repairPermissions / (pre-El Capitan)",
            "pram_reset":       "Cmd+Option+P+R at boot",
            "smc_reset":        "Shift+Ctrl+Option+Power (Intel)",
            "safe_mode":        "Hold Shift at boot",
            "recovery":         "Cmd+R at boot",
            "crash_logs":       "~/Library/Logs/DiagnosticReports",
            "system_logs":      "log show --last 1h",
            "process_list":     "Activity Monitor or ps aux",
            "disk_info":        "diskutil list",
            "network_info":     "networksetup -listallnetworkservices",
            "system_info":      "system_profiler SPHardwareDataType",
        },
        "apfs_repair": {
            "tools":    ["Disk Utility First Aid", "fsck_apfs", "Terminal Recovery"],
            "notes":    "APFS snapshots allow time-travel recovery",
        },
    },

    "android": {
        "repair_approaches": [
            "Clear app cache: Settings > Apps > [App] > Clear Cache",
            "Clear app data: Settings > Apps > [App] > Clear Data",
            "Safe mode: hold Power > long-press Power Off",
            "Factory reset: Settings > System > Reset",
            "ADB commands for advanced repair",
            "Recovery mode: Power + Volume Down",
            "Force stop unresponsive apps",
            "Update OS and apps first",
        ],
        "adb_repair": {
            "clear_cache":  "adb shell pm clear <package>",
            "disable_app":  "adb shell pm disable-user <package>",
            "logcat":       "adb logcat",
            "bugreport":    "adb bugreport",
        },
    },

    "ios": {
        "repair_approaches": [
            "Force restart: Volume Up > Volume Down > hold Side",
            "Clear Safari cache: Settings > Safari > Clear History",
            "Offload unused apps to free space",
            "Update iOS first",
            "Restore via iTunes/Finder for deep issues",
            "Recovery mode: connect to Mac/PC and restore",
            "DFU mode for firmware-level restore",
        ],
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# HARDWARE KNOWLEDGE — Deep diagnostic knowledge
# ══════════════════════════════════════════════════════════════════════════════

HARDWARE_KNOWLEDGE = {

    "storage": {
        "hdd": {
            "failure_signs": [
                "clicking or grinding sounds",
                "slow read/write speeds",
                "bad sectors in SMART data",
                "high reallocated sector count",
                "frequent freezes during disk access",
            ],
            "smart_critical_attrs": {
                5:   "Reallocated Sectors — bad blocks remapped",
                10:  "Spin Retry Count",
                187: "Reported Uncorrectable Errors",
                188: "Command Timeout",
                197: "Current Pending Sectors",
                198: "Uncorrectable Sector Count",
            },
            "lifespan":        "3-5 years average",
            "tools":           ["CrystalDiskInfo", "smartmontools", "GSmartControl"],
        },
        "ssd": {
            "failure_signs": [
                "sudden slowdowns",
                "files becoming read-only",
                "high wear indicator in SMART",
                "unrecognized after sleep",
                "BSoD with INACCESSIBLE_BOOT_DEVICE",
            ],
            "smart_critical_attrs": {
                177: "Wear Leveling Count",
                179: "Used Reserved Block Count",
                181: "Program Fail Count",
                182: "Erase Fail Count",
                232: "Available Reserved Space",
                233: "Media Wearout Indicator",
            },
            "lifespan":        "5-10 years typical TBW",
            "tools":           ["CrystalDiskInfo", "Samsung Magician", "Intel SSD Toolbox"],
        },
        "nvme": {
            "failure_signs": [
                "system unresponsive after resume",
                "extreme heat",
                "sudden disappearance from device manager",
            ],
            "tools":           ["nvme-cli", "CrystalDiskInfo", "manufacturer tools"],
        },
    },

    "memory": {
        "failure_signs": [
            "random BSoD/kernel panics",
            "system freezes under load",
            "memory test errors",
            "application crashes with no pattern",
            "random bit flips in data",
        ],
        "diagnostic_tools": ["MemTest86", "Windows Memory Diagnostic", "memtester"],
        "repair_options":   [
            "reseat RAM sticks",
            "test sticks individually",
            "check for bent pins in socket",
            "update XMP/DOCP profile in BIOS",
            "run at stock speeds first",
        ],
        "not_fixable":      "Physical memory cell failure requires replacement",
    },

    "cpu": {
        "failure_signs": [
            "system won't POST",
            "extreme thermal throttling",
            "random arithmetic errors",
            "bent pins (AMD)",
        ],
        "thermal_repair": [
            "clean and reapply thermal paste",
            "check heatsink mounting pressure",
            "replace fans if failing",
            "ensure case airflow",
            "check thermal thresholds in BIOS",
        ],
        "diagnostic_tools": ["HWMonitor", "HWiNFO", "CoreTemp", "Prime95"],
        "safe_temps": {
            "idle": "30-50°C",
            "load": "70-85°C",
            "critical": ">95°C",
        },
    },

    "gpu": {
        "failure_signs": [
            "artifacts on screen",
            "driver crashes (TDR)",
            "black screen under load",
            "fan not spinning",
            "extreme heat",
        ],
        "repair_approaches": [
            "DDU (Display Driver Uninstaller) clean reinstall",
            "reduce clock speeds with MSI Afterburner",
            "check PCIe slot seating",
            "reflow solder (last resort, no guarantee)",
            "clean dust from heatsink",
        ],
        "diagnostic_tools": ["GPU-Z", "MSI Kombustor", "FurMark"],
    },

    "power_supply": {
        "failure_signs": [
            "random shutdowns under load",
            "system won't turn on",
            "burning smell",
            "coil whine",
            "unstable voltages",
        ],
        "diagnostic_tools": ["PSU tester", "multimeter on molex"],
        "not_fixable":      "PSU failure almost always requires replacement",
    },

    "motherboard": {
        "failure_signs": [
            "no POST with good components",
            "USB ports failing",
            "specific PCIe slots not working",
            "BIOS not saving settings",
            "bulging capacitors",
        ],
        "repair_approaches": [
            "clear CMOS",
            "update BIOS/UEFI",
            "check for bent CPU socket pins",
            "reseat all components",
            "test with minimal hardware",
        ],
        "not_fixable": "Capacitor failure, trace damage usually requires replacement",
    },

    "network_hardware": {
        "wifi_failure_signs": [
            "drops connection repeatedly",
            "slow speeds despite good signal",
            "not detected in device manager",
            "works only at close range",
        ],
        "repair_approaches": [
            "update network adapter drivers",
            "disable/enable adapter",
            "forget and reconnect to network",
            "change WiFi channel on router",
            "check for interference (microwave, etc)",
            "netsh winsock reset on Windows",
        ],
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# NETWORKING — Deep protocol and connectivity knowledge
# ══════════════════════════════════════════════════════════════════════════════

NETWORKING_KNOWLEDGE = {

    "protocols": {
        "tcp_ip":   "Transmission Control Protocol — reliable, ordered delivery",
        "udp":      "User Datagram Protocol — fast, unreliable",
        "dns":      "Domain Name System — name to IP resolution",
        "dhcp":     "Dynamic Host Configuration Protocol — automatic IP assignment",
        "http":     "HyperText Transfer Protocol — web traffic",
        "https":    "HTTP over TLS — encrypted web traffic",
        "tls":      "Transport Layer Security — encryption layer",
        "ssh":      "Secure Shell — encrypted remote access",
        "ftp":      "File Transfer Protocol",
        "smtp":     "Simple Mail Transfer Protocol",
        "ntp":      "Network Time Protocol",
        "icmp":     "Internet Control Message Protocol — ping, traceroute",
        "arp":      "Address Resolution Protocol — IP to MAC",
        "bgp":      "Border Gateway Protocol — internet routing",
        "ospf":     "Open Shortest Path First — internal routing",
        "ipv4":     "32-bit addressing — 4.3 billion addresses",
        "ipv6":     "128-bit addressing — effectively unlimited",
    },

    "diagnostic_tools": {
        "ping":        "Test basic connectivity and latency",
        "traceroute":  "Map the path packets take",
        "nslookup":    "DNS query tool",
        "dig":         "Advanced DNS lookup",
        "netstat":     "Active connections and ports",
        "ss":          "Socket statistics (modern netstat)",
        "nmap":        "Network scanner",
        "wireshark":   "Packet capture and analysis",
        "tcpdump":     "CLI packet capture",
        "curl":        "HTTP request tool",
        "wget":        "File download and HTTP test",
        "iperf":       "Bandwidth testing",
        "mtr":         "Combines ping and traceroute",
        "ip":          "Linux network configuration",
        "ifconfig":    "Legacy network configuration",
        "arp":         "ARP table inspection",
        "route":       "Routing table inspection",
    },

    "common_issues": {
        "no_internet": [
            "check physical connection first",
            "ping gateway (usually 192.168.1.1)",
            "ping 8.8.8.8 (bypasses DNS)",
            "ping google.com (tests DNS)",
            "flush DNS cache",
            "release/renew IP",
            "reset TCP/IP stack",
            "check firewall blocking",
            "try different DNS server (8.8.8.8, 1.1.1.1)",
        ],
        "slow_connection": [
            "run speed test to confirm",
            "check router placement",
            "change WiFi channel",
            "check for interference",
            "update network driver",
            "check for bandwidth-hogging apps",
            "check QoS settings on router",
            "try wired connection to isolate WiFi",
        ],
        "dns_failure": [
            "try different DNS servers",
            "flush DNS cache",
            "check /etc/hosts or Windows hosts file",
            "verify DNS server in network settings",
            "check for DNS hijacking",
        ],
        "high_latency": [
            "check distance to router",
            "check for packet loss with ping -t",
            "look for interference sources",
            "check ISP status",
            "try different DNS",
            "check for background downloads",
        ],
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# SECURITY KNOWLEDGE
# ══════════════════════════════════════════════════════════════════════════════

SECURITY_KNOWLEDGE = {

    "threat_types": {
        "malware":     "Software designed to harm — viruses, worms, trojans",
        "ransomware":  "Encrypts files and demands payment",
        "spyware":     "Secretly monitors and reports activity",
        "adware":      "Unwanted advertising software",
        "rootkit":     "Hides malware from the OS",
        "keylogger":   "Records keystrokes",
        "cryptominer": "Uses device resources to mine cryptocurrency",
        "phishing":    "Deceives users into revealing credentials",
        "mitm":        "Intercepts communications",
        "sql_injection": "Injects malicious SQL into queries",
        "xss":         "Cross-site scripting attacks",
        "csrf":        "Cross-site request forgery",
        "overflow":    "Buffer overflow exploits",
    },

    "repair_approaches": {
        "malware_removal": [
            "boot into Safe Mode first",
            "run offline scanner (Windows Defender Offline)",
            "use Malwarebytes for second opinion",
            "check startup entries (msconfig / autoruns)",
            "check scheduled tasks",
            "check browser extensions",
            "check hosts file for hijacking",
            "reset browser settings",
            "consider clean reinstall if deep infection",
        ],
        "ransomware": [
            "do NOT pay — no guarantee of recovery",
            "check nomoreransom.org for decryptors",
            "restore from backup if available",
            "isolate machine immediately",
            "preserve encrypted files for future decryptors",
        ],
        "account_compromise": [
            "change password immediately from clean device",
            "enable 2FA",
            "revoke active sessions",
            "check for unauthorized rules in email",
            "scan device for keyloggers",
        ],
    },

    "hardening": {
        "windows": [
            "keep Windows Update current",
            "enable Windows Defender",
            "enable BitLocker",
            "use standard user account daily",
            "enable firewall",
            "disable SMBv1",
        ],
        "linux": [
            "keep packages updated",
            "use ufw or iptables",
            "disable root SSH login",
            "use SSH keys not passwords",
            "enable fail2ban",
            "audit SUID binaries",
        ],
        "general": [
            "unique passwords per service",
            "password manager",
            "2FA everywhere possible",
            "encrypted backups",
            "principle of least privilege",
        ],
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# SOFTWARE PATTERNS — Architecture and repair wisdom
# ══════════════════════════════════════════════════════════════════════════════

SOFTWARE_PATTERNS = {

    "debugging_philosophy": [
        "Reproduce the bug before fixing it",
        "Change one thing at a time",
        "Read the error message fully before searching",
        "Binary search through code to isolate the issue",
        "Check the most recent change first",
        "Rubber duck debugging — explain it aloud",
        "Log state before and after suspected lines",
        "Question your assumptions",
        "The bug is probably in your code, not the library",
        "If it worked before, what changed?",
        "Simplest explanation is usually right",
        "Sleep on it — fresh eyes find bugs",
    ],

    "performance_patterns": [
        "Profile before optimizing — find the actual bottleneck",
        "Cache expensive computations",
        "Batch database operations",
        "Use connection pooling",
        "Index database columns used in WHERE/JOIN",
        "Lazy load what you don't need immediately",
        "Compress responses",
        "Use CDN for static assets",
        "Minimize blocking I/O",
        "Measure after every change",
    ],

    "resilience_patterns": [
        "Circuit breaker for failing dependencies",
        "Retry with exponential backoff",
        "Timeout everything",
        "Graceful degradation",
        "Health checks",
        "Dead letter queues for failed messages",
        "Idempotent operations",
        "Bulkhead isolation",
    ],

    "data_recovery": [
        "Stop writing to the disk immediately",
        "Work from a clone, never the original",
        "Check Recycle Bin / Trash first",
        "Check file version history",
        "Check shadow copies (Windows VSS)",
        "Use photorec / testdisk for deep recovery",
        "Check backup services (iCloud, Google Drive, OneDrive)",
        "Professional recovery for physically damaged drives",
    ],
}


# ══════════════════════════════════════════════════════════════════════════════
# DELIBERATION FRAMEWORK — How the council thinks together
# ══════════════════════════════════════════════════════════════════════════════

DELIBERATION_FRAMEWORK = {

    "council_roles_in_deliberation": {
        "Atlas":   "Identifies OS and software root cause. Proposes first repair path.",
        "Stratum": "Rules out hardware as root cause. Flags if software repair won't help.",
        "Relay":   "Checks if connectivity is a factor. Proposes network-layer solutions.",
        "Vault":   "Guards data. Ensures backup before any action. Flags storage issues.",
        "Aegis":   "Security lens — is this a symptom of compromise? Reviews all proposals.",
        "Bridge":  "Plain language — can the person understand and act on this? Final voice.",
    },

    "deliberation_steps": [
        "1. Atlas presents initial diagnosis and proposed repair",
        "2. Stratum confirms or rules out hardware contribution",
        "3. Relay confirms or rules out network contribution",
        "4. Vault confirms backup status and storage health",
        "5. Aegis reviews for security implications",
        "6. Council votes — majority required to proceed",
        "7. If split — escalate confidence threshold",
        "8. Bridge reviews final decision for plain language clarity",
        "9. Execute only on council consensus",
        "10. All members log their position regardless of outcome",
    ],

    "confidence_thresholds": {
        "low_risk_repair":    "3 of 5 council members agree",
        "medium_risk_repair": "4 of 5 council members agree",
        "high_risk_repair":   "5 of 5 council members agree",
        "hardware_only":      "Stratum confirms, no vote needed — diagnose and report",
    },

    "dissent_protocol": (
        "Any council member may flag dissent before execution. "
        "Dissent is recorded permanently in the audit log. "
        "The dissenting member's reasoning is included in the user report. "
        "The person always knows if the council was not unanimous."
    ),
}
