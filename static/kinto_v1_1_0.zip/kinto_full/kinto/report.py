# NZMHQABAANzN0B5gRAae9mmqdXkpehPlSDjI07tLPQBUJVbGcPOzJuQEYwDZAWUS
# vWPeq2rDHbHYTCOy6wJ4R87RFWsSYhfLm1TzZrYyLOvglYrwcy6VpSDre3mDYNBl
""""""
import os
import json
import platform
from datetime import datetime

class _pPaKaGfaNdFT:
    _kzKrzOcWovkq = 'Kinto — Device Repair Report'
    _XexFyPoUCdWQ = 'Krone the Architect · Powers Tracey Lynn'
    _HvmkDDhPhMGU = '1.0.0'

    def __init__(self):
        self.scan_results = []
        self.repair_log = []
        self.generated_at = datetime.now()

    def _AwwHYFfYBsVd(self, _yqDgyzziPSGP: str='kinto_audit.log'):
        """"""
        if not os.path.exists(_yqDgyzziPSGP):
            return False
        _ojuKGwBcYrOl = []
        _FPdNdUeDKYny = []
        try:
            with open(_yqDgyzziPSGP) as _aCDiAcdkWqsd:
                for _ICqRJbIOsYdx in _aCDiAcdkWqsd:
                    _ICqRJbIOsYdx = _ICqRJbIOsYdx.strip()
                    if not _ICqRJbIOsYdx:
                        continue
                    try:
                        _ofrcsGLyqMPr = json.loads(_ICqRJbIOsYdx)
                        if _ofrcsGLyqMPr.get('action') in ('scan_complete', 'scan_start', 'os_diagnosis', 'hardware_diagnosis', 'network_diagnosis', 'storage_diagnosis', 'security_diagnosis'):
                            _ojuKGwBcYrOl.append(_ofrcsGLyqMPr)
                        elif _ofrcsGLyqMPr.get('action') in ('repair_attempted', 'repair_complete', 'repair_failed', 'backup_created', 'backup_verified'):
                            _FPdNdUeDKYny.append(_ofrcsGLyqMPr)
                    except json.JSONDecodeError:
                        continue
            self.scan_results = _ojuKGwBcYrOl
            self.repair_log = _FPdNdUeDKYny
            return True
        except Exception:
            return False

    def _iFsDhJEDptAR(self, _TcWPGYIdYnem: dict, _TGZUlzTAQkfU: list=None):
        """"""
        self.scan_results = [_TcWPGYIdYnem] if isinstance(_TcWPGYIdYnem, dict) else _TcWPGYIdYnem
        self.repair_log = _TGZUlzTAQkfU or []

    def _BrKbcJLDVZPm(self, _MRFJAXyjVrJw: str='txt') -> str:
        """"""
        _UeFhlzruXFvB = self._build_content()
        if _MRFJAXyjVrJw == 'pdf':
            return self._save_pdf(_UeFhlzruXFvB)
        else:
            return self._save_txt(_UeFhlzruXFvB)

    def _YSUzinaIeavP(self) -> dict:
        """"""
        return {'header': self._build_header(), 'summary': self._build_summary(), 'findings': self._build_findings(), 'repairs': self._build_repairs(), 'next_steps': self._build_next_steps(), 'footer': self._build_footer()}

    def _inDXoPftSseg(self) -> str:
        _MOeuHVLjOvpW = []
        _MOeuHVLjOvpW.append('═' * 58)
        _MOeuHVLjOvpW.append('  KINTO — DEVICE REPAIR REPORT')
        _MOeuHVLjOvpW.append('═' * 58)
        _MOeuHVLjOvpW.append(f'  Generated:  {self.generated_at.strftime('%B %d, %Y at %I:%M %p')}')
        _MOeuHVLjOvpW.append(f'  Device:     {_AQwPnDuVgXpf.node() or 'Your Device'}')
        _MOeuHVLjOvpW.append(f'  System:     {_AQwPnDuVgXpf.system()} {_AQwPnDuVgXpf.release()}')
        _MOeuHVLjOvpW.append(f'  Kinto:      v{self.VERSION}')
        _MOeuHVLjOvpW.append('═' * 58)
        return '\n'.join(_MOeuHVLjOvpW)

    def _PMeAkmAjFbLH(self) -> str:
        _MOeuHVLjOvpW = []
        _MOeuHVLjOvpW.append('\n  WHAT KINTO DID')
        _MOeuHVLjOvpW.append('  ' + '─' * 54)
        _QVXLgUSNkMmo = len([_IBTHoYMKiaZx for _IBTHoYMKiaZx in self.scan_results if _IBTHoYMKiaZx.get('action') == 'scan_complete'])
        _AJlwpBJkNOKJ = len([_IBTHoYMKiaZx for _IBTHoYMKiaZx in self.repair_log if _IBTHoYMKiaZx.get('action') == 'repair_complete'])
        _soHLWxFFbIDA = len([_IBTHoYMKiaZx for _IBTHoYMKiaZx in self.repair_log if _IBTHoYMKiaZx.get('action') == 'backup_created'])
        _MOeuHVLjOvpW.append(f'\n  Scans completed:    {_QVXLgUSNkMmo or 'See findings below'}')
        _MOeuHVLjOvpW.append(f'  Repairs attempted:  {_AJlwpBJkNOKJ}')
        _MOeuHVLjOvpW.append(f'  Backups created:    {_soHLWxFFbIDA}')
        _MOeuHVLjOvpW.append(f'\n  Your data was protected before anything was changed.')
        return '\n'.join(_MOeuHVLjOvpW)

    def _ntnvjPmYyxWk(self) -> str:
        _MOeuHVLjOvpW = []
        _MOeuHVLjOvpW.append('\n\n  WHAT KINTO FOUND')
        _MOeuHVLjOvpW.append('  ' + '─' * 54)
        _ibAYpWCMkgdj = []
        for _ofrcsGLyqMPr in self.scan_results:
            _aKzoDBjFfirv = _ofrcsGLyqMPr.get('detail', '')
            _HitlqqysggPd = _ofrcsGLyqMPr.get('member', '')
            _JdgGhMFwYzFC = _ofrcsGLyqMPr.get('outcome', '')
            _ymgOimrpPPRN = _ofrcsGLyqMPr.get('action', '')
            _CZzkHJdgkbwe = _ofrcsGLyqMPr.get('time', '')
            if _aKzoDBjFfirv and _HitlqqysggPd and (_HitlqqysggPd not in ('ENGINE',)):
                _ibAYpWCMkgdj.append({'member': _HitlqqysggPd, 'detail': _aKzoDBjFfirv, 'outcome': _JdgGhMFwYzFC, 'action': _ymgOimrpPPRN, 'time': _CZzkHJdgkbwe})
        if not _ibAYpWCMkgdj:
            _MOeuHVLjOvpW.append('\n  No scan data available in the current log.')
            _MOeuHVLjOvpW.append('  Run a scan first to generate a detailed report.')
        else:
            _KgOPZPxufQUY = {}
            for _aCDiAcdkWqsd in _ibAYpWCMkgdj:
                _oRfMUSGukTeA = _aCDiAcdkWqsd['member']
                if _oRfMUSGukTeA not in _KgOPZPxufQUY:
                    _KgOPZPxufQUY[_oRfMUSGukTeA] = []
                _KgOPZPxufQUY[_oRfMUSGukTeA].append(_aCDiAcdkWqsd)
            _xVoSCxyUbAYk = {'Atlas': 'Operating System', 'Stratum': 'Hardware', 'Relay': 'Network & Connectivity', 'Vault': 'Storage & Files', 'Aegis': 'Security', 'Bridge': 'Summary', 'ENGINE': 'System', 'SECURITY': 'Security Check'}
            for _HitlqqysggPd, _aHKxCIaiqTfk in _KgOPZPxufQUY.items():
                _eUIGgryGMnmE = _xVoSCxyUbAYk.get(_HitlqqysggPd, _HitlqqysggPd)
                _MOeuHVLjOvpW.append(f'\n  {_HitlqqysggPd} — {_eUIGgryGMnmE}')
                for _aCDiAcdkWqsd in _aHKxCIaiqTfk[:5]:
                    _XyHzqXqCoeCg = ''
                    if _aCDiAcdkWqsd.get('time'):
                        try:
                            _PCLTJuESKjqd = datetime.fromisoformat(_aCDiAcdkWqsd['time'])
                            _XyHzqXqCoeCg = _PCLTJuESKjqd.strftime('%I:%M %p')
                        except Exception:
                            pass
                    _aKzoDBjFfirv = _aCDiAcdkWqsd.get('detail', '')
                    if _aKzoDBjFfirv:
                        _qTNGpmcizZaP = _aKzoDBjFfirv.split()
                        _ICqRJbIOsYdx = '    '
                        _JsInqDWiVtXo = True
                        for _MPPNCsyhZUYb in _qTNGpmcizZaP:
                            if len(_ICqRJbIOsYdx) + len(_MPPNCsyhZUYb) + 1 > 56:
                                _MOeuHVLjOvpW.append(_ICqRJbIOsYdx)
                                _ICqRJbIOsYdx = '    ' + _MPPNCsyhZUYb + ' '
                            else:
                                _ICqRJbIOsYdx += _MPPNCsyhZUYb + ' '
                        if _ICqRJbIOsYdx.strip():
                            _MOeuHVLjOvpW.append(_ICqRJbIOsYdx)
                        if _XyHzqXqCoeCg:
                            _MOeuHVLjOvpW.append(f'    Checked at: {_XyHzqXqCoeCg}')
        return '\n'.join(_MOeuHVLjOvpW)

    def _VRYlozifzInR(self) -> str:
        _MOeuHVLjOvpW = []
        _MOeuHVLjOvpW.append('\n\n  WHAT KINTO REPAIRED')
        _MOeuHVLjOvpW.append('  ' + '─' * 54)
        _FPdNdUeDKYny = [_IBTHoYMKiaZx for _IBTHoYMKiaZx in self.repair_log if _IBTHoYMKiaZx.get('action') in ('repair_complete', 'repair_attempted', 'repair_failed', 'backup_created')]
        if not _FPdNdUeDKYny:
            _MOeuHVLjOvpW.append('\n  No repairs were performed in this session.')
        else:
            for _JcpEQokTcCCo in _FPdNdUeDKYny:
                _ymgOimrpPPRN = _JcpEQokTcCCo.get('action', '')
                _aKzoDBjFfirv = _JcpEQokTcCCo.get('detail', '')
                _JdgGhMFwYzFC = _JcpEQokTcCCo.get('outcome', '')
                _CZzkHJdgkbwe = _JcpEQokTcCCo.get('time', '')
                _XyHzqXqCoeCg = ''
                if _CZzkHJdgkbwe:
                    try:
                        _PCLTJuESKjqd = datetime.fromisoformat(_CZzkHJdgkbwe)
                        _XyHzqXqCoeCg = _PCLTJuESKjqd.strftime('%I:%M %p')
                    except Exception:
                        pass
                _TOOYuteFlAgy = {'repair_complete': '✓  Fixed', 'repair_attempted': '→  Attempted', 'repair_failed': '✗  Could not fix', 'backup_created': '✓  Backed up'}
                _fQjaXGbXfAxd = _TOOYuteFlAgy.get(_ymgOimrpPPRN, _ymgOimrpPPRN)
                _MOeuHVLjOvpW.append(f'\n  {_fQjaXGbXfAxd}')
                if _aKzoDBjFfirv:
                    _qTNGpmcizZaP = _aKzoDBjFfirv.split()
                    _ICqRJbIOsYdx = '     '
                    for _MPPNCsyhZUYb in _qTNGpmcizZaP:
                        if len(_ICqRJbIOsYdx) + len(_MPPNCsyhZUYb) + 1 > 56:
                            _MOeuHVLjOvpW.append(_ICqRJbIOsYdx)
                            _ICqRJbIOsYdx = '     ' + _MPPNCsyhZUYb + ' '
                        else:
                            _ICqRJbIOsYdx += _MPPNCsyhZUYb + ' '
                    if _ICqRJbIOsYdx.strip():
                        _MOeuHVLjOvpW.append(_ICqRJbIOsYdx)
                if _XyHzqXqCoeCg:
                    _MOeuHVLjOvpW.append(f'     At: {_XyHzqXqCoeCg}')
        return '\n'.join(_MOeuHVLjOvpW)

    def _lVHbnFAXOCHu(self) -> str:
        _MOeuHVLjOvpW = []
        _MOeuHVLjOvpW.append('\n\n  WHAT TO DO NEXT')
        _MOeuHVLjOvpW.append('  ' + '─' * 54)
        _ZUQnRNJiYwvl = [_IBTHoYMKiaZx for _IBTHoYMKiaZx in self.repair_log if _IBTHoYMKiaZx.get('action') == 'repair_failed']
        _uWppRnVYwiZm = [_IBTHoYMKiaZx for _IBTHoYMKiaZx in self.scan_results if _IBTHoYMKiaZx.get('member') == 'Stratum' and _IBTHoYMKiaZx.get('outcome') != 'ok']
        if not _ZUQnRNJiYwvl and (not _uWppRnVYwiZm):
            _MOeuHVLjOvpW.append('\n  Kinto resolved the issues it found.')
            _MOeuHVLjOvpW.append('  Keep Kinto running in the background to')
            _MOeuHVLjOvpW.append('  catch problems early.')
        else:
            _MOeuHVLjOvpW.append('\n  Some issues need attention beyond what')
            _MOeuHVLjOvpW.append('  Kinto can fix on its own:\n')
            if _ZUQnRNJiYwvl:
                _MOeuHVLjOvpW.append('  Software issues Kinto could not fix:')
                for _JcpEQokTcCCo in _ZUQnRNJiYwvl:
                    _MOeuHVLjOvpW.append(f'    · {_JcpEQokTcCCo.get('detail', 'See log for details')}')
                _MOeuHVLjOvpW.append('')
                _MOeuHVLjOvpW.append('  Recommended: Contact a software technician')
                _MOeuHVLjOvpW.append('  or visit the Commons community for help.')
            if _uWppRnVYwiZm:
                _MOeuHVLjOvpW.append('\n  Hardware issues found:')
                for _PaqOtnDJaDJh in _uWppRnVYwiZm:
                    _MOeuHVLjOvpW.append(f'    · {_PaqOtnDJaDJh.get('detail', 'See log for details')}')
                _MOeuHVLjOvpW.append('')
                _MOeuHVLjOvpW.append('  Recommended: Show this report to a repair shop.')
                _MOeuHVLjOvpW.append('  The details above explain exactly what was found.')
        _MOeuHVLjOvpW.append('\n  You can run Kinto again any time for a fresh scan.')
        return '\n'.join(_MOeuHVLjOvpW)

    def _akcVCwpShkGO(self) -> str:
        _MOeuHVLjOvpW = []
        _MOeuHVLjOvpW.append('\n\n' + '═' * 58)
        _MOeuHVLjOvpW.append('  This report was generated by Kinto.')
        _MOeuHVLjOvpW.append('  Kinto is a free device repair tool.')
        _MOeuHVLjOvpW.append('  Available at The Commons — commons.onrender.com')
        _MOeuHVLjOvpW.append('')
        _MOeuHVLjOvpW.append('  Founded by Krone the Architect · Powers Tracey Lynn')
        _MOeuHVLjOvpW.append('  We are doing our best for you.')
        _MOeuHVLjOvpW.append('═' * 58 + '\n')
        return '\n'.join(_MOeuHVLjOvpW)

    def _aewNtlvPUbkY(self, _UeFhlzruXFvB: dict) -> str:
        """"""
        _JYycZBwHVhDz = self.generated_at.strftime('%Y%m%d_%H%M%S')
        _lNsGzvNbFaAf = f'Kinto_Report_{_JYycZBwHVhDz}.txt'
        _WFBFWfUWEvVX = os.path.join(os.path.expanduser('~'), 'Desktop')
        if os.path.exists(_WFBFWfUWEvVX):
            _EcqkOBmrGkyJ = os.path.join(_WFBFWfUWEvVX, _lNsGzvNbFaAf)
        else:
            _EcqkOBmrGkyJ = _lNsGzvNbFaAf
        try:
            with open(_EcqkOBmrGkyJ, 'w', encoding='utf-8') as _aCDiAcdkWqsd:
                for _QqUXrEECbAzf in _UeFhlzruXFvB.values():
                    _aCDiAcdkWqsd.write(_QqUXrEECbAzf + '\n')
            return _EcqkOBmrGkyJ
        except Exception as e:
            with open(_lNsGzvNbFaAf, 'w', encoding='utf-8') as _aCDiAcdkWqsd:
                for _QqUXrEECbAzf in _UeFhlzruXFvB.values():
                    _aCDiAcdkWqsd.write(_QqUXrEECbAzf + '\n')
            return _lNsGzvNbFaAf

    def _MXsGNTmnVZHg(self, _UeFhlzruXFvB: dict) -> str:
        """"""
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import inch
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
            _JYycZBwHVhDz = self.generated_at.strftime('%Y%m%d_%H%M%S')
            _lNsGzvNbFaAf = f'Kinto_Report_{_JYycZBwHVhDz}.pdf'
            _WFBFWfUWEvVX = os.path.join(os.path.expanduser('~'), 'Desktop')
            if os.path.exists(_WFBFWfUWEvVX):
                _EcqkOBmrGkyJ = os.path.join(_WFBFWfUWEvVX, _lNsGzvNbFaAf)
            else:
                _EcqkOBmrGkyJ = _lNsGzvNbFaAf
            _eOQDfBtpCVlk = _IhEewDPpNhzA(_EcqkOBmrGkyJ, pagesize=_ubtiMnpWKlin, rightMargin=_lNBqlyoVkZed, leftMargin=_lNBqlyoVkZed, topMargin=_lNBqlyoVkZed, bottomMargin=_lNBqlyoVkZed)
            _yvuTPrWaURVu = _sLsmJCEqCddB()
            _bZCNerTpiKIm = _PmSFhlQnHtdy('KintoTitle', parent=_yvuTPrWaURVu['Heading1'], fontSize=18, textColor=_XKxtHavmTuUQ.HexColor('#c8832a'), spaceAfter=12)
            _tbtDmuXHXdoC = _PmSFhlQnHtdy('KintoBody', parent=_yvuTPrWaURVu['Normal'], fontSize=10, leading=16, spaceAfter=6)
            _ymunJOKzZedo = _PmSFhlQnHtdy('KintoSection', parent=_yvuTPrWaURVu['Heading2'], fontSize=12, textColor=_XKxtHavmTuUQ.HexColor('#1a1714'), spaceBefore=16, spaceAfter=8)
            _XWJvAMGfxmUk = []
            _XWJvAMGfxmUk.append(_HkWZOWiOSoWB('Kinto — Device Repair Report', _bZCNerTpiKIm))
            _XWJvAMGfxmUk.append(_HkWZOWiOSoWB(f'Generated: {self.generated_at.strftime('%B %d, %Y at %I:%M %p')} · {_AQwPnDuVgXpf.system()} {_AQwPnDuVgXpf.release()}', _tbtDmuXHXdoC))
            _XWJvAMGfxmUk.append(_edhbmuiXeLHy(1, 12))
            _DISGBUYwVTDG = {'summary': 'What Kinto Did', 'findings': 'What Kinto Found', 'repairs': 'What Kinto Repaired', 'next_steps': 'What To Do Next', 'footer': 'About Kinto'}
            for _dTtYKfebbORm, _loJbIAWuKMSx in _UeFhlzruXFvB.items():
                if _dTtYKfebbORm == 'header':
                    continue
                _SinvKWBuCsTb = _DISGBUYwVTDG.get(_dTtYKfebbORm, _dTtYKfebbORm.title())
                _XWJvAMGfxmUk.append(_HkWZOWiOSoWB(_SinvKWBuCsTb, _ymunJOKzZedo))
                for _ICqRJbIOsYdx in _loJbIAWuKMSx.split('\n'):
                    _DKWvGECCPWzD = _ICqRJbIOsYdx.strip()
                    if _DKWvGECCPWzD and (not _DKWvGECCPWzD.startswith('─')) and (not _DKWvGECCPWzD.startswith('═')):
                        _XWJvAMGfxmUk.append(_HkWZOWiOSoWB(_DKWvGECCPWzD, _tbtDmuXHXdoC))
            _eOQDfBtpCVlk.build(_XWJvAMGfxmUk)
            return _EcqkOBmrGkyJ
        except ImportError:
            print('\n  [KINTO] PDF library not available.')
            print('  [KINTO] Saving as text file instead.\n')
            return self._save_txt(_UeFhlzruXFvB)

def _PMVeyIEWVMUe(_TcWPGYIdYnem: dict=None, _TGZUlzTAQkfU: list=None):
    """"""
    print('\n  ─────────────────────────────────────────────')
    print('  Would you like a copy of what Kinto found?')
    print()
    print('  You can save it for your records, show it')
    print('  to a repair shop, or just keep it for')
    print('  peace of mind.')
    print()
    print('  1. Save as text file (.txt)')
    print('  2. Save as PDF')
    print('  3. No thanks')
    print()
    try:
        _GSYtDWZpaCYz = _BZMNBhdOIIeP('  Your choice (1, 2, or 3): ').strip()
    except (_jKOWFPjxdYgp, _hiHhfZSStjSH):
        _GSYtDWZpaCYz = '3'
    if _GSYtDWZpaCYz not in ('1', '2'):
        print('\n  No problem. Your scan results are saved')
        print("  in Kinto's audit log if you change your mind.\n")
        return None
    _MRFJAXyjVrJw = 'txt' if _GSYtDWZpaCYz == '1' else 'pdf'
    _RVDvSISuweVc = _pPaKaGfaNdFT()
    _RVDvSISuweVc.load_from_audit_log()
    if _TcWPGYIdYnem:
        _RVDvSISuweVc.load_from_scan(_TcWPGYIdYnem, _TGZUlzTAQkfU)
    print('\n  Generating your report...\n')
    _EcqkOBmrGkyJ = _RVDvSISuweVc.generate(fmt=_MRFJAXyjVrJw)
    print(f'  ✓  Report saved:')
    print(f'     {_EcqkOBmrGkyJ}')
    print()
    print('  This report is yours.')
    print('  Keep it, share it, or show it to a repair shop.')
    print('  It explains everything in plain language.')
    print()
    return _EcqkOBmrGkyJ