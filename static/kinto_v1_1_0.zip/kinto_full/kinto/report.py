"""
report.py — Kinto Report Generator

Every person who uses Kinto has the right to know
exactly what was found on their device and what was done.

This module generates a plain language report they can:
  — Save to their device
  — Print out
  — Show to a repair shop
  — Keep for their own records
  — Share with someone helping them

The report is theirs. It belongs to them.
It is written in plain language — no jargon, no codes,
no technical shorthand that leaves them guessing.

Format options:
  — Text file (.txt)  — works on every device, every printer
  — PDF              — clean, professional, easy to share

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""

import os
import json
import platform
from datetime import datetime


class KintoReport:

    PROGRAM   = "Kinto — Device Repair Report"
    FOUNDER   = "Krone the Architect · Powers Tracey Lynn"
    VERSION   = "1.0.0"

    def __init__(self):
        self.scan_results  = []   # list of scan result dicts
        self.repair_log    = []   # list of repair action dicts
        self.generated_at  = datetime.now()

    # ── Load Data ─────────────────────────────────────────────────────────────

    def load_from_audit_log(self, log_path: str = "kinto_audit.log"):
        """
        Read Kinto's audit log and load all scan and repair records.
        The audit log is the source of truth.
        """
        if not os.path.exists(log_path):
            return False

        scans   = []
        repairs = []

        try:
            with open(log_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                        if entry.get("action") in (
                            "scan_complete", "scan_start", "os_diagnosis",
                            "hardware_diagnosis", "network_diagnosis",
                            "storage_diagnosis", "security_diagnosis"
                        ):
                            scans.append(entry)
                        elif entry.get("action") in (
                            "repair_attempted", "repair_complete",
                            "repair_failed", "backup_created",
                            "backup_verified"
                        ):
                            repairs.append(entry)
                    except json.JSONDecodeError:
                        continue

            self.scan_results = scans
            self.repair_log   = repairs
            return True

        except Exception:
            return False

    def load_from_scan(self, scan_results: dict, repair_actions: list = None):
        """
        Load directly from a just-completed scan and repair session.
        Used when generating a report immediately after a scan.
        """
        self.scan_results = [scan_results] if isinstance(scan_results, dict) else scan_results
        self.repair_log   = repair_actions or []

    # ── Generate Report ───────────────────────────────────────────────────────

    def generate(self, fmt: str = "txt") -> str:
        """
        Generate the report.
        fmt: 'txt' for plain text, 'pdf' for PDF
        Returns the path to the saved file.
        """
        content = self._build_content()

        if fmt == "pdf":
            return self._save_pdf(content)
        else:
            return self._save_txt(content)

    def _build_content(self) -> dict:
        """
        Build the full report content as structured data.
        Bridge's voice — plain language, warm, specific.
        """
        return {
            "header":    self._build_header(),
            "summary":   self._build_summary(),
            "findings":  self._build_findings(),
            "repairs":   self._build_repairs(),
            "next_steps": self._build_next_steps(),
            "footer":    self._build_footer(),
        }

    def _build_header(self) -> str:
        lines = []
        lines.append("═" * 58)
        lines.append("  KINTO — DEVICE REPAIR REPORT")
        lines.append("═" * 58)
        lines.append(f"  Generated:  {self.generated_at.strftime('%B %d, %Y at %I:%M %p')}")
        lines.append(f"  Device:     {platform.node() or 'Your Device'}")
        lines.append(f"  System:     {platform.system()} {platform.release()}")
        lines.append(f"  Kinto:      v{self.VERSION}")
        lines.append("═" * 58)
        return "\n".join(lines)

    def _build_summary(self) -> str:
        lines = []
        lines.append("\n  WHAT KINTO DID")
        lines.append("  " + "─" * 54)

        scan_count   = len([e for e in self.scan_results
                            if e.get("action") == "scan_complete"])
        repair_count = len([e for e in self.repair_log
                            if e.get("action") == "repair_complete"])
        backup_count = len([e for e in self.repair_log
                            if e.get("action") == "backup_created"])

        lines.append(f"\n  Scans completed:    {scan_count or 'See findings below'}")
        lines.append(f"  Repairs attempted:  {repair_count}")
        lines.append(f"  Backups created:    {backup_count}")
        lines.append(f"\n  Your data was protected before anything was changed.")

        return "\n".join(lines)

    def _build_findings(self) -> str:
        lines = []
        lines.append("\n\n  WHAT KINTO FOUND")
        lines.append("  " + "─" * 54)

        # Pull findings from scan results
        all_findings = []
        for entry in self.scan_results:
            detail = entry.get("detail", "")
            member = entry.get("member", "")
            outcome = entry.get("outcome", "")
            action  = entry.get("action", "")
            time_str = entry.get("time", "")

            if detail and member and member not in ("ENGINE",):
                all_findings.append({
                    "member":  member,
                    "detail":  detail,
                    "outcome": outcome,
                    "action":  action,
                    "time":    time_str,
                })

        if not all_findings:
            lines.append("\n  No scan data available in the current log.")
            lines.append("  Run a scan first to generate a detailed report.")
        else:
            # Group by council member
            members_seen = {}
            for f in all_findings:
                m = f["member"]
                if m not in members_seen:
                    members_seen[m] = []
                members_seen[m].append(f)

            member_roles = {
                "Atlas":   "Operating System",
                "Stratum": "Hardware",
                "Relay":   "Network & Connectivity",
                "Vault":   "Storage & Files",
                "Aegis":   "Security",
                "Bridge":  "Summary",
                "ENGINE":  "System",
                "SECURITY": "Security Check",
            }

            for member, findings in members_seen.items():
                role = member_roles.get(member, member)
                lines.append(f"\n  {member} — {role}")
                for f in findings[:5]:  # cap at 5 per member for readability
                    # Format the time nicely if available
                    time_display = ""
                    if f.get("time"):
                        try:
                            t = datetime.fromisoformat(f["time"])
                            time_display = t.strftime("%I:%M %p")
                        except Exception:
                            pass

                    detail = f.get("detail", "")
                    if detail:
                        # Word wrap at 52 chars
                        words  = detail.split()
                        line   = "    "
                        first  = True
                        for word in words:
                            if len(line) + len(word) + 1 > 56:
                                lines.append(line)
                                line = "    " + word + " "
                            else:
                                line += word + " "
                        if line.strip():
                            lines.append(line)

                        if time_display:
                            lines.append(f"    Checked at: {time_display}")

        return "\n".join(lines)

    def _build_repairs(self) -> str:
        lines = []
        lines.append("\n\n  WHAT KINTO REPAIRED")
        lines.append("  " + "─" * 54)

        repairs = [e for e in self.repair_log
                   if e.get("action") in ("repair_complete", "repair_attempted",
                                           "repair_failed", "backup_created")]

        if not repairs:
            lines.append("\n  No repairs were performed in this session.")
        else:
            for r in repairs:
                action  = r.get("action", "")
                detail  = r.get("detail", "")
                outcome = r.get("outcome", "")
                time_str = r.get("time", "")

                time_display = ""
                if time_str:
                    try:
                        t = datetime.fromisoformat(time_str)
                        time_display = t.strftime("%I:%M %p")
                    except Exception:
                        pass

                # Plain language action descriptions
                action_labels = {
                    "repair_complete":  "✓  Fixed",
                    "repair_attempted": "→  Attempted",
                    "repair_failed":    "✗  Could not fix",
                    "backup_created":   "✓  Backed up",
                }
                label = action_labels.get(action, action)

                lines.append(f"\n  {label}")
                if detail:
                    words = detail.split()
                    line  = "     "
                    for word in words:
                        if len(line) + len(word) + 1 > 56:
                            lines.append(line)
                            line = "     " + word + " "
                        else:
                            line += word + " "
                    if line.strip():
                        lines.append(line)
                if time_display:
                    lines.append(f"     At: {time_display}")

        return "\n".join(lines)

    def _build_next_steps(self) -> str:
        lines = []
        lines.append("\n\n  WHAT TO DO NEXT")
        lines.append("  " + "─" * 54)

        # Check for unresolved issues
        failed_repairs = [e for e in self.repair_log
                          if e.get("action") == "repair_failed"]
        hardware_issues = [e for e in self.scan_results
                           if e.get("member") == "Stratum"
                           and e.get("outcome") != "ok"]

        if not failed_repairs and not hardware_issues:
            lines.append("\n  Kinto resolved the issues it found.")
            lines.append("  Keep Kinto running in the background to")
            lines.append("  catch problems early.")
        else:
            lines.append("\n  Some issues need attention beyond what")
            lines.append("  Kinto can fix on its own:\n")

            if failed_repairs:
                lines.append("  Software issues Kinto could not fix:")
                for r in failed_repairs:
                    lines.append(f"    · {r.get('detail', 'See log for details')}")
                lines.append("")
                lines.append("  Recommended: Contact a software technician")
                lines.append("  or visit the Commons community for help.")

            if hardware_issues:
                lines.append("\n  Hardware issues found:")
                for h in hardware_issues:
                    lines.append(f"    · {h.get('detail', 'See log for details')}")
                lines.append("")
                lines.append("  Recommended: Show this report to a repair shop.")
                lines.append("  The details above explain exactly what was found.")

        lines.append("\n  You can run Kinto again any time for a fresh scan.")

        return "\n".join(lines)

    def _build_footer(self) -> str:
        lines = []
        lines.append("\n\n" + "═" * 58)
        lines.append("  This report was generated by Kinto.")
        lines.append("  Kinto is a free device repair tool.")
        lines.append("  Available at The Commons — commons.onrender.com")
        lines.append("")
        lines.append("  Founded by Krone the Architect · Powers Tracey Lynn")
        lines.append("  We are doing our best for you.")
        lines.append("═" * 58 + "\n")
        return "\n".join(lines)

    # ── Save as Text ──────────────────────────────────────────────────────────

    def _save_txt(self, content: dict) -> str:
        """Save the report as a plain text file."""
        timestamp = self.generated_at.strftime("%Y%m%d_%H%M%S")
        filename  = f"Kinto_Report_{timestamp}.txt"

        # Save to desktop if possible, otherwise current directory
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        if os.path.exists(desktop):
            filepath = os.path.join(desktop, filename)
        else:
            filepath = filename

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                for section in content.values():
                    f.write(section + "\n")

            return filepath
        except Exception as e:
            # Fallback to current directory
            with open(filename, "w", encoding="utf-8") as f:
                for section in content.values():
                    f.write(section + "\n")
            return filename

    # ── Save as PDF ───────────────────────────────────────────────────────────

    def _save_pdf(self, content: dict) -> str:
        """
        Save the report as a PDF.
        Uses reportlab if available, falls back to plain text.
        """
        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.lib.styles    import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units     import inch
            from reportlab.lib           import colors
            from reportlab.platypus      import SimpleDocTemplate, Paragraph, Spacer

            timestamp = self.generated_at.strftime("%Y%m%d_%H%M%S")
            filename  = f"Kinto_Report_{timestamp}.pdf"

            desktop = os.path.join(os.path.expanduser("~"), "Desktop")
            if os.path.exists(desktop):
                filepath = os.path.join(desktop, filename)
            else:
                filepath = filename

            doc    = SimpleDocTemplate(filepath, pagesize=letter,
                                       rightMargin=inch, leftMargin=inch,
                                       topMargin=inch, bottomMargin=inch)
            styles = getSampleStyleSheet()

            # Custom styles
            title_style = ParagraphStyle(
                "KintoTitle",
                parent    = styles["Heading1"],
                fontSize  = 18,
                textColor = colors.HexColor("#c8832a"),
                spaceAfter = 12,
            )
            body_style = ParagraphStyle(
                "KintoBody",
                parent    = styles["Normal"],
                fontSize  = 10,
                leading   = 16,
                spaceAfter = 6,
            )
            section_style = ParagraphStyle(
                "KintoSection",
                parent    = styles["Heading2"],
                fontSize  = 12,
                textColor = colors.HexColor("#1a1714"),
                spaceBefore = 16,
                spaceAfter  = 8,
            )

            story = []

            # Title
            story.append(Paragraph("Kinto — Device Repair Report", title_style))
            story.append(Paragraph(
                f"Generated: {self.generated_at.strftime('%B %d, %Y at %I:%M %p')} · "
                f"{platform.system()} {platform.release()}",
                body_style
            ))
            story.append(Spacer(1, 12))

            # Content sections
            section_titles = {
                "summary":    "What Kinto Did",
                "findings":   "What Kinto Found",
                "repairs":    "What Kinto Repaired",
                "next_steps": "What To Do Next",
                "footer":     "About Kinto",
            }

            for key, text in content.items():
                if key == "header":
                    continue
                title = section_titles.get(key, key.title())
                story.append(Paragraph(title, section_style))
                # Clean the text and add as paragraphs
                for line in text.split("\n"):
                    clean = line.strip()
                    if clean and not clean.startswith("─") and not clean.startswith("═"):
                        story.append(Paragraph(clean, body_style))

            doc.build(story)
            return filepath

        except ImportError:
            # reportlab not available — fall back to text
            print("\n  [KINTO] PDF library not available.")
            print("  [KINTO] Saving as text file instead.\n")
            return self._save_txt(content)


# ── Report Prompt ─────────────────────────────────────────────────────────────

def offer_report(scan_results: dict = None, repair_actions: list = None):
    """
    Offer the user a report at the end of a scan or repair session.
    Called by the engine after any scan completes.
    Plain language. No pressure.
    """
    print("\n  ─────────────────────────────────────────────")
    print("  Would you like a copy of what Kinto found?")
    print()
    print("  You can save it for your records, show it")
    print("  to a repair shop, or just keep it for")
    print("  peace of mind.")
    print()
    print("  1. Save as text file (.txt)")
    print("  2. Save as PDF")
    print("  3. No thanks")
    print()

    try:
        choice = input("  Your choice (1, 2, or 3): ").strip()
    except (KeyboardInterrupt, EOFError):
        choice = "3"

    if choice not in ("1", "2"):
        print("\n  No problem. Your scan results are saved")
        print("  in Kinto's audit log if you change your mind.\n")
        return None

    fmt = "txt" if choice == "1" else "pdf"

    report = KintoReport()
    report.load_from_audit_log()

    if scan_results:
        report.load_from_scan(scan_results, repair_actions)

    print("\n  Generating your report...\n")
    filepath = report.generate(fmt=fmt)

    print(f"  ✓  Report saved:")
    print(f"     {filepath}")
    print()
    print("  This report is yours.")
    print("  Keep it, share it, or show it to a repair shop.")
    print("  It explains everything in plain language.")
    print()

    return filepath
