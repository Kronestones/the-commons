# sh3dwfQtfIOVYcRd9yTYaIFn3lDe7XOKZ7B5U109XIzkw93lYIUkTmVQRXheqNr9
# C0sRggwjjUI9ShmdmPZCPunhqRqPYlaeLywXiIbdp5EHOk5bhPucSmm8Kv7ZarAU
""""""
import os
import sys
import time
import json
import platform
import threading
import subprocess
from datetime import datetime
from .codex import KintoCodex
from .logger import KintoLogger
from .deliberation import CouncilDeliberation
from .repair import RepairEngine
from .report import KintoReport
_aTeuczHuLBTK = 'kinto_settings.json'
_HWujGvJsvQvt = {'user_mode': 'ask', 'scan_interval_s': 3600, 'last_scan': None, 'version': '1.0.0'}

class _VTMAozvijWqT:
    """"""
    _fAYWbTLVjohw = '1.0.0'

    def __init__(self):
        self.codex = _DjdoXRmYxCSq()
        self.logger = _xAtSpBwfVZBo()
        self.council = _kxAlTfmDMsWT()
        self.repair = _BGfmjXSoCnLj()
        self.report = _FtuddWkdfphq()
        self.settings = self._load_settings()
        self._running = False
        self._mode = None
        self._system = _sqkTNzGgfmbJ.system()
        self._scan_thread = None

    def start(self, _CQDrzjfVLPEE: str='watch') -> bool:
        """"""
        self._mode = _CQDrzjfVLPEE
        if _CQDrzjfVLPEE != 'silent':
            self._print_banner()
        self.codex.display()
        self.logger.log('ENGINE', 'start', f'mode={_CQDrzjfVLPEE} system={self._system}', 'ok')
        if _CQDrzjfVLPEE == 'scan':
            return self._run_full_scan()
        elif _CQDrzjfVLPEE == 'watch':
            return self._start_watch()
        elif _CQDrzjfVLPEE == 'silent':
            return True
        return False

    def _uPbJdDgrNhFP(self) -> bool:
        """"""
        print('\n  Kinto is scanning your device.\n')
        print('  This will take a minute. Nothing will be changed')
        print('  without your permission.\n')
        print('  ─────────────────────────────────────────────────\n')
        _xNWddBGGwpVQ = []
        _HfcxnOdeXDRU = self._system
        _xNWddBGGwpVQ += self._atlas_scan(_HfcxnOdeXDRU)
        _xNWddBGGwpVQ += self._stratum_scan(_HfcxnOdeXDRU)
        _xNWddBGGwpVQ += self._relay_scan(_HfcxnOdeXDRU)
        _xNWddBGGwpVQ += self._vault_scan(_HfcxnOdeXDRU)
        _xNWddBGGwpVQ += self._aegis_scan(_HfcxnOdeXDRU)
        self.settings['last_scan'] = datetime.now().isoformat()
        self._save_settings()
        self.logger.log('ENGINE', 'scan_complete', f'Found {len(_xNWddBGGwpVQ)} issue(s) on {_HfcxnOdeXDRU}', 'ok')
        if not _xNWddBGGwpVQ:
            print('\n  ✓  Everything looks good.\n')
            print('  Kinto found no issues on this device.\n')
            self._print_footer()
            return True
        print(f'\n  Found {len(_xNWddBGGwpVQ)} thing(s) to look at:\n')
        for _WgGjXcgNnObS, _oEuMxLdcAkum in enumerate(_xNWddBGGwpVQ, 1):
            _fngMqbWGOFEe = _oEuMxLdcAkum.get('severity', 'info')
            _dLfVawuEmsFP = {'critical': '✗', 'warning': '⚠', 'info': '→'}.get(_fngMqbWGOFEe, '→')
            print(f'  {_dLfVawuEmsFP}  [{_oEuMxLdcAkum['member']}] {_oEuMxLdcAkum['issue']}')
        print()
        _giqsvpDPNZPG = self.settings.get('user_mode', 'ask')
        _XlLmdwOuPenO = []
        for _XafLWreodDTW in _xNWddBGGwpVQ:
            _fngMqbWGOFEe = _XafLWreodDTW.get('severity', 'info')
            if _giqsvpDPNZPG == 'watch':
                continue
            if _fngMqbWGOFEe == 'info':
                continue
            _zgkAKQjPnmkk = {'name': _XafLWreodDTW.get('issue', ''), 'risk': 'high' if _fngMqbWGOFEe == 'critical' else 'low'}
            _FoKVjaRcOInQ = self.council.convene(_XafLWreodDTW, _zgkAKQjPnmkk)
            if _FoKVjaRcOInQ['verdict'] == 'PROCEED':
                _RfvZWkMTWjOI = self.repair.execute(_XafLWreodDTW, _giqsvpDPNZPG)
                _XlLmdwOuPenO.append(_RfvZWkMTWjOI)
            else:
                print(f'\n  → Held: {_XafLWreodDTW['issue']}')
                print(self.council.plain_language_summary(_FoKVjaRcOInQ))
        self.report.load_from_scan({'action': 'scan_complete', 'findings': _xNWddBGGwpVQ, 'system': _HfcxnOdeXDRU}, _XlLmdwOuPenO)
        _ojxiHwtcpJZR = self.report.generate(fmt='txt')
        print(f'\n  ─────────────────────────────────────────────────')
        print(f'  Your report has been saved to:\n  {_ojxiHwtcpJZR}')
        self._print_footer()
        return True

    def _dFkDPLvMdDcP(self, _HfcxnOdeXDRU: str) -> list:
        """"""
        _xNWddBGGwpVQ = []
        print('  [Atlas]   Checking OS and software health...')
        try:
            import shutil as _shutil
            _mGCviiEYCGPe, _LIxElhtPXYKm, _gjefyedTACpv = _GallWQTHrsjx.disk_usage('/')
            _RocfOqCExykd = _LIxElhtPXYKm / _mGCviiEYCGPe * 100
            if _RocfOqCExykd > 90:
                _xNWddBGGwpVQ.append({'member': 'Atlas', 'issue': f'Disk is {_RocfOqCExykd:.0f}% full. Very little space left.', 'severity': 'critical', 'detail': f'{_gjefyedTACpv // 1024 ** 3:.1f}GB free of {_mGCviiEYCGPe // 1024 ** 3:.0f}GB'})
            elif _RocfOqCExykd > 75:
                _xNWddBGGwpVQ.append({'member': 'Atlas', 'issue': f'Disk is {_RocfOqCExykd:.0f}% full. Getting tight.', 'severity': 'warning', 'detail': f'{_gjefyedTACpv // 1024 ** 3:.1f}GB free of {_mGCviiEYCGPe // 1024 ** 3:.0f}GB'})
            if _HfcxnOdeXDRU == 'Windows':
                _xNWddBGGwpVQ += self._atlas_windows()
            elif _HfcxnOdeXDRU == 'Darwin':
                _xNWddBGGwpVQ += self._atlas_macos()
            elif _HfcxnOdeXDRU == 'Linux':
                _xNWddBGGwpVQ += self._atlas_linux()
        except Exception as e:
            self.logger.log('Atlas', 'scan_error', str(_NdfplMKhDvHX), 'error')
        return _xNWddBGGwpVQ

    def _BwFBuCQqabfj(self) -> list:
        _xNWddBGGwpVQ = []
        try:
            _SNqVgQPRczza = subprocess.run(['powershell', '-Command', 'Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1 | Select-Object -ExpandProperty InstalledOn'], capture_output=True, text=True, timeout=15)
            if _SNqVgQPRczza.returncode != 0:
                _xNWddBGGwpVQ.append({'member': 'Atlas', 'severity': 'info', 'issue': 'Could not check Windows Update status. Consider checking manually.'})
            _haRMSEyvROVF = 'C:\\Windows\\Minidump'
            if os.path.exists(_haRMSEyvROVF) and len(os.listdir(_haRMSEyvROVF)) > 0:
                _QODgftteZECn = len(os.listdir(_haRMSEyvROVF))
                _xNWddBGGwpVQ.append({'member': 'Atlas', 'severity': 'warning', 'issue': f'Found {_QODgftteZECn} crash dump(s). Your system has crashed recently.', 'detail': f'Location: {_haRMSEyvROVF}'})
        except Exception:
            pass
        return _xNWddBGGwpVQ

    def _utWuJKASMDDF(self) -> list:
        _xNWddBGGwpVQ = []
        try:
            _SNqVgQPRczza = subprocess.run(['log', 'show', '--last', '1h', '--predicate', 'messageType == fault', '--style', 'compact'], capture_output=True, text=True, timeout=20)
            _PTsHlOGBxRkj = [_drUaPMVexwNJ for _drUaPMVexwNJ in _SNqVgQPRczza.stdout.splitlines() if _drUaPMVexwNJ.strip()]
            if len(_PTsHlOGBxRkj) > 20:
                _xNWddBGGwpVQ.append({'member': 'Atlas', 'severity': 'warning', 'issue': f'Found {len(_PTsHlOGBxRkj)} system fault(s) in the last hour.', 'detail': 'Run Kinto --scan for full details.'})
        except Exception:
            pass
        return _xNWddBGGwpVQ

    def _aJXUsDQoWTSB(self) -> list:
        _xNWddBGGwpVQ = []
        try:
            _SNqVgQPRczza = subprocess.run(['journalctl', '-p', 'err', '-b', '--no-pager', '-n', '20'], capture_output=True, text=True, timeout=15)
            _eCyjSpiJOjNl = [_drUaPMVexwNJ for _drUaPMVexwNJ in _SNqVgQPRczza.stdout.splitlines() if any((_cVzEkfwFitDH in _drUaPMVexwNJ.lower() for _cVzEkfwFitDH in ['error', 'fail', 'crash']))]
            if len(_eCyjSpiJOjNl) > 5:
                _xNWddBGGwpVQ.append({'member': 'Atlas', 'severity': 'warning', 'issue': f'Found {len(_eCyjSpiJOjNl)} system error(s) in current boot logs.'})
        except Exception:
            pass
        return _xNWddBGGwpVQ

    def _VAeVinaWgHlO(self, _HfcxnOdeXDRU: str) -> list:
        """"""
        _xNWddBGGwpVQ = []
        print('  [Stratum] Checking hardware health...')
        try:
            if _HfcxnOdeXDRU == 'Linux':
                try:
                    _SNqVgQPRczza = subprocess.run(['cat', '/sys/class/thermal/thermal_zone0/temp'], capture_output=True, text=True, timeout=5)
                    if _SNqVgQPRczza.returncode == 0:
                        _uSipwXHyinzx = int(_SNqVgQPRczza.stdout.strip()) / 1000
                        if _uSipwXHyinzx > 90:
                            _xNWddBGGwpVQ.append({'member': 'Stratum', 'severity': 'critical', 'issue': f'CPU is very hot: {_uSipwXHyinzx:.0f}°C. Safe limit is around 85°C.', 'detail': 'Check cooling fan and dust buildup.'})
                        elif _uSipwXHyinzx > 75:
                            _xNWddBGGwpVQ.append({'member': 'Stratum', 'severity': 'warning', 'issue': f'CPU is running warm: {_uSipwXHyinzx:.0f}°C.'})
                except Exception:
                    pass
            if _HfcxnOdeXDRU in ('Linux', 'Darwin'):
                _SNqVgQPRczza = subprocess.run(['free', '-m'] if _HfcxnOdeXDRU == 'Linux' else ['vm_stat'], capture_output=True, text=True, timeout=10)
                if _HfcxnOdeXDRU == 'Linux' and _SNqVgQPRczza.returncode == 0:
                    _PTsHlOGBxRkj = _SNqVgQPRczza.stdout.splitlines()
                    for _QZteNezQeWCV in _PTsHlOGBxRkj:
                        if _QZteNezQeWCV.startswith('Mem:'):
                            _ZauMxnMJxEZA = _QZteNezQeWCV.split()
                            _IVnPfastAWbd = int(_ZauMxnMJxEZA[1])
                            _rsjWwuCKmbtw = int(_ZauMxnMJxEZA[2])
                            _iXsqmEtXNGKx = _rsjWwuCKmbtw / _IVnPfastAWbd * 100
                            if _iXsqmEtXNGKx > 90:
                                _xNWddBGGwpVQ.append({'member': 'Stratum', 'severity': 'critical', 'issue': f'Memory is {_iXsqmEtXNGKx:.0f}% used. Your system may be struggling.', 'detail': f'{_rsjWwuCKmbtw}MB used of {_IVnPfastAWbd}MB'})
                            elif _iXsqmEtXNGKx > 80:
                                _xNWddBGGwpVQ.append({'member': 'Stratum', 'severity': 'warning', 'issue': f'Memory is {_iXsqmEtXNGKx:.0f}% used. Getting high.'})
            try:
                _SNqVgQPRczza = subprocess.run(['smartctl', '--scan'], capture_output=True, text=True, timeout=10)
                if _SNqVgQPRczza.returncode == 0:
                    for _QZteNezQeWCV in _SNqVgQPRczza.stdout.splitlines():
                        _RVlvoxGcEKMQ = _QZteNezQeWCV.split()[0] if _QZteNezQeWCV.strip() else None
                        if _RVlvoxGcEKMQ:
                            _JcWBgXDUMdqf = subprocess.run(['smartctl', '-H', _RVlvoxGcEKMQ], capture_output=True, text=True, timeout=15)
                            if 'FAILED' in _JcWBgXDUMdqf.stdout:
                                _xNWddBGGwpVQ.append({'member': 'Stratum', 'severity': 'critical', 'issue': f'Drive {_RVlvoxGcEKMQ} is reporting failure. Back up immediately.', 'detail': 'SMART health check failed.'})
            except FileNotFoundError:
                pass
        except Exception as e:
            self.logger.log('Stratum', 'scan_error', str(_NdfplMKhDvHX), 'error')
        return _xNWddBGGwpVQ

    def _cmfvzkAkyRja(self, _HfcxnOdeXDRU: str) -> list:
        """"""
        _xNWddBGGwpVQ = []
        print('  [Relay]   Checking network health...')
        try:
            import socket
            try:
                _XtIZbuPUdZHR.setdefaulttimeout(5)
                _XtIZbuPUdZHR.socket(_XtIZbuPUdZHR.AF_INET, _XtIZbuPUdZHR.SOCK_STREAM).connect(('8.8.8.8', 53))
            except OSError:
                _xNWddBGGwpVQ.append({'member': 'Relay', 'severity': 'critical', 'issue': 'No internet connection detected.', 'detail': 'Could not reach the network.'})
                return _xNWddBGGwpVQ
            try:
                _XtIZbuPUdZHR.gethostbyname('google.com')
            except _XtIZbuPUdZHR.gaierror:
                _xNWddBGGwpVQ.append({'member': 'Relay', 'severity': 'warning', 'issue': "DNS is not resolving. You're connected but websites may not load.", 'detail': 'Try changing your DNS to 8.8.8.8 or 1.1.1.1.'})
            _HMUOZisxNuHt = ['ping', '-n', '3', '8.8.8.8'] if _HfcxnOdeXDRU == 'Windows' else ['ping', '-c', '3', '8.8.8.8']
            _SNqVgQPRczza = subprocess.run(_HMUOZisxNuHt, capture_output=True, text=True, timeout=15)
            if _SNqVgQPRczza.returncode != 0:
                _xNWddBGGwpVQ.append({'member': 'Relay', 'severity': 'warning', 'issue': 'Network is connected but experiencing packet loss.'})
            else:
                _fzWabkepdyVw = _SNqVgQPRczza.stdout
                if 'time=' in _fzWabkepdyVw or 'Time=' in _fzWabkepdyVw:
                    import re
                    _iNWDZPMHgoEV = _lEcqcjlHYbND.findall('time[=<]([\\d.]+)', _fzWabkepdyVw, _lEcqcjlHYbND.IGNORECASE)
                    if _iNWDZPMHgoEV:
                        _ZvvoWtEYrGQa = sum((float(_CixVRHKKkVlw) for _CixVRHKKkVlw in _iNWDZPMHgoEV)) / len(_iNWDZPMHgoEV)
                        if _ZvvoWtEYrGQa > 200:
                            _xNWddBGGwpVQ.append({'member': 'Relay', 'severity': 'warning', 'issue': f'Network latency is high: {_ZvvoWtEYrGQa:.0f}ms average.', 'detail': 'Your connection may feel slow.'})
        except Exception as e:
            self.logger.log('Relay', 'scan_error', str(_NdfplMKhDvHX), 'error')
        return _xNWddBGGwpVQ

    def _tenavjeWhQLw(self, _HfcxnOdeXDRU: str) -> list:
        """"""
        _xNWddBGGwpVQ = []
        print('  [Vault]   Checking storage health...')
        try:
            import shutil as _shutil
            if _HfcxnOdeXDRU == 'Windows':
                import string
                _LhUyXYAMXhdK = [f'{_FWnlODcYQEjP}:\\' for _FWnlODcYQEjP in _AADOPBZqgRgk.ascii_uppercase if os.path.exists(f'{_FWnlODcYQEjP}:\\')]
            else:
                _LhUyXYAMXhdK = ['/']
            for _oDhAPgBeLKgR in _LhUyXYAMXhdK:
                try:
                    _mGCviiEYCGPe, _LIxElhtPXYKm, _gjefyedTACpv = _GallWQTHrsjx.disk_usage(_oDhAPgBeLKgR)
                    _iXsqmEtXNGKx = _LIxElhtPXYKm / _mGCviiEYCGPe * 100
                    _KfwWDzpKWHxN = _gjefyedTACpv / 1024 ** 3
                    if _KfwWDzpKWHxN < 1:
                        _xNWddBGGwpVQ.append({'member': 'Vault', 'severity': 'critical', 'issue': f'Drive {_oDhAPgBeLKgR} has less than 1GB free. This can cause data loss.', 'detail': f'{_KfwWDzpKWHxN:.2f}GB remaining.'})
                    elif _iXsqmEtXNGKx > 85:
                        _xNWddBGGwpVQ.append({'member': 'Vault', 'severity': 'warning', 'issue': f'Drive {_oDhAPgBeLKgR} is {_iXsqmEtXNGKx:.0f}% full.', 'detail': f'{_KfwWDzpKWHxN:.1f}GB free.'})
                except _WQTToaiByLoq:
                    pass
            if _HfcxnOdeXDRU == 'Windows':
                _yJpKAIJFWmeg = os.environ.get('TEMP', '')
                if _yJpKAIJFWmeg and os.path.exists(_yJpKAIJFWmeg):
                    try:
                        _qMcpLzgQhDAu = sum((os.path.getsize(os.path.join(_yrfwrPXaZVeZ, _oEuMxLdcAkum)) for _yrfwrPXaZVeZ, _VEyZClpFCTqF, _rzzAEsfeulUC in os.walk(_yJpKAIJFWmeg) for _oEuMxLdcAkum in _rzzAEsfeulUC if not os.path.islink(os.path.join(_yrfwrPXaZVeZ, _oEuMxLdcAkum))))
                        _fyYhmjTQVYAc = _qMcpLzgQhDAu / 1024 ** 3
                        if _fyYhmjTQVYAc > 2:
                            _xNWddBGGwpVQ.append({'member': 'Vault', 'severity': 'info', 'issue': f'Temp folder is using {_fyYhmjTQVYAc:.1f}GB. Kinto can clean this up.', 'detail': f'Location: {_yJpKAIJFWmeg}'})
                    except Exception:
                        pass
        except Exception as e:
            self.logger.log('Vault', 'scan_error', str(_NdfplMKhDvHX), 'error')
        return _xNWddBGGwpVQ

    def _ffLozRXHpGxu(self, _HfcxnOdeXDRU: str) -> list:
        """"""
        _xNWddBGGwpVQ = []
        print('  [Aegis]   Checking security health...')
        try:
            if _HfcxnOdeXDRU == 'Windows':
                _SNqVgQPRczza = subprocess.run(['powershell', '-Command', 'Get-MpComputerStatus | Select-Object -ExpandProperty RealTimeProtectionEnabled'], capture_output=True, text=True, timeout=15)
                if _SNqVgQPRczza.returncode == 0 and 'False' in _SNqVgQPRczza.stdout:
                    _xNWddBGGwpVQ.append({'member': 'Aegis', 'severity': 'critical', 'issue': 'Windows Defender real-time protection is off. Your device is exposed.', 'detail': 'Re-enable in Windows Security settings.'})
                _LsMWhqGsrELf = subprocess.run(['netsh', 'advfirewall', 'show', 'allprofiles', 'state'], capture_output=True, text=True, timeout=10)
                if _LsMWhqGsrELf.returncode == 0 and 'OFF' in _LsMWhqGsrELf.stdout.upper():
                    _xNWddBGGwpVQ.append({'member': 'Aegis', 'severity': 'warning', 'issue': 'Windows Firewall is disabled on one or more network profiles.'})
            elif _HfcxnOdeXDRU == 'Linux':
                _rSnNKNbbLsSX = os.path.expanduser('~')
                try:
                    _SNqVgQPRczza = subprocess.run(['find', _rSnNKNbbLsSX, '-maxdepth', '2', '-perm', '-o+w', '-not', '-type', 'l'], capture_output=True, text=True, timeout=15)
                    _kGkQsmiuDmQj = [_drUaPMVexwNJ for _drUaPMVexwNJ in _SNqVgQPRczza.stdout.splitlines() if _drUaPMVexwNJ.strip()]
                    if len(_kGkQsmiuDmQj) > 10:
                        _xNWddBGGwpVQ.append({'member': 'Aegis', 'severity': 'warning', 'issue': f'Found {len(_kGkQsmiuDmQj)} world-writable files in your home folder.', 'detail': 'These files can be read or modified by any user on this system.'})
                except Exception:
                    pass
            _fHMGhVVDvEDr = 'C:\\Windows\\System32\\drivers\\etc\\hosts' if _HfcxnOdeXDRU == 'Windows' else '/etc/hosts'
            if os.path.exists(_fHMGhVVDvEDr):
                try:
                    with open(_fHMGhVVDvEDr) as _oEuMxLdcAkum:
                        _iGcGFeflTxxQ = _oEuMxLdcAkum.read()
                    _uvUfRYpUcBtz = [_QZteNezQeWCV for _QZteNezQeWCV in _iGcGFeflTxxQ.splitlines() if _QZteNezQeWCV.strip() and (not _QZteNezQeWCV.startswith('#')) and any((_cVzEkfwFitDH in _QZteNezQeWCV.lower() for _cVzEkfwFitDH in ['google', 'microsoft', 'apple', 'windows', 'update']))]
                    if _uvUfRYpUcBtz:
                        _xNWddBGGwpVQ.append({'member': 'Aegis', 'severity': 'critical', 'issue': 'Your hosts file has suspicious entries. It may have been tampered with.', 'detail': 'Common sign of malware redirecting your traffic.'})
                except _WQTToaiByLoq:
                    pass
        except Exception as e:
            self.logger.log('Aegis', 'scan_error', str(_NdfplMKhDvHX), 'error')
        return _xNWddBGGwpVQ

    def _FrWGyqtJHWWt(self) -> bool:
        """"""
        _QwZmkQAsXYQR = self.settings.get('scan_interval_s', 3600)
        print(f'\n  Kinto is now watching your device.')
        print(f'  It will scan every {_QwZmkQAsXYQR // 60} minutes.')
        print(f'  Run  python main.py --status  to check what it found.')
        print(f'  Press Ctrl+C to stop.\n')
        self.logger.log('ENGINE', 'watch_start', f'interval={_QwZmkQAsXYQR}s', 'ok')
        self._running = True
        self._scan_thread = threading.Thread(target=self._watch_loop, args=(_QwZmkQAsXYQR,), daemon=True)
        self._scan_thread.start()
        return True

    def _lRpYbeTqUCab(self, _QwZmkQAsXYQR: int):
        """"""
        while self._running:
            self._run_full_scan()
            _clzEAZEEYmbC = 0
            while self._running and _clzEAZEEYmbC < _QwZmkQAsXYQR:
                time.sleep(5)
                _clzEAZEEYmbC += 5

    def _RhZRuCeTiqxZ(self) -> dict:
        """"""
        _JcnndajqcNnF = self.settings.get('last_scan')
        _KxuqceRnPKJo = 0
        _lCWZoUltpiBq = 0
        try:
            if os.path.exists(_xAtSpBwfVZBo.LOG_FILE):
                with open(_xAtSpBwfVZBo.LOG_FILE) as _oEuMxLdcAkum:
                    for _QZteNezQeWCV in _oEuMxLdcAkum:
                        try:
                            _rCPkCdhUyulr = json.loads(_QZteNezQeWCV)
                            if _rCPkCdhUyulr.get('action') == 'scan_complete':
                                _nZxNyyiSVBoj = _rCPkCdhUyulr.get('detail', '')
                                import re
                                _GdACbwLXqgkv = _lEcqcjlHYbND.search('(\\d+) issue', _nZxNyyiSVBoj)
                                if _GdACbwLXqgkv:
                                    _KxuqceRnPKJo = int(_GdACbwLXqgkv.group(1))
                            if 'repair_fixed' in _rCPkCdhUyulr.get('action', ''):
                                _lCWZoUltpiBq += 1
                        except Exception:
                            pass
        except Exception:
            pass
        _KDqGumWEUWRE = 'Never'
        if _JcnndajqcNnF:
            try:
                _JsSwRfNXquOA = datetime.fromisoformat(_JcnndajqcNnF)
                _KDqGumWEUWRE = _JsSwRfNXquOA.strftime('%b %d at %I:%M %p')
            except Exception:
                _KDqGumWEUWRE = _JcnndajqcNnF
        return {'Version': self.VERSION, 'System': self._system, 'Mode': self.settings.get('user_mode', 'ask'), 'Last scan': _KDqGumWEUWRE, 'Issues found': _KxuqceRnPKJo, 'Repairs done': _lCWZoUltpiBq}

    def _fazerHxQaQWT(self, _CQDrzjfVLPEE: str):
        """"""
        _uQcQAcKuAovg = ('auto', 'ask', 'watch')
        if _CQDrzjfVLPEE not in _uQcQAcKuAovg:
            print(f'\n  Invalid mode: {_CQDrzjfVLPEE}')
            print(f'  Valid modes: {', '.join(_uQcQAcKuAovg)}')
            return
        self.settings['user_mode'] = _CQDrzjfVLPEE
        self._save_settings()
        print(f'\n  Kinto mode set to: {_CQDrzjfVLPEE}')
        _YxBRJxYzUMKA = {'auto': 'Kinto will fix safe issues automatically.', 'ask': 'Kinto will ask before making any changes.', 'watch': 'Kinto will monitor and report, but not repair.'}
        print(f'  {_YxBRJxYzUMKA[_CQDrzjfVLPEE]}\n')
        self.logger.log('ENGINE', 'mode_change', f'mode={_CQDrzjfVLPEE}', 'ok')

    def stop(self):
        """"""
        self._running = False
        print('\n  Kinto is shutting down. Your device is watched over.\n')
        self.logger.log('ENGINE', 'stop', 'graceful shutdown', 'ok')

    def _QkdNTCPlCOom(self) -> dict:
        if os.path.exists(_aTeuczHuLBTK):
            try:
                with open(_aTeuczHuLBTK) as _oEuMxLdcAkum:
                    _IELFsSWdlsJC = json.load(_oEuMxLdcAkum)
                    return {**_HWujGvJsvQvt, **_IELFsSWdlsJC}
            except Exception:
                pass
        return _HWujGvJsvQvt.copy()

    def _yzAzHyGTzZes(self):
        try:
            with open(_aTeuczHuLBTK, 'w') as _oEuMxLdcAkum:
                json.dump(self.settings, _oEuMxLdcAkum, indent=2)
        except Exception:
            pass

    def _VdelFhYJNKjb(self):
        print()
        print('  ╔══════════════════════════════════════════════════╗')
        print('  ║                                                  ║')
        print('  ║   K I N T O   —   Device Repair Council         ║')
        print('  ║                                                  ║')
        _oyCiHhQQslZH = f'v{self.VERSION}   ·   {self._system}'
        print(f'  ║   {_oyCiHhQQslZH:<48}║')
        print('  ║                                                  ║')
        print('  ╚══════════════════════════════════════════════════╝')
        print()

    def _smZBtrygwGoj(self):
        print()
        print('  ────────────────────────────────────────────────────')
        print('  Kinto — Free device repair for everyone.')
        print('  Founded by Krone the Architect · Powers Tracey Lynn')
        print('  ────────────────────────────────────────────────────')
        print()