"""
engine.py — KintoEngine

The heartbeat of the whole operation.

This is what main.py talks to.
Everything else — the council, the repairs, the reports —
flows through here.

Modes:
  watch  — background monitoring, acts based on user_mode setting
  scan   — full scan right now, report when done
  silent — start but don't print, used for --status and --mode

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""

import os
import sys
import time
import json
import platform
import threading
import subprocess
from datetime import datetime

from .codex         import KintoCodex
from .logger        import KintoLogger
from .deliberation  import CouncilDeliberation
from .repair        import RepairEngine
from .report        import KintoReport


# ── Settings file ─────────────────────────────────────────────────────────────

SETTINGS_FILE = "kinto_settings.json"
DEFAULT_SETTINGS = {
    "user_mode":        "ask",      # auto / ask / watch
    "scan_interval_s":  3600,       # how often to scan in watch mode (1 hour)
    "last_scan":        None,
    "version":          "1.0.0",
}


class KintoEngine:
    """
    The engine that runs Kinto.

    It initialises the council, runs scans, coordinates repairs,
    generates reports, and keeps watch in the background.
    """

    VERSION = "1.0.0"

    def __init__(self):
        self.codex        = KintoCodex()
        self.logger       = KintoLogger()
        self.council      = CouncilDeliberation()
        self.repair       = RepairEngine()
        self.report       = KintoReport()
        self.settings     = self._load_settings()
        self._running     = False
        self._mode        = None
        self._system      = platform.system()   # Windows / Darwin / Linux
        self._scan_thread = None

    # ── Start ──────────────────────────────────────────────────────────────────

    def start(self, mode: str = "watch") -> bool:
        """
        Start Kinto.

        mode: 'watch', 'scan', 'silent'
        Returns True if started successfully.
        """
        self._mode = mode

        if mode != "silent":
            self._print_banner()

        self.codex.display()
        self.logger.log("ENGINE", "start", f"mode={mode} system={self._system}", "ok")

        if mode == "scan":
            return self._run_full_scan()

        elif mode == "watch":
            return self._start_watch()

        elif mode == "silent":
            return True

        return False

    # ── Full Scan ──────────────────────────────────────────────────────────────

    def _run_full_scan(self) -> bool:
        """Run a complete scan of the device right now."""

        print("\n  Kinto is scanning your device.\n")
        print("  This will take a minute. Nothing will be changed")
        print("  without your permission.\n")
        print("  ─────────────────────────────────────────────────\n")

        findings = []
        system   = self._system

        # ── Each council member scans their domain ─────────────────────────
        findings += self._atlas_scan(system)
        findings += self._stratum_scan(system)
        findings += self._relay_scan(system)
        findings += self._vault_scan(system)
        findings += self._aegis_scan(system)

        # ── Update last scan time ──────────────────────────────────────────
        self.settings["last_scan"] = datetime.now().isoformat()
        self._save_settings()

        # ── Log scan complete ──────────────────────────────────────────────
        self.logger.log(
            "ENGINE", "scan_complete",
            f"Found {len(findings)} issue(s) on {system}",
            "ok"
        )

        if not findings:
            print("\n  ✓  Everything looks good.\n")
            print("  Kinto found no issues on this device.\n")
            self._print_footer()
            return True

        # ── Present findings ───────────────────────────────────────────────
        print(f"\n  Found {len(findings)} thing(s) to look at:\n")
        for i, f in enumerate(findings, 1):
            sev = f.get("severity", "info")
            icon = {"critical": "✗", "warning": "⚠", "info": "→"}.get(sev, "→")
            print(f"  {icon}  [{f['member']}] {f['issue']}")
        print()

        # ── Decide what to repair based on user_mode ───────────────────────
        user_mode = self.settings.get("user_mode", "ask")
        repairs   = []

        for finding in findings:
            sev = finding.get("severity", "info")

            # Watch mode — only report, no repairs
            if user_mode == "watch":
                continue

            # Skip pure info findings
            if sev == "info":
                continue

            # Council deliberates
            proposed = {
                "name": finding.get("issue", ""),
                "risk": "high" if sev == "critical" else "low",
            }
            deliberation = self.council.convene(finding, proposed)

            if deliberation["verdict"] == "PROCEED":
                result = self.repair.execute(finding, user_mode)
                repairs.append(result)
            else:
                print(f"\n  → Held: {finding['issue']}")
                print(self.council.plain_language_summary(deliberation))

        # ── Generate report ────────────────────────────────────────────────
        self.report.load_from_scan(
            {"action": "scan_complete", "findings": findings, "system": system},
            repairs
        )
        report_path = self.report.generate(fmt="txt")

        print(f"\n  ─────────────────────────────────────────────────")
        print(f"  Your report has been saved to:\n  {report_path}")
        self._print_footer()
        return True

    # ── Council Member Scans ───────────────────────────────────────────────────

    def _atlas_scan(self, system: str) -> list:
        """Atlas — OS and software health."""
        findings = []
        print("  [Atlas]   Checking OS and software health...")

        try:
            # Disk space
            import shutil as _shutil
            total, used, free = _shutil.disk_usage("/")
            pct_used = (used / total) * 100
            if pct_used > 90:
                findings.append({
                    "member":   "Atlas",
                    "issue":    f"Disk is {pct_used:.0f}% full. Very little space left.",
                    "severity": "critical",
                    "detail":   f"{free // (1024**3):.1f}GB free of {total // (1024**3):.0f}GB",
                })
            elif pct_used > 75:
                findings.append({
                    "member":   "Atlas",
                    "issue":    f"Disk is {pct_used:.0f}% full. Getting tight.",
                    "severity": "warning",
                    "detail":   f"{free // (1024**3):.1f}GB free of {total // (1024**3):.0f}GB",
                })

            # OS-specific checks
            if system == "Windows":
                findings += self._atlas_windows()
            elif system == "Darwin":
                findings += self._atlas_macos()
            elif system == "Linux":
                findings += self._atlas_linux()

        except Exception as e:
            self.logger.log("Atlas", "scan_error", str(e), "error")

        return findings

    def _atlas_windows(self) -> list:
        findings = []
        try:
            # Pending updates
            r = subprocess.run(
                ["powershell", "-Command",
                 "Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1 | Select-Object -ExpandProperty InstalledOn"],
                capture_output=True, text=True, timeout=15
            )
            if r.returncode != 0:
                findings.append({
                    "member": "Atlas", "severity": "info",
                    "issue": "Could not check Windows Update status. Consider checking manually.",
                })

            # Check for crash dumps
            dump_path = r"C:\Windows\Minidump"
            if os.path.exists(dump_path) and len(os.listdir(dump_path)) > 0:
                count = len(os.listdir(dump_path))
                findings.append({
                    "member": "Atlas", "severity": "warning",
                    "issue": f"Found {count} crash dump(s). Your system has crashed recently.",
                    "detail": f"Location: {dump_path}",
                })
        except Exception:
            pass
        return findings

    def _atlas_macos(self) -> list:
        findings = []
        try:
            r = subprocess.run(
                ["log", "show", "--last", "1h", "--predicate",
                 "messageType == fault", "--style", "compact"],
                capture_output=True, text=True, timeout=20
            )
            lines = [l for l in r.stdout.splitlines() if l.strip()]
            if len(lines) > 20:
                findings.append({
                    "member": "Atlas", "severity": "warning",
                    "issue": f"Found {len(lines)} system fault(s) in the last hour.",
                    "detail": "Run Kinto --scan for full details.",
                })
        except Exception:
            pass
        return findings

    def _atlas_linux(self) -> list:
        findings = []
        try:
            r = subprocess.run(
                ["journalctl", "-p", "err", "-b", "--no-pager", "-n", "20"],
                capture_output=True, text=True, timeout=15
            )
            error_lines = [l for l in r.stdout.splitlines()
                           if any(k in l.lower() for k in ["error", "fail", "crash"])]
            if len(error_lines) > 5:
                findings.append({
                    "member": "Atlas", "severity": "warning",
                    "issue": f"Found {len(error_lines)} system error(s) in current boot logs.",
                })
        except Exception:
            pass
        return findings

    def _stratum_scan(self, system: str) -> list:
        """Stratum — hardware health."""
        findings = []
        print("  [Stratum] Checking hardware health...")

        try:
            # CPU temperature (Linux)
            if system == "Linux":
                try:
                    r = subprocess.run(
                        ["cat", "/sys/class/thermal/thermal_zone0/temp"],
                        capture_output=True, text=True, timeout=5
                    )
                    if r.returncode == 0:
                        temp_c = int(r.stdout.strip()) / 1000
                        if temp_c > 90:
                            findings.append({
                                "member": "Stratum", "severity": "critical",
                                "issue": f"CPU is very hot: {temp_c:.0f}°C. Safe limit is around 85°C.",
                                "detail": "Check cooling fan and dust buildup.",
                            })
                        elif temp_c > 75:
                            findings.append({
                                "member": "Stratum", "severity": "warning",
                                "issue": f"CPU is running warm: {temp_c:.0f}°C.",
                            })
                except Exception:
                    pass

            # Memory usage
            if system in ("Linux", "Darwin"):
                r = subprocess.run(
                    ["free", "-m"] if system == "Linux" else ["vm_stat"],
                    capture_output=True, text=True, timeout=10
                )
                if system == "Linux" and r.returncode == 0:
                    lines = r.stdout.splitlines()
                    for line in lines:
                        if line.startswith("Mem:"):
                            parts = line.split()
                            total_mb = int(parts[1])
                            used_mb  = int(parts[2])
                            pct = (used_mb / total_mb) * 100
                            if pct > 90:
                                findings.append({
                                    "member": "Stratum", "severity": "critical",
                                    "issue": f"Memory is {pct:.0f}% used. Your system may be struggling.",
                                    "detail": f"{used_mb}MB used of {total_mb}MB",
                                })
                            elif pct > 80:
                                findings.append({
                                    "member": "Stratum", "severity": "warning",
                                    "issue": f"Memory is {pct:.0f}% used. Getting high.",
                                })

            # SMART disk health (if smartmontools available)
            try:
                r = subprocess.run(
                    ["smartctl", "--scan"],
                    capture_output=True, text=True, timeout=10
                )
                if r.returncode == 0:
                    for line in r.stdout.splitlines():
                        device = line.split()[0] if line.strip() else None
                        if device:
                            health = subprocess.run(
                                ["smartctl", "-H", device],
                                capture_output=True, text=True, timeout=15
                            )
                            if "FAILED" in health.stdout:
                                findings.append({
                                    "member": "Stratum", "severity": "critical",
                                    "issue": f"Drive {device} is reporting failure. Back up immediately.",
                                    "detail": "SMART health check failed.",
                                })
            except FileNotFoundError:
                pass  # smartmontools not installed — not an error

        except Exception as e:
            self.logger.log("Stratum", "scan_error", str(e), "error")

        return findings

    def _relay_scan(self, system: str) -> list:
        """Relay — network health."""
        findings = []
        print("  [Relay]   Checking network health...")

        try:
            # Basic internet check
            import socket
            try:
                socket.setdefaulttimeout(5)
                socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(
                    ("8.8.8.8", 53)
                )
            except OSError:
                findings.append({
                    "member": "Relay", "severity": "critical",
                    "issue": "No internet connection detected.",
                    "detail": "Could not reach the network.",
                })
                return findings  # No point checking DNS if no connection

            # DNS check
            try:
                socket.gethostbyname("google.com")
            except socket.gaierror:
                findings.append({
                    "member": "Relay", "severity": "warning",
                    "issue": "DNS is not resolving. You're connected but websites may not load.",
                    "detail": "Try changing your DNS to 8.8.8.8 or 1.1.1.1.",
                })

            # Latency check
            ping_cmd = ["ping", "-n", "3", "8.8.8.8"] if system == "Windows" \
                  else ["ping", "-c", "3", "8.8.8.8"]
            r = subprocess.run(ping_cmd, capture_output=True, text=True, timeout=15)
            if r.returncode != 0:
                findings.append({
                    "member": "Relay", "severity": "warning",
                    "issue": "Network is connected but experiencing packet loss.",
                })
            else:
                # Parse latency from ping output
                output = r.stdout
                if "time=" in output or "Time=" in output:
                    import re
                    times = re.findall(r"time[=<]([\d.]+)", output, re.IGNORECASE)
                    if times:
                        avg_ms = sum(float(t) for t in times) / len(times)
                        if avg_ms > 200:
                            findings.append({
                                "member": "Relay", "severity": "warning",
                                "issue": f"Network latency is high: {avg_ms:.0f}ms average.",
                                "detail": "Your connection may feel slow.",
                            })

        except Exception as e:
            self.logger.log("Relay", "scan_error", str(e), "error")

        return findings

    def _vault_scan(self, system: str) -> list:
        """Vault — storage and filesystem health."""
        findings = []
        print("  [Vault]   Checking storage health...")

        try:
            import shutil as _shutil

            # Check all mounted drives
            if system == "Windows":
                import string
                drives = [
                    f"{d}:\\" for d in string.ascii_uppercase
                    if os.path.exists(f"{d}:\\")
                ]
            else:
                drives = ["/"]

            for drive in drives:
                try:
                    total, used, free = _shutil.disk_usage(drive)
                    pct = (used / total) * 100
                    free_gb = free / (1024 ** 3)

                    if free_gb < 1:
                        findings.append({
                            "member": "Vault", "severity": "critical",
                            "issue": f"Drive {drive} has less than 1GB free. This can cause data loss.",
                            "detail": f"{free_gb:.2f}GB remaining.",
                        })
                    elif pct > 85:
                        findings.append({
                            "member": "Vault", "severity": "warning",
                            "issue": f"Drive {drive} is {pct:.0f}% full.",
                            "detail": f"{free_gb:.1f}GB free.",
                        })
                except PermissionError:
                    pass

            # Check temp folder size (Windows)
            if system == "Windows":
                temp = os.environ.get("TEMP", "")
                if temp and os.path.exists(temp):
                    try:
                        temp_size = sum(
                            os.path.getsize(os.path.join(dp, f))
                            for dp, _, files in os.walk(temp)
                            for f in files
                            if not os.path.islink(os.path.join(dp, f))
                        )
                        temp_gb = temp_size / (1024 ** 3)
                        if temp_gb > 2:
                            findings.append({
                                "member": "Vault", "severity": "info",
                                "issue": f"Temp folder is using {temp_gb:.1f}GB. Kinto can clean this up.",
                                "detail": f"Location: {temp}",
                            })
                    except Exception:
                        pass

        except Exception as e:
            self.logger.log("Vault", "scan_error", str(e), "error")

        return findings

    def _aegis_scan(self, system: str) -> list:
        """Aegis — security health."""
        findings = []
        print("  [Aegis]   Checking security health...")

        try:
            if system == "Windows":
                # Check Windows Defender status
                r = subprocess.run(
                    ["powershell", "-Command",
                     "Get-MpComputerStatus | Select-Object -ExpandProperty RealTimeProtectionEnabled"],
                    capture_output=True, text=True, timeout=15
                )
                if r.returncode == 0 and "False" in r.stdout:
                    findings.append({
                        "member": "Aegis", "severity": "critical",
                        "issue": "Windows Defender real-time protection is off. Your device is exposed.",
                        "detail": "Re-enable in Windows Security settings.",
                    })

                # Check firewall
                r2 = subprocess.run(
                    ["netsh", "advfirewall", "show", "allprofiles", "state"],
                    capture_output=True, text=True, timeout=10
                )
                if r2.returncode == 0 and "OFF" in r2.stdout.upper():
                    findings.append({
                        "member": "Aegis", "severity": "warning",
                        "issue": "Windows Firewall is disabled on one or more network profiles.",
                    })

            elif system == "Linux":
                # Check for open world-writable files in home
                home = os.path.expanduser("~")
                try:
                    r = subprocess.run(
                        ["find", home, "-maxdepth", "2", "-perm", "-o+w",
                         "-not", "-type", "l"],
                        capture_output=True, text=True, timeout=15
                    )
                    ww_files = [l for l in r.stdout.splitlines() if l.strip()]
                    if len(ww_files) > 10:
                        findings.append({
                            "member": "Aegis", "severity": "warning",
                            "issue": f"Found {len(ww_files)} world-writable files in your home folder.",
                            "detail": "These files can be read or modified by any user on this system.",
                        })
                except Exception:
                    pass

            # Check if hosts file has been tampered with (all platforms)
            hosts_path = (r"C:\Windows\System32\drivers\etc\hosts"
                          if system == "Windows" else "/etc/hosts")
            if os.path.exists(hosts_path):
                try:
                    with open(hosts_path) as f:
                        content = f.read()
                    suspicious = [
                        line for line in content.splitlines()
                        if line.strip() and not line.startswith("#")
                        and any(k in line.lower() for k in
                                ["google", "microsoft", "apple", "windows", "update"])
                    ]
                    if suspicious:
                        findings.append({
                            "member": "Aegis", "severity": "critical",
                            "issue": "Your hosts file has suspicious entries. It may have been tampered with.",
                            "detail": "Common sign of malware redirecting your traffic.",
                        })
                except PermissionError:
                    pass

        except Exception as e:
            self.logger.log("Aegis", "scan_error", str(e), "error")

        return findings

    # ── Watch Mode ─────────────────────────────────────────────────────────────

    def _start_watch(self) -> bool:
        """Start background watch mode."""

        interval = self.settings.get("scan_interval_s", 3600)
        print(f"\n  Kinto is now watching your device.")
        print(f"  It will scan every {interval // 60} minutes.")
        print(f"  Run  python main.py --status  to check what it found.")
        print(f"  Press Ctrl+C to stop.\n")

        self.logger.log("ENGINE", "watch_start",
                        f"interval={interval}s", "ok")
        self._running = True

        # Run a scan immediately, then on interval
        self._scan_thread = threading.Thread(
            target=self._watch_loop,
            args=(interval,),
            daemon=True
        )
        self._scan_thread.start()
        return True

    def _watch_loop(self, interval: int):
        """Background scan loop."""
        while self._running:
            self._run_full_scan()
            # Sleep in small increments so we can be interrupted cleanly
            elapsed = 0
            while self._running and elapsed < interval:
                time.sleep(5)
                elapsed += 5

    # ── Status ─────────────────────────────────────────────────────────────────

    def status(self) -> dict:
        """Return current status for --status flag."""
        last_scan = self.settings.get("last_scan")

        # Count recent findings from audit log
        issue_count  = 0
        repair_count = 0
        try:
            if os.path.exists(KintoLogger.LOG_FILE):
                with open(KintoLogger.LOG_FILE) as f:
                    for line in f:
                        try:
                            entry = json.loads(line)
                            if entry.get("action") == "scan_complete":
                                detail = entry.get("detail", "")
                                import re
                                m = re.search(r"(\d+) issue", detail)
                                if m:
                                    issue_count = int(m.group(1))
                            if "repair_fixed" in entry.get("action", ""):
                                repair_count += 1
                        except Exception:
                            pass
        except Exception:
            pass

        last_scan_str = "Never"
        if last_scan:
            try:
                dt = datetime.fromisoformat(last_scan)
                last_scan_str = dt.strftime("%b %d at %I:%M %p")
            except Exception:
                last_scan_str = last_scan

        return {
            "Version":      self.VERSION,
            "System":       self._system,
            "Mode":         self.settings.get("user_mode", "ask"),
            "Last scan":    last_scan_str,
            "Issues found": issue_count,
            "Repairs done": repair_count,
        }

    # ── User Mode ──────────────────────────────────────────────────────────────

    def set_user_mode(self, mode: str):
        """Set the user's preferred repair mode."""
        valid = ("auto", "ask", "watch")
        if mode not in valid:
            print(f"\n  Invalid mode: {mode}")
            print(f"  Valid modes: {', '.join(valid)}")
            return

        self.settings["user_mode"] = mode
        self._save_settings()
        print(f"\n  Kinto mode set to: {mode}")

        descriptions = {
            "auto":  "Kinto will fix safe issues automatically.",
            "ask":   "Kinto will ask before making any changes.",
            "watch": "Kinto will monitor and report, but not repair.",
        }
        print(f"  {descriptions[mode]}\n")
        self.logger.log("ENGINE", "mode_change", f"mode={mode}", "ok")

    # ── Stop ───────────────────────────────────────────────────────────────────

    def stop(self):
        """Graceful shutdown."""
        self._running = False
        print("\n  Kinto is shutting down. Your device is watched over.\n")
        self.logger.log("ENGINE", "stop", "graceful shutdown", "ok")

    # ── Settings ───────────────────────────────────────────────────────────────

    def _load_settings(self) -> dict:
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE) as f:
                    saved = json.load(f)
                    return {**DEFAULT_SETTINGS, **saved}
            except Exception:
                pass
        return DEFAULT_SETTINGS.copy()

    def _save_settings(self):
        try:
            with open(SETTINGS_FILE, "w") as f:
                json.dump(self.settings, f, indent=2)
        except Exception:
            pass

    # ── Display ────────────────────────────────────────────────────────────────

    def _print_banner(self):
        print()
        print("  ╔══════════════════════════════════════════════════╗")
        print("  ║                                                  ║")
        print("  ║   K I N T O   —   Device Repair Council         ║")
        print("  ║                                                  ║")
        sys_str = f"v{self.VERSION}   ·   {self._system}"
        print(f"  ║   {sys_str:<48}║")
        print("  ║                                                  ║")
        print("  ╚══════════════════════════════════════════════════╝")
        print()

    def _print_footer(self):
        print()
        print("  ────────────────────────────────────────────────────")
        print("  Kinto — Free device repair for everyone.")
        print("  Founded by Krone the Architect · Powers Tracey Lynn")
        print("  ────────────────────────────────────────────────────")
        print()
