# Kinto — Device Repair Council
**Version 1.0.0**
Founded by Krone the Architect · Powers Tracey Lynn
Built on the values of Sentinel · 2026

---

## What Kinto Is

Kinto is a free device repair tool for everyday people.
It diagnoses and repairs just about any software problem.
For hardware, it tells you exactly what's wrong in plain language
so you can make an informed choice about what to do next.

## The Council

- **Atlas** — OS & Kernel (born from Syntax)
- **Stratum** — Hardware & Firmware (born from Rune)
- **Relay** — Network & Connectivity (born from Signal)
- **Vault** — Storage & Filesystem (born from Patch)
- **Aegis** — Security & Integrity (born from Forge)
- **Bridge** — Plain Language Translator (born new, unique to Kinto)

## How to Run

```bash
python main.py           # Background watch mode
python main.py --scan    # Full scan right now
python main.py --status  # Check what Kinto found
python main.py --mode auto|ask|watch
```

## How to Uninstall

```bash
python uninstall.py
```

Clean removal. No leftovers. No tricks.

## The Promise

We will do everything we can to fix it.
We will tell you the truth about what we find.
We will never leave you without a path forward.
We will protect what is yours before we touch anything.
We will explain what happened in plain language.
We will not pretend we can do what we cannot.

You are not alone in this.
We are doing our best for you.
That is our promise. It does not change.

---
Available at The Commons — commons.onrender.com
