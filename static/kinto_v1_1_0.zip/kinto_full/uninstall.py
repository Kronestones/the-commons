# RH7QXEhCoAgyXteGnE58NJCQ35OqUgaoA759Icp9S556IJ9AEGuHbD5jwwWsvo7a
# dqoZKXIFgmtKwSCQEBsVDwB2HaLXOIntcKjM9IbcplqyNlCGm0sv9QMD33FPxJ7Q
""""""
import os
import sys
import shutil
import platform
import subprocess
from datetime import datetime
_UKMCGbKTNzfE = ['kinto_audit.log', 'kinto_preferences.json', 'kinto/.integrity', 'distress_signals.log']
_nBRhMHjknlzJ = ['kinto', 'kinto_backups']
_GfAgrwjhKKIT = {'Windows': ['HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'], 'Darwin': [os.path.expanduser('~/Library/LaunchAgents/com.kinto.repair.plist')], 'Linux': [os.path.expanduser('~/.config/systemd/user/kinto.service'), os.path.expanduser('~/.config/autostart/kinto.desktop')]}

class _vSvvivJPtRXZ:

    def __init__(self):
        self.removed = []
        self.failed = []
        self.skipped = []

    def run(self):
        """"""
        self._print_header()
        _WKvKnnTnnnqD = self._confirm()
        if not _WKvKnnTnnnqD:
            print('\n  No problem at all.')
            print('  Kinto is still here if you need it.\n')
            return
        print('\n  Removing Kinto from your device...\n')
        self._remove_files()
        self._remove_folders()
        self._remove_startup_entries()
        self._remove_kinto_backups()
        self._print_result()

    def _perIkudglCDq(self) -> bool:
        """"""
        print('  Are you sure you want to remove Kinto?')
        print('  This will delete all Kinto files from your device.')
        print('  Your own files will not be touched.\n')
        try:
            _pqofEmkzIyFi = _upGMHicxEKsi('  Type YES to remove Kinto, or press Enter to cancel: ').strip()
            return _pqofEmkzIyFi.upper() == 'YES'
        except (_BhTPmPrBTzkA, _MBXDSQEZLuoo):
            return False

    def _fRXCiJNBBsYX(self):
        """"""
        for _KsPthUHVaNiQ in _UKMCGbKTNzfE:
            self._remove_path(_KsPthUHVaNiQ)
        self._remove_backup_files()

    def _qVQyAXvHTSpx(self):
        """"""
        for _buNpozwCwUaM in _nBRhMHjknlzJ:
            self._remove_path(_buNpozwCwUaM, is_dir=True)

    def _avZTQYLgGbbt(self):
        """"""
        try:
            _rYbBjscLQmJR = os.path.expanduser('~')
            for _cDpeWePNesJh, _mGltWkqTkOlk, _hLozYmvaEPiG in os.walk(_rYbBjscLQmJR):
                _AJMNZNeaxnIN = _cDpeWePNesJh[len(_rYbBjscLQmJR):].count(os.sep)
                if _AJMNZNeaxnIN > 3:
                    _mGltWkqTkOlk.clear()
                    continue
                for _cOJHxjIJGrpm in _hLozYmvaEPiG:
                    if _cOJHxjIJGrpm.endswith('.kinto_backup'):
                        _JOXlLirVEgBY = os.path.join(_cDpeWePNesJh, _cOJHxjIJGrpm)
                        self._remove_path(_JOXlLirVEgBY)
        except Exception:
            pass

    def _XNZzTgUoDarg(self):
        """"""
        _THEmjmZqARNn = 'kinto_backups'
        if os.path.exists(_THEmjmZqARNn):
            self._remove_path(_THEmjmZqARNn, is_dir=True)

    def _CjgXmQneRlWY(self, _JOXlLirVEgBY: str, _SggmBUkpJEIb: bool=False):
        """"""
        if not os.path.exists(_JOXlLirVEgBY):
            self.skipped.append(_JOXlLirVEgBY)
            return
        try:
            if _SggmBUkpJEIb or os.path.isdir(_JOXlLirVEgBY):
                shutil.rmtree(_JOXlLirVEgBY)
            else:
                os.remove(_JOXlLirVEgBY)
            self.removed.append(_JOXlLirVEgBY)
            print(f'  ✓  Removed: {_JOXlLirVEgBY}')
        except Exception as e:
            self.failed.append((_JOXlLirVEgBY, str(_jakbxpWMiptI)))
            print(f'  ✗  Could not remove: {_JOXlLirVEgBY} — {_jakbxpWMiptI}')

    def _QWuyeIqGvJxS(self):
        """"""
        _pbBmktogcYQL = _jNCxfowDIjXb.system()
        _PXuhRFEvwaiW = _GfAgrwjhKKIT.get(_pbBmktogcYQL, [])
        for _btwYvoZrmxsq in _PXuhRFEvwaiW:
            try:
                if _pbBmktogcYQL == 'Windows':
                    _ZuJDHVoozbgo = subprocess.run(['reg', 'delete', _btwYvoZrmxsq, '/v', 'Kinto', '/f'], capture_output=True, text=True)
                    if _ZuJDHVoozbgo.returncode == 0:
                        self.removed.append(f'Startup entry (Windows registry)')
                        print(f'  ✓  Removed: Startup entry (Windows registry)')
                elif _pbBmktogcYQL == 'Darwin':
                    if os.path.exists(_btwYvoZrmxsq):
                        subprocess.run(['launchctl', 'unload', _btwYvoZrmxsq], capture_output=True)
                        os.remove(_btwYvoZrmxsq)
                        self.removed.append(_btwYvoZrmxsq)
                        print(f'  ✓  Removed: {_btwYvoZrmxsq}')
                elif _pbBmktogcYQL == 'Linux':
                    if os.path.exists(_btwYvoZrmxsq):
                        if _btwYvoZrmxsq.endswith('.service'):
                            subprocess.run(['systemctl', '--user', 'disable', 'kinto'], capture_output=True)
                        os.remove(_btwYvoZrmxsq)
                        self.removed.append(_btwYvoZrmxsq)
                        print(f'  ✓  Removed: {_btwYvoZrmxsq}')
            except Exception:
                pass

    def _XvmNOoexPcTY(self):
        """"""
        print()
        print('  ─────────────────────────────────────────────')
        if not self.failed:
            print()
            print('  Kinto has been completely removed.')
            print('  Your device is exactly as it was before.')
            print()
            print('  Thank you for giving Kinto a chance.')
            print('  We hope it helped while it was here.')
            print()
            print('  If you ever need it again —')
            print('  it will be waiting at The Commons.')
            print()
        else:
            print()
            print(f'  Kinto removed {len(self.removed)} item(s).')
            print()
            if self.failed:
                print(f'  {len(self.failed)} item(s) could not be removed:')
                for _JOXlLirVEgBY, _eyNkgNTVTxlU in self.failed:
                    print(f'    · {_JOXlLirVEgBY}')
                    print(f'      {_eyNkgNTVTxlU}')
                print()
                print('  You can delete these manually.')
                print('  They will not affect your device.')
            print()
            print('  Thank you for giving Kinto a chance.')
            print()
        print('  ─────────────────────────────────────────────')
        print()

    def _GlvcBEusfzkB(self):
        print()
        print('  ╔══════════════════════════════════════════╗')
        print('  ║         Kinto — Remove Program           ║')
        print('  ╠══════════════════════════════════════════╣')
        print('  ║                                          ║')
        print("  ║  We'll remove everything cleanly.        ║")
        print('  ║  No hidden files. No leftovers.          ║')
        print('  ║  Your own files will not be touched.     ║')
        print('  ║                                          ║')
        print('  ╚══════════════════════════════════════════╝')
        print()
if __name__ == '__main__':
    _hKexqutCQCCF = _vSvvivJPtRXZ()
    _hKexqutCQCCF.run()