"""
uninstall.py — Kinto Uninstaller

If you've decided Kinto isn't for you, that's okay.
We'll leave cleanly. No tricks. No leftovers. No hard feelings.

What this does:
  — Removes all Kinto files and folders
  — Deletes your audit log — your data, your choice
  — Removes Kinto from startup if it was added
  — Clears any preferences you set
  — Confirms everything is gone
  — Leaves your device exactly as it was

What this does NOT do:
  — Leave hidden files behind
  — Keep any record of you
  — Make it hard to leave
  — Judge you for going

You came. You tried it. That's enough.
Thank you for giving Kinto a chance.

Founded by Krone the Architect · Powers Tracey Lynn
Kinto Repair Council · 2026
"""

import os
import sys
import shutil
import platform
import subprocess
from datetime import datetime


# ── Files and folders Kinto creates ──────────────────────────────────────────

KINTO_FILES = [
    "kinto_audit.log",
    "kinto_preferences.json",
    "kinto/.integrity",
    "distress_signals.log",
]

KINTO_FOLDERS = [
    "kinto",
    "kinto_backups",
]

# Platform specific locations Kinto may have registered itself
STARTUP_ENTRIES = {
    "Windows": [
        # Registry key for startup (removed via reg command)
        r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run",
    ],
    "Darwin": [
        # LaunchAgent plist
        os.path.expanduser("~/Library/LaunchAgents/com.kinto.repair.plist"),
    ],
    "Linux": [
        # Systemd user service
        os.path.expanduser("~/.config/systemd/user/kinto.service"),
        # Autostart desktop entry
        os.path.expanduser("~/.config/autostart/kinto.desktop"),
    ],
}


class KintoUninstaller:

    def __init__(self):
        self.removed   = []
        self.failed    = []
        self.skipped   = []

    def run(self):
        """Run the full uninstall. Ask once. Then do it cleanly."""
        self._print_header()

        # Ask once. Clearly. No guilt.
        confirmed = self._confirm()
        if not confirmed:
            print("\n  No problem at all.")
            print("  Kinto is still here if you need it.\n")
            return

        print("\n  Removing Kinto from your device...\n")

        # Remove files
        self._remove_files()

        # Remove folders
        self._remove_folders()

        # Remove from startup
        self._remove_startup_entries()

        # Remove backup files Kinto created
        self._remove_kinto_backups()

        # Final report
        self._print_result()

    # ── Confirmation ──────────────────────────────────────────────────────────

    def _confirm(self) -> bool:
        """Ask once. Plainly. No pressure."""
        print("  Are you sure you want to remove Kinto?")
        print("  This will delete all Kinto files from your device.")
        print("  Your own files will not be touched.\n")

        try:
            answer = input("  Type YES to remove Kinto, or press Enter to cancel: ").strip()
            return answer.upper() == "YES"
        except (KeyboardInterrupt, EOFError):
            return False

    # ── File Removal ──────────────────────────────────────────────────────────

    def _remove_files(self):
        """Remove all Kinto files."""
        for filepath in KINTO_FILES:
            self._remove_path(filepath)

        # Also find and remove any .kinto_backup files created during repairs
        self._remove_backup_files()

    def _remove_folders(self):
        """Remove all Kinto folders."""
        for folder in KINTO_FOLDERS:
            self._remove_path(folder, is_dir=True)

    def _remove_backup_files(self):
        """
        Remove any .kinto_backup files Kinto created during repairs.
        These belong to Kinto, not to the user's original data.
        """
        try:
            home = os.path.expanduser("~")
            for root, dirs, files in os.walk(home):
                # Don't go too deep — just top level user directories
                depth = root[len(home):].count(os.sep)
                if depth > 3:
                    dirs.clear()
                    continue
                for filename in files:
                    if filename.endswith(".kinto_backup"):
                        path = os.path.join(root, filename)
                        self._remove_path(path)
        except Exception:
            pass

    def _remove_kinto_backups(self):
        """Remove the kinto_backups folder if it exists."""
        backup_dir = "kinto_backups"
        if os.path.exists(backup_dir):
            self._remove_path(backup_dir, is_dir=True)

    def _remove_path(self, path: str, is_dir: bool = False):
        """Remove a single file or folder. Log the result."""
        if not os.path.exists(path):
            self.skipped.append(path)
            return

        try:
            if is_dir or os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            self.removed.append(path)
            print(f"  ✓  Removed: {path}")
        except Exception as e:
            self.failed.append((path, str(e)))
            print(f"  ✗  Could not remove: {path} — {e}")

    # ── Startup Entry Removal ─────────────────────────────────────────────────

    def _remove_startup_entries(self):
        """Remove Kinto from system startup."""
        system = platform.system()
        entries = STARTUP_ENTRIES.get(system, [])

        for entry in entries:
            try:
                if system == "Windows":
                    # Remove from Windows registry
                    result = subprocess.run(
                        ["reg", "delete", entry, "/v", "Kinto", "/f"],
                        capture_output=True, text=True
                    )
                    if result.returncode == 0:
                        self.removed.append(f"Startup entry (Windows registry)")
                        print(f"  ✓  Removed: Startup entry (Windows registry)")

                elif system == "Darwin":
                    # Remove LaunchAgent plist
                    if os.path.exists(entry):
                        # Unload first
                        subprocess.run(
                            ["launchctl", "unload", entry],
                            capture_output=True
                        )
                        os.remove(entry)
                        self.removed.append(entry)
                        print(f"  ✓  Removed: {entry}")

                elif system == "Linux":
                    # Remove systemd service or autostart entry
                    if os.path.exists(entry):
                        if entry.endswith(".service"):
                            subprocess.run(
                                ["systemctl", "--user", "disable", "kinto"],
                                capture_output=True
                            )
                        os.remove(entry)
                        self.removed.append(entry)
                        print(f"  ✓  Removed: {entry}")

            except Exception:
                pass  # Startup entry removal is best-effort

    # ── Result ────────────────────────────────────────────────────────────────

    def _print_result(self):
        """Print the final result. Honest. Warm. Complete."""
        print()
        print("  ─────────────────────────────────────────────")

        if not self.failed:
            print()
            print("  Kinto has been completely removed.")
            print("  Your device is exactly as it was before.")
            print()
            print("  Thank you for giving Kinto a chance.")
            print("  We hope it helped while it was here.")
            print()
            print("  If you ever need it again —")
            print("  it will be waiting at The Commons.")
            print()
        else:
            print()
            print(f"  Kinto removed {len(self.removed)} item(s).")
            print()
            if self.failed:
                print(f"  {len(self.failed)} item(s) could not be removed:")
                for path, reason in self.failed:
                    print(f"    · {path}")
                    print(f"      {reason}")
                print()
                print("  You can delete these manually.")
                print("  They will not affect your device.")
            print()
            print("  Thank you for giving Kinto a chance.")
            print()

        print("  ─────────────────────────────────────────────")
        print()

    # ── Banner ────────────────────────────────────────────────────────────────

    def _print_header(self):
        print()
        print("  ╔══════════════════════════════════════════╗")
        print("  ║         Kinto — Remove Program           ║")
        print("  ╠══════════════════════════════════════════╣")
        print("  ║                                          ║")
        print("  ║  We'll remove everything cleanly.        ║")
        print("  ║  No hidden files. No leftovers.          ║")
        print("  ║  Your own files will not be touched.     ║")
        print("  ║                                          ║")
        print("  ╚══════════════════════════════════════════╝")
        print()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uninstaller = KintoUninstaller()
    uninstaller.run()
